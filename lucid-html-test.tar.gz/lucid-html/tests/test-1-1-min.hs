{-# LANGUAGE OverloadedStrings, ExtendedDefaultRules #-}

import Lucid
import Lucid.Base
import Data.Text
import System.IO (stdout)
import Data.Text.Lazy.IO as L

main :: IO ()
main = L.hPutStr stdout (renderText template1)

ariaHidden_ :: Text -> Attribute
ariaHidden_ = makeAttribute "aria-hidden"

property_ :: Text -> Attribute
property_ = makeAttribute "property"

-- this attribute is deprecated
language_ :: Text -> Attribute
language_ = makeAttribute "language"

-- this attribute is obsolete!
align_ :: Text -> Attribute
align_ = makeAttribute "align"

-- this tag is deprecated
tt_ :: Term arg result => arg -> result
tt_ = term "tt"

-- Template for file: test-1-1-spaces-min.html
template1 :: Html ()
template1 = do
    tt_ [ class_ "docutils literal" ] $ do
        span_ [ class_ "pre" ] $ "foreign"
        " "
        span_ [ class_ "pre" ] $ "export"
    " and "
    tt_ [ class_ "docutils literal" ] $ do
        span_ [ class_ "pre" ] $ "foreign"
        " "
        span_ [ class_ "pre" ] $ "import"
        " "
        span_ [ class_ "pre" ] $ "ccall"
        " "
        span_ [ class_ "pre" ] $ "\"wrapper\""
    "\n"

