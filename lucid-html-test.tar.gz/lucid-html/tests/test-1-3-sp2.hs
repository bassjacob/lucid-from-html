{-# LANGUAGE OverloadedStrings, ExtendedDefaultRules #-}

import Lucid
import Lucid.Supplemental
import System.IO (stdout, hSetEncoding, utf8)
import Data.Text.Lazy.IO as L

main :: IO ()
main = do
  hSetEncoding stdout utf8
  L.hPutStr stdout (renderText template1)


-- Template for file: test-1-3-spaces.html
template1 :: Html ()
template1 = do
    html_ $ do
        "\nstartPre\n"
        pre_ $ do
            "\n\n"
            i_ "abc"
            "\n\n"
            b_ "def"
            "\n\n"
        "\nendPre"
        br_ []
        "\nstartP\n"
        p_ $ do
            "\n\n"
            i_ "1 \\n above, 3 \\n below"
            "\n\n\n\n"
            b_ "1 \\n below"
            "\n\n"
        "\nendP"
        br_ []
        "\n3nbsp\160\160\160here\n"
    "\n"

