{-# LANGUAGE OverloadedStrings, ExtendedDefaultRules #-}

import Lucid
import Lucid.Supplemental
import System.IO (stdout, hSetEncoding, utf8)
import Data.Text.Lazy.IO as L

main :: IO ()
main = do
  hSetEncoding stdout utf8
  L.hPutStr stdout (renderText template1)


-- Template for file: test-1-3-spaces.html
template1 :: Html ()
template1 = do
    pre_ $ do
        "\n\n"
        i_ "abc"
        "\n\n"
        b_ "def"
        "\n\n"
    "\nendPre\n"
    p_ $ do
        i_ "ghi"
        b_ "jkl"
    "\nendP\n"

