{-# LANGUAGE OverloadedStrings, ExtendedDefaultRules #-}

import Lucid
import Lucid.Base
import Data.Text
import System.IO (stdout)
import Data.Text.Lazy.IO as L

main :: IO ()
main = L.hPutStr stdout (renderText template1)

ariaHidden_ :: Text -> Attribute
ariaHidden_ = makeAttribute "aria-hidden"

property_ :: Text -> Attribute
property_ = makeAttribute "property"

-- this attribute is deprecated
language_ :: Text -> Attribute
language_ = makeAttribute "language"

-- this attribute is obsolete!
align_ :: Text -> Attribute
align_ = makeAttribute "align"

-- this tag is deprecated
tt_ :: Term arg result => arg -> result
tt_ = term "tt"

-- Template for file: test-spaces.html
template1 :: Html ()
template1 = do
    "\n"
    doctype_
    "\n\n\n"
    html_ [ xmlns_ "http://www.w3.org/1999/xhtml" ] $ do
        "\n  "
        head_ $ do
            "\n    "
            meta_ [ httpEquiv_ "Content-Type", content_ "text/html; charset=utf-8" ]
            "\n    \n    "
            title_ "Welcome to the GHC User\8217s Guide \8212 Glasgow Haskell Compiler <release> User's Guide"
            "\n    \n    "
            link_ [ rel_ "stylesheet", href_ "_static/ghc-theme.css", type_ "text/css" ]
            "\n    "
            link_ [ rel_ "stylesheet", href_ "_static/pygments.css", type_ "text/css" ]
            "\n    \n    "
            script_ [ type_ "text/javascript" ] $ "\n      var DOCUMENTATION_OPTIONS = {\n        URL_ROOT:    './',\n        VERSION:     '8.2.0.20170704',\n        COLLAPSE_INDEX: false,\n        FILE_SUFFIX: '.html',\n        HAS_SOURCE:  true\n      };\n    "
            "\n    "
            script_ [ type_ "text/javascript", src_ "_static/jquery.js" ] $ ""
            "\n    "
            script_ [ type_ "text/javascript", src_ "_static/underscore.js" ] $ ""
            "\n    "
            script_ [ type_ "text/javascript", src_ "_static/doctools.js" ] $ ""
            "\n    "
            link_ [ rel_ "search", type_ "application/opensearchdescription+xml", title_ "Search within Glasgow Haskell Compiler <release> User's Guide", href_ "_static/opensearch.xml" ]
            "\n    "
            link_ [ rel_ "top", title_ "Glasgow Haskell Compiler <release> User's Guide", href_ "#" ]
            "\n    "
            link_ [ rel_ "next", title_ "1. The Glasgow Haskell Compiler License", href_ "license.html" ]
            " \n  "
        "\n"
        body_ $ do
            "\n"
            div_ [ class_ "document" ] $ do
                "\n  "
                div_ [ class_ "documentwrapper" ] $ do
                    "\n    "
                    div_ [ class_ "bodywrapper" ] $ do
                        "\n      "
                        div_ [ class_ "body" ] $ do
                            "\n        "
                            div_ [ id_ "welcome-to-the-ghc-user-s-guide", class_ "section" ] $ do
                                "\n          "
                                div_ [ class_ "toctree-wrapper compound" ] $ do
                                    "\n            "
                                    ul_ $ do
                                        "\n              "
                                        li_ [ class_ "toctree-l1" ] $ do
                                            a_ [ class_ "reference internal", href_ "ffi-chap.html" ] $ "10. Foreign function interface (FFI)"
                                            "\n                "
                                            ul_ $ do
                                                "\n                  "
                                                li_ [ class_ "toctree-l2" ] $ do
                                                    a_ [ class_ "reference internal", href_ "ffi-chap.html#using-the-ffi-with-ghc" ] $ "10.2. Using the FFI with GHC"
                                                    "\n                    "
                                                    ul_ $ do
                                                        "\n                      "
                                                        li_ [ class_ "toctree-l3" ] $ do
                                                            a_ [ class_ "reference internal", href_ "ffi-chap.html#using-foreign-export-and-foreign-import-ccall-wrapper-with-ghc" ] $ do
                                                                "10.2.1. using "
                                                                tt_ [ class_ "docutils literal" ] $ do
                                                                    span_ [ class_ "pre" ] $ "foreign"
                                                                    " "
                                                                    span_ [ class_ "pre" ] $ "export"
                                                                " and "
                                                                tt_ [ class_ "docutils literal" ] $ do
                                                                    span_ [ class_ "pre" ] $ "foreign"
                                                                    " "
                                                                    span_ [ class_ "pre" ] $ "import"
                                                                    " "
                                                                    span_ [ class_ "pre" ] $ "ccall"
                                                                    " "
                                                                    span_ [ class_ "pre" ] $ "\"wrapper\""
                                                                " with GHC"
                                                            "\n                        "
                                                            ul_ $ do
                                                                "\n                          "
                                                                li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "ffi-chap.html#using-your-own-main" ] $ do
                                                                    "10.2.1.1. using your own "
                                                                    tt_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ "main()"
                                                                "\n                          "
                                                                li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "ffi-chap.html#making-a-haskell-library-that-can-be-called-from-foreign-code" ] $ "10.2.1.2. making a haskell library that can be called from foreign code"
                                                                "\n                        "
                                                            "\n                      "
                                                        "\n                      "
                                                        li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "ffi-chap.html#using-header-files" ] $ "10.2.2. using header files"
                                                        "\n                      "
                                                        li_ [ class_ "toctree-l3" ] $ do
                                                            a_ [ class_ "reference internal", href_ "ffi-chap.html#memory-allocation" ] $ "10.2.3. memory allocation"
                                                            "\n                      "
                                                        "\n                      "
                                                        li_ [ class_ "toctree-l3" ] $ ""
                                                        "\n                    "
                                                    "\n                  "
                                                "\n                "
                                            "\n              "
                                        "\n            "
                                    "\n          "
                                "\n        "
                            "\n      "
                        "\n    "
                    "\n  "
                "\n"
            "\n\n"
        "\n"
    "\n"

