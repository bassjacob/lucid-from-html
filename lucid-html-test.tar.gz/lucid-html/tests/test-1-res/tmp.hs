{-# LANGUAGE OverloadedStrings, ExtendedDefaultRules #-}

import Lucid
import Lucid.Base
import Data.Text
import System.IO (stdout)
import Data.Text.Lazy.IO as L

main :: IO ()
main = L.hPutStr stdout (renderText template1)

ariaHidden_ :: Text -> Attribute
ariaHidden_ = makeAttribute "aria-hidden"

property_ :: Text -> Attribute
property_ = makeAttribute "property"

-- this attribute is deprecated
language_ :: Text -> Attribute
language_ = makeAttribute "language"

-- this attribute is obsolete!
align_ :: Text -> Attribute
align_ = makeAttribute "align"

-- this tag is deprecated
tt_ :: Term arg result => arg -> result
tt_ = term "tt"

-- Template for file: test-1-index.html
template1 :: Html ()
template1 = do
    doctype_
    html_ [ xmlns_ "http://www.w3.org/1999/xhtml" ] $ do
        head_ $ do
            meta_ [ httpEquiv_ "Content-Type", content_ "text/html; charset=utf-8" ]
            title_ "Welcome to the GHC User\8217s Guide \8212 Glasgow Haskell Compiler <release> User's Guide"
            link_ [ rel_ "stylesheet", href_ "_static/ghc-theme.css", type_ "text/css" ]
            link_ [ rel_ "stylesheet", href_ "_static/pygments.css", type_ "text/css" ]
            script_ [ type_ "text/javascript" ] $ "\n      var DOCUMENTATION_OPTIONS = {\n        URL_ROOT:    './',\n        VERSION:     '8.2.0.20170704',\n        COLLAPSE_INDEX: false,\n        FILE_SUFFIX: '.html',\n        HAS_SOURCE:  true\n      };\n    "
            script_ [ type_ "text/javascript", src_ "_static/jquery.js" ] $ ""
            script_ [ type_ "text/javascript", src_ "_static/underscore.js" ] $ ""
            script_ [ type_ "text/javascript", src_ "_static/doctools.js" ] $ ""
            link_ [ rel_ "search", type_ "application/opensearchdescription+xml", title_ "Search within Glasgow Haskell Compiler <release> User's Guide", href_ "_static/opensearch.xml" ]
            link_ [ rel_ "top", title_ "Glasgow Haskell Compiler <release> User's Guide", href_ "#" ]
            link_ [ rel_ "next", title_ "1. The Glasgow Haskell Compiler License", href_ "license.html" ]
        body_ $ do
            div_ [ class_ "document" ] $ do
                div_ [ class_ "documentwrapper" ] $ div_ [ class_ "bodywrapper" ] $ div_ [ class_ "body" ] $ do
                    div_ [ class_ "section", id_ "welcome-to-the-ghc-user-s-guide" ] $ do
                        div_ [ class_ "toctree-wrapper compound" ] $ ul_ $ do
                            li_ [ class_ "toctree-l1" ] $ do
                                a_ [ class_ "reference internal", href_ "ffi-chap.html" ] $ "10. Foreign function interface (FFI)"
                                ul_ $ do
                                    li_ [ class_ "toctree-l2" ] $ do
                                        a_ [ class_ "reference internal", href_ "ffi-chap.html#using-the-ffi-with-ghc" ] $ "10.2. Using the FFI with GHC"
                                        ul_ $ do
                                            li_ [ class_ "toctree-l3" ] $ do
                                                a_ [ class_ "reference internal", href_ "ffi-chap.html#using-foreign-export-and-foreign-import-ccall-wrapper-with-ghc" ] $ do
                                                    "10.2.1. Using "
                                                    tt_ [ class_ "docutils literal" ] $ do
                                                        span_ [ class_ "pre" ] $ "foreign"
                                                        span_ [ class_ "pre" ] $ "export"
                                                    " and "
                                                    tt_ [ class_ "docutils literal" ] $ do
                                                        span_ [ class_ "pre" ] $ "foreign"
                                                        span_ [ class_ "pre" ] $ "import"
                                                        span_ [ class_ "pre" ] $ "ccall"
                                                        span_ [ class_ "pre" ] $ "\"wrapper\""
                                                    " with GHC"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "ffi-chap.html#using-header-files" ] $ "10.2.2. Using header files"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "ffi-chap.html#memory-allocation" ] $ "10.2.3. Memory Allocation"
                                            li_ [ class_ "toctree-l3" ] $ ""
