{-# LANGUAGE OverloadedStrings, ExtendedDefaultRules #-}

import Lucid
import Lucid.Supplemental
import System.IO (stdout)
import Data.Text.Lazy.IO as L

main :: IO ()
main = L.hPutStr stdout (renderText template1)

-- Template for file: test-1-1-spaces-min.html
template1 :: Html ()
template1 = do
    tt_ [ class_ "docutils literal" ] $ do
        span_ [ class_ "pre" ] $ "foreign"
        " "
        span_ [ class_ "pre" ] $ "export"
    " and "
    tt_ [ class_ "docutils literal" ] $ do
        span_ [ class_ "pre" ] $ "foreign"
        " "
        span_ [ class_ "pre" ] $ "import"
        " "
        span_ [ class_ "pre" ] $ "ccall"
        " "
        span_ [ class_ "pre" ] $ "\"wrapper\""
    "\n"

