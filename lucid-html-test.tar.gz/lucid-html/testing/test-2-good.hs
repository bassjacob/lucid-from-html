{-# LANGUAGE OverloadedStrings, ExtendedDefaultRules #-}

import Lucid
import Lucid.Supplemental
import System.IO (stdout, hSetEncoding, utf8)
import Data.Text.Lazy.IO as L

main :: IO ()
main = do
  hSetEncoding stdout utf8
  L.hPutStr stdout (renderText template1)


-- Template for file: test-2-folia.html
template1 :: Html ()
template1 = do
    doctype_
    "\n"
    toHtmlRaw  "<!-- \n    Obtainded by\n    wget -O test-2-folia.html http://www.foliageoutdoors.com\n\n    <svg>'s are commented\n-->"
    "\n"
    html_ $ do
        "\n"
        head_ $ do
            "\n  "
            meta_ [ charset_ "utf-8" ]
            "\n  "
            meta_ [ httpEquiv_ "X-UA-Compatible", content_ "IE=edge" ]
            "\n  "
            meta_ [ name_ "viewport", content_ "width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" ]
            "\n\n  "
            title_ "Best Wildlife & Adventure Holidays | Summer Camps | Offbeat Trips | Treks | Nature Camps | Kids Camps Pune Mumbai"
            "\n  "
            meta_ [ name_ "description", content_ "We are a government recognized Tours & Travels in Pune, India. We specialized in offering Offbeat Destinations in India, summer camps in India, offbeat tours. Foliage Outdoors , Boys and Girls age 8 to 16 years , Kids Acitivity camps near Pune , Mumbai , Wildlife camps Kanha , Bandhavgarh, Ranthambhore,Gir,Corbett , Kaziranga , Manali Adventure, Chandrashila Chopta Trek, Pha Konda trek, Pugmarks123, Cloud 9 , Rishikeh Rafting,Dandeli Goa Meta Description: Foliage Outdoors premier organisation in Pune and near Mumbai catering to boys and girls of age 8 years to 16 years to various destination near Pune, Wildlife National Parks in India and Himalayan Treks" ]
            "\n\n    "
            link_ [ rel_ "canonical", href_ "http://www.foliageoutdoors.com/" ]
            "\n\n  "
            link_ [ href_ "//d1j3wd17d78ehn.cloudfront.net/custom_stylesheets/common/store_front/themes/flexi_theme/style_4156_20171124060331-53c06b5123a00cef3b90b71865ecca2a.css", media_ "screen", rel_ "stylesheet", type_ "text/css" ]
            "\n\n\n    "
            link_ [ rel_ "icon", type_ "image/png", href_ "//d1j3wd17d78ehn.cloudfront.net/system/images/000/100/266/ff0d1c0901096aa65bc72b8c91c5d20d/favicon/Foliage_logo_favicon_png.png?1510555138" ]
            "\n\n  "
            toHtmlRaw  "<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->"
            "\n  "
            toHtmlRaw  "<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->"
            "\n  "
            toHtmlRaw  "<!--[if lt IE 9]>\n    <script src=\"https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js\"></script>\n    <script src=\"https://oss.maxcdn.com/respond/1.4.2/respond.min.js\"></script>\n  <![endif]-->"
            "\n\n\n  "
            toHtmlRaw  "<!-- Open Graph Tags -->"
            "\n  "
            toHtmlRaw  "<!-- <meta property=\"og:type\" content=\"article\"> -->"
            "\n    "
            meta_ [ property_ "og:title", content_ "Foliage Outdoors | Wildlife Camps | Adventure Camps | Trekking | Kids Camps Pune |Summer Camps" ]
            "\n    "
            meta_ [ property_ "og:description", content_ "Adventure seekers and travellers looking for new vistas are what excite us and have kept us going since 2000." ]
            "\n  "
            meta_ [ property_ "og:url", content_ "http://www.foliageoutdoors.com/" ]
            "\n  "
            meta_ [ property_ "og:site_name", content_ "Foliage Outdoors" ]
            "\n  "
            meta_ [ property_ "og:image", content_ "//d1j3wd17d78ehn.cloudfront.net/system/images/000/102/604/99cc0041ebd04dd50c12b7f9aff70fe6/banner/24_(1).jpg?1511023098" ]
            "\n\n  "
            toHtmlRaw  "<!-- Client stylesheet and header script -->"
            "\n  "
            style_ [ type_ "text/css" ] $ "\n    #body > div > div.content-area > div.main-content > div.section.additional-fields-section > div.additional-fields > div > div.field-title{display:none;}\n\n#body > div > div.content-area > div.main-content > div.section.additional-fields-section > div.additional-fields > div > div.field-value{display:none;}\n\n.section-type-accreditations > .content > .logo-item > .logo{\n  filter: none !important;\n}\n\n.page-type-trip .section-type-banner .floating-container .book-button{font-size:18px;}\n.section-type-accreditations > .content > .logo-item > a > .logo{\n  filter: none !important;}\n\n.trips-date-based .months-listing .month-accordion .accordion-content .accordion-data .trip-info .availability { display:none;}\n\n#body > div > div.content-area > div.section.trips-date-based > div.months-listing > div.month-accordion.active > div.accordion-content.slide > div > div > div > span:nth-child(3){ display:none;}\n\n.footer-container.footer-multi-column{font-size:14px;}\n\n.header-center-aligned .header-bottom .main-nav{font-size:14px;}\n\n.page-type-trip .section-type-banner .mobile-floating-container .btn-container .book-button{font-size:14px;}\n\n.page-type-trip .additional-fields-section .additional-fields{display:none;}\n\n.trips-date-based .months-listing .month-accordion .accordion-content .accordion-data .trip-info .tour-location .media-body .available-seats-sticker-price > span:first-child{display:none;}\n\n.trips-date-based .months-listing .month-accordion .accordion-content .accordion-data .trip-info .tour-location .media-body .available-seats-sticker-price > span:first-child{display:none;}\n\n#body > div > div.content-area > div.section.trips-date-based > div.months-listing > div > div.accordion-content > div > div > div > span:nth-child(3) {display:none;}\n  "
            "\n  "
            toHtmlRaw  "<!-- Global site tag (gtag.js) - AdWords: 874842349 -->"
            "\n"
            script_ [ async_ "", src_ "https://www.googletagmanager.com/gtag/js?id=AW-874842349" ] $ ""
            "\n"
            script_ "\n  window.dataLayer = window.dataLayer || [];\n  function gtag(){dataLayer.push(arguments);}\n  gtag('js', new Date());\n\n  gtag('config', 'AW-874842349');\n"
            "\n"
            toHtmlRaw  "<!-- Global site tag (gtag.js) - Google Analytics -->"
            "\n"
            script_ [ async_ "", src_ "https://www.googletagmanager.com/gtag/js?id=UA-1961475-4" ] $ ""
            "\n"
            script_ "\n  window.dataLayer = window.dataLayer || [];\n  function gtag(){dataLayer.push(arguments);}\n  gtag('js', new Date());\n\n  gtag('config', 'UA-1961475-4');\n"
            "\n"
            toHtmlRaw  "<!-- Global site tag (gtag.js) - Google Analytics -->"
            "\n"
            script_ [ async_ "", src_ "https://www.googletagmanager.com/gtag/js?id=UA-1961475-9" ] $ ""
            "\n"
            script_ "\n  window.dataLayer = window.dataLayer || [];\n  function gtag(){dataLayer.push(arguments);}\n  gtag('js', new Date());\n\n  gtag('config', 'UA-1961475-9');\n"
            "\n"
            toHtmlRaw  "<!-- Global site tag (gtag.js) - Google Analytics -->"
            "\n"
            script_ [ async_ "", src_ "https://www.googletagmanager.com/gtag/js?id=UA-1961475-9" ] $ ""
            "\n"
            script_ "\n  window.dataLayer = window.dataLayer || [];\n  function gtag(){dataLayer.push(arguments);}\n  gtag('js', new Date());\n\n  gtag('config', 'UA-1961475-9');\n"
            "\n"
            toHtmlRaw  "<!-- Facebook Pixel Code -->"
            "\n"
            script_ "\n  !function(f,b,e,v,n,t,s)\n  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?\n  n.callMethod.apply(n,arguments):n.queue.push(arguments)};\n  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';\n  n.queue=[];t=b.createElement(e);t.async=!0;\n  t.src=v;s=b.getElementsByTagName(e)[0];\n  s.parentNode.insertBefore(t,s)}(window, document,'script',\n  'https://connect.facebook.net/en_US/fbevents.js');\n  fbq('init', '1565756943734145');\n  fbq('track', 'PageView');\n"
            "\n"
            noscript_ $ img_ [ height_ "1", width_ "1", style_ "display:none", src_ "https://www.facebook.com/tr?id=1565756943734145&ev=PageView&noscript=1" ]
            "\n"
            toHtmlRaw  "<!-- End Facebook Pixel Code -->"
            "\n\n"
        "\n\n"
        body_ [ id_ "", data_ "page-type" "home", data_ "page" "38017", class_ "container-fluid assan-container index_handler center-aligned-header-style ", data_ "spy" "scroll", data_ "target" ".sticky-menu", data_ "offset" "150" ] $ do
            "\n    "
            header_ [ class_ "header-center-aligned " ] $ do
                "\n  "
                div_ [ class_ "header-top" ] $ do
                    "\n    "
                    div_ [ class_ "container" ] $ do
                        "\n      "
                        div_ [ class_ "row" ] $ do
                            "\n        "
                            div_ [ class_ "col-xs-12" ] $ do
                                "\n          "
                                div_ [ class_ "holder" ] $ do
                                    "\n            "
                                    div_ [ class_ "hidden-xs hidden-sm info-block" ] $ do
                                        "\n              "
                                        ul_ [ class_ "info-list list-unstyled" ] $ do
                                            "\n                 "
                                            li_ $ a_ [ href_ "tel://#{@client.support_phone}" ] $ do
                                                i_ [ class_ "fa fa-phone skip-title-check", ariaHidden_ "true" ] $ ""
                                                " +91 2066447777 "
                                            "\n                  "
                                            li_ $ a_ [ href_ "mailto:#{@client.support_email}" ] $ do
                                                i_ [ class_ "fa fa-envelope", ariaHidden_ "true" ] $ ""
                                                "info@foliageoutdoors.com"
                                            "\n              "
                                        "\n            "
                                    "\n            "
                                    toHtmlRaw  "<!-- select block -->"
                                    "\n            "
                                    div_ [ class_ "select-holder" ] $ do
                                        "\n              "
                                        toHtmlRaw  "<!-- google translate language select -->"
                                        "\n              "
                                        toHtmlRaw  "<!-- currency select -->"
                                        "\n\n            "
                                    "\n          "
                                "\n        "
                            "\n      "
                        "\n    "
                    "\n  "
                "\n  "
                div_ [ class_ "header-bottom" ] $ do
                    "\n    "
                    div_ [ class_ "container" ] $ do
                        "\n      "
                        div_ [ class_ "row" ] $ do
                            "\n        "
                            div_ [ class_ "col-xs-12" ] $ do
                                "\n          "
                                div_ [ class_ "menu-holder tall-logo header-search-enabled" ] $ do
                                    "\n            "
                                    toHtmlRaw  "<!-- burger menu button -->"
                                    "\n            "
                                    a_ [ href_ "#", class_ "nav-opener" ] $ span_ ""
                                    "\n            "
                                    toHtmlRaw  "<!-- search drop -->"
                                    "\n            "
                                    div_ [ class_ "nav-slide" ] $ do
                                        "\n              "
                                        toHtmlRaw  "<!-- burger menu close button -->"
                                        "\n              "
                                        a_ [ href_ "#", class_ "nav-close" ] $ ""
                                        "\n              "
                                        toHtmlRaw  "<!-- main navigation of the page -->"
                                        "\n                "
                                        ul_ [ class_ "main-nav left-menu accordion multilevel-accordion" ] $ do
                                            "\n                    "
                                            li_ [ class_ " ", id_ "menu-item-0 " ] $ a_ [ class_ "", href_ "/", target_ "_self", title_ "Home" ] $ "Home"
                                            "\n                    "
                                            li_ [ class_ " has-drop-down", id_ "menu-item-1 " ] $ do
                                                a_ [ class_ "accordion-opener has-drop-down-a", href_ "#", target_ "_self", title_ "About" ] $ "About"
                                                div_ [ class_ "nav-drop slide" ] $ ul_ $ do
                                                    li_ $ a_ [ href_ "/who-we-are", target_ "_self", title_ "Who We Are" ] $ "Who We Are"
                                                    li_ $ a_ [ href_ "/vision-values", target_ "_self", title_ "Our Visions & Values" ] $ "Our Visions & Values"
                                                    li_ $ a_ [ href_ "/foliage-advantage", target_ "_self", title_ "Foliage Advantage" ] $ "Foliage Advantage"
                                                    li_ $ a_ [ href_ "/our-team", target_ "_self", title_ "Our People" ] $ "Our People"
                                            "\n                    "
                                            li_ [ class_ " ", id_ "menu-item-2 " ] $ a_ [ class_ "", href_ "/collections/summer-camps-2018", target_ "_self", title_ "Summer Camps 2018" ] $ "Summer Camps 2018"
                                            "\n                "
                                        "\n                "
                                        ul_ [ class_ "main-nav right-menu accordion multilevel-accordion" ] $ do
                                            "\n                    "
                                            li_ [ class_ " has-drop-down", id_ "menu-item-0 " ] $ do
                                                a_ [ class_ "accordion-opener has-drop-down-a", href_ "/collections/upcoming-tours", target_ "_self", title_ "Tours" ] $ "Tours"
                                                div_ [ class_ "nav-drop slide" ] $ ul_ $ do
                                                    li_ $ a_ [ href_ "/collections/upcoming-tours", target_ "_self", title_ "Upcoming Tours" ] $ "Upcoming Tours"
                                                    li_ $ a_ [ href_ "/collections/adventure-camps-and-treks-10-16-years", target_ "_self", title_ "Adventure Camps and Treks (10-16 years)" ] $ "Adventure Camps and Treks (10-16 years)"
                                                    li_ $ a_ [ href_ "/collections/adventure-camps-and-treks-14-18-years", target_ "_self", title_ "Adventure Camps and Treks (14-18 years)" ] $ "Adventure Camps and Treks (14-18 years)"
                                                    li_ $ a_ [ href_ "/collections/wildlife-camps-10-16-years", target_ "_self", title_ "Wildlife Camps (10-16 years)" ] $ "Wildlife Camps (10-16 years)"
                                                    li_ $ a_ [ href_ "/collections/kids-camps", target_ "_self", title_ "Kids' Camps (8-12 years)" ] $ "Kids' Camps (8-12 years)"
                                                    li_ $ a_ [ href_ "/collections/youthcamps", target_ "_self", title_ "Youth Camps (18-22 years)" ] $ "Youth Camps (18-22 years)"
                                                    li_ $ a_ [ href_ "/collections/international-tours", target_ "_self", title_ "International Tours" ] $ "International Tours"
                                                    li_ $ a_ [ href_ "/collections/wildlife-tours", target_ "_self", title_ "Wildlife Tours for All Ages" ] $ "Wildlife Tours for All Ages"
                                                    li_ $ a_ [ href_ "/collections/treks-and-leisure-treks", target_ "_self", title_ "Treks and Leisure Treks for All Ages" ] $ "Treks and Leisure Treks for All Ages"
                                            "\n                    "
                                            li_ [ class_ " ", id_ "menu-item-1 " ] $ a_ [ class_ "", href_ "/contact-us", target_ "_self", title_ "Contact Us" ] $ "Contact Us"
                                            "\n                "
                                        "\n            "
                                    "\n              "
                                    div_ [ class_ "popup-holder" ] $ do
                                        "\n                "
                                        a_ [ href_ "#", class_ "opener fa fa-search" ] $ ""
                                        "\n                "
                                        div_ [ class_ "popup" ] $ do
                                            "\n                  "
                                            form_ [ action_ "#", class_ "global-search-form" ] $ do
                                                "\n                    "
                                                div_ [ class_ "input-holder global-search" ] $ do
                                                    "\n                      "
                                                    input_ [ type_ "hidden", class_ "js-search-select", data_ "drop-class" "global-header-search-box-drop", placeholder_ "What are you looking for?" ]
                                                    "\n                      "
                                                    "\n                    "
                                                "\n                  "
                                            "\n                "
                                        "\n              "
                                    "\n\n            "
                                    toHtmlRaw  "<!-- page logo -->"
                                    "\n            "
                                    div_ [ class_ "logo-holder" ] $ do
                                        "\n                "
                                        strong_ [ class_ "logo" ] $ do
                                            "\n                  "
                                            a_ [ href_ "/" ] $ do
                                                "\n                    "
                                                img_ [ alt_ "Foliage Outdoors Logo", class_ "tall-img", id_ "logo", src_ "//d1j3wd17d78ehn.cloudfront.net/system/images/000/100/953/44497b6fcf9b69e74690cebc5352ff70/website_logo/Foliage_Logo_with_outline.png?1510912230", title_ "Foliage Outdoors Logo" ]
                                                "\n                  "
                                            "\n                "
                                        "\n              "
                                        span_ [ class_ "bg-l" ] $ ""
                                        "\n              "
                                        span_ [ class_ "bg-r" ] $ ""
                                        "\n            "
                                    "\n          "
                                "\n        "
                            "\n      "
                        "\n    "
                    "\n  "
                "\n"
            "\n\n"
            toHtmlRaw  "<!-- popular search results -->"
            "\n"
            div_ [ id_ "popular-search-results", style_ "display:none", data_ "popular-search" "[{\"items\":[{\"title\":\"Upcoming Tours\",\"page_type\":\"trip_collection\",\"custom_url\":null,\"is_custom_url\":false,\"open_in_new_window\":false,\"storefront_route_id\":38023,\"extra_data\":{\"name\":\"Upcoming Tours\",\"advertised_price_string\":\"\\u20b9 3\",\"total_tours\":71,\"route_url\":\"/collections/upcoming-tours\"}},{\"title\":\"Adventure Camps and Treks (14-22 years)\",\"page_type\":\"trip_collection\",\"custom_url\":null,\"is_custom_url\":false,\"open_in_new_window\":false,\"storefront_route_id\":43839,\"extra_data\":{\"name\":\"Adventure Camps and Treks (14-18 years)\",\"advertised_price_string\":\"\\u20b9 27,400\",\"total_tours\":7,\"route_url\":\"/collections/adventure-camps-and-treks-14-18-years\"}},{\"title\":\"Adventure Camps and Treks (10-16 years)\",\"page_type\":\"trip_collection\",\"custom_url\":null,\"is_custom_url\":false,\"open_in_new_window\":false,\"storefront_route_id\":43636,\"extra_data\":{\"name\":\"Adventure Camps and Treks (10-16 years)\",\"advertised_price_string\":\"\\u20b9 18,900\",\"total_tours\":6,\"route_url\":\"/collections/adventure-camps-and-treks-10-16-years\"}},{\"title\":\"Wildlife Camps (10-16 years)\",\"page_type\":\"trip_collection\",\"custom_url\":null,\"is_custom_url\":false,\"open_in_new_window\":false,\"storefront_route_id\":40162,\"extra_data\":{\"name\":\"Wildlife Camps (10-16 years)\",\"advertised_price_string\":\"\\u20b9 19,600\",\"total_tours\":11,\"route_url\":\"/collections/wildlife-camps-10-16-years\"}}],\"title\":\"Trips\"}]" ] $ ""
            "\n"
            div_ [ id_ "body" ] $ do
                "\n  "
                div_ [ class_ "page-type-home", data_ "page-id" "38017" ] $ do
                    "\n\n    "
                    toHtmlRaw  "<!-- section is present -->"
                    "\n    "
                    toHtmlRaw  "<!-- section has active banner slides -->"
                    "\n\n      "
                    div_ [ class_ "section-fluid section-type-banner banner-slide banner-present bigger-slide ", data_ "banner-slide-id" "7051", data_ "slide-type" "custom" ] $ do
                        "\n        "
                        div_ [ class_ "content" ] $ do
                            "\n          "
                            div_ [ class_ "bg-cover-container owl-lazy b-loading b-lazy", data_ "src" "//d1j3wd17d78ehn.cloudfront.net/system/images/000/102/604/99cc0041ebd04dd50c12b7f9aff70fe6/banner/24_(1).jpg?1511023098", title_ "Join us on an Adventure of a Lifetime !" ] $ ""
                            "\n            "
                            div_ [ class_ "black-50-overlay" ] $ ""
                            "\n          "
                            div_ [ class_ "content-overlay" ] $ do
                                "\n            "
                                div_ [ class_ "custom-slide" ] $ do
                                    "\n  "
                                    div_ [ class_ "title" ] $ do
                                        "\n      "
                                        h1_ "Join us on an Adventure of a Lifetime !"
                                        "\n  "
                                    "\n\n  "
                                    toHtmlRaw  "<!-- NOTE: Global Search to be used only on home page with search enabled set in website theme settings -->"
                                    "\n    "
                                    form_ [ action_ "#", class_ "global-search-form" ] $ do
                                        "\n      "
                                        div_ [ class_ "input-holder global-search global-banner-search-box" ] $ do
                                            "\n        "
                                            input_ [ class_ "js-search-select", data_ "drop-class" "search-drop global-banner-search-box-drop", placeholder_ "What are you looking for?" ]
                                            "\n      "
                                        "\n    "
                                    "\n\n"
                                "\n          "
                            "\n        "
                        "\n"
                    "\n\n\n          "
                    div_ [ class_ "content-area-full-width description-section  ", style_ "background-image: url('//d1j3wd17d78ehn.cloudfront.net/system/images/000/103/870/802c16a6be8d3a1ccaf5cdf9e95a9c51/original/Who-we-are.jpg?1511279549'); background-repeat: no-repeat; background-size: cover;" ] $ div_ [ class_ "{}", style_ "background-color: transparent;color: rgb(76, 126, 77);" ] $ do
                        "\n            "
                        div_ [ class_ "content-area" ] $ do
                            "\n                "
                            div_ [ class_ "content-section section section-type-description", data_ "section-id" "25184", data_ "section-type" "description" ] $ do
                                "\n    "
                                div_ [ class_ "row" ] $ do
                                    "\n      "
                                    div_ [ class_ "col-xs-12" ] $ do
                                        "\n                  "
                                        h2_ [ class_ "section-title-side-lines", style_ "color: rgb(76, 126, 77)" ] $ do
                                            "\n      "
                                            span_ [ class_ "heading-decor" ] $ "\n        Who We Are\n      "
                                            "\n    "
                                        "\n\n\n        \n        "
                                        div_ [ class_ "content-holder image-align-bottom" ] $ do
                                            "\n\n            "
                                            div_ [ class_ "text-block no-image-block text-align-center" ] $ do
                                                "\n              "
                                                p_ $ do
                                                    "We are an organisation working in the field of Eco-tourism, from past eighteen years and stand tall, as a recognized name in the domain of "
                                                    strong_ "'Wildlife, "
                                                    strong_ "Adventure"
                                                    strong_ " and Trekking Holidays'"
                                                    " and have rendered lasting experiences to travel and wildlife enthusiasts, corporates and adventure dwellers of all ages."
                                                    br_ []
                                                    "\nBesides conducting "
                                                    strong_ "wildlife camps, adventure camps, trekking and offbeat tours in India"
                                                    ", we have been conducting trips to international destinations, right from "
                                                    strong_ "Arctic to Antarctica"
                                                    "; encompassing African Safaris to "
                                                    strong_ "Kenya, Tanzania, Botswana, Zimbabwe, Namibia and South Africa; Birding Tours to Bhutan, and Treks to Everest Base Camp and Annapurna Base Camp in Nepal.\160"
                                                    br_ []
                                                    "\nNow that you know what we do, it\8217s time for you to dive into the bag\160of memories\160we have scripted for you, and "
                                                    strong_ "Start Exploring!"
                                                "\n\n            "
                                            "\n\n        "
                                        "\n      "
                                    "\n    "
                                "\n\n"
                            "\n            "
                        "\n"
                    "          "
                    div_ [ class_ "content-area-full-width ", style_ "background-color: transparent;color: #333333;" ] $ do
                        "\n            "
                        div_ [ class_ "content-area" ] $ do
                            "\n               \n      "
                            div_ [ class_ "section section-type-promotional-offers", data_ "section-id" "25185", data_ "section-type" "promotional_offers" ] $ do
                                "\n        "
                                div_ [ class_ "slider init-slider coupon-slider count-2" ] $ do
                                    "\n          "
                                    div_ [ class_ "item coupon", data_ "coupon-id" "4623" ] $ do
                                        "\n  "
                                        a_ [ href_ "http://www.foliageoutdoors.com/coupon/save-rs-3000-by-booking-four-months-in-advance", class_ "coupon-page-link", title_ "Save Rs 3000 for camps by AC train - Coupon" ] $ do
                                            "\n\n    "
                                            toHtmlRaw  "<!-- Using lazy image loading -->"
                                            "\n    "
                                            div_ [ class_ "bg-cover-container b-lazy b-loading", data_ "src" "//d1j3wd17d78ehn.cloudfront.net/system/images/000/105/083/a1f910e1f5af68b52aaf4901f2d8791f/list_wide/newsearlybird1.jpg?1511509350", title_ "Save Rs 3000 for camps by AC train - Coupon" ] $ ""
                                            "\n\n    "
                                            div_ [ class_ "black-50-overlay" ] $ ""
                                            "\n    "
                                            div_ [ class_ "content-wrapper" ] $ do
                                                "\n      "
                                                div_ [ class_ "coupon-code-container" ] $ do
                                                    "\n        "
                                                    div_ [ class_ "code-use small-text" ] $ "Use coupon code"
                                                    "\n        "
                                                    div_ [ class_ "coupon-code-badge coupon-code-badge-small" ] $ do
                                                        "\n            "
                                                        div_ [ class_ "coupon-code" ] $ "EARLYBIRDDISCOUNT"
                                                        "\n        "
                                                    "\n      "
                                                "\n\n      "
                                                div_ [ class_ "coupon-description" ] $ do
                                                    "\n        "
                                                    div_ [ class_ "h2 discount_basis" ] $ "Save Rs 3000 for camps by AC train"
                                                    "\n        "
                                                    toHtmlRaw  "<!--  (section.coupons.length == 1 ) -->"
                                                    "\n      "
                                                "\n\n    "
                                            "\n"
                                        "\n"
                                    "\n          "
                                    div_ [ class_ "item coupon", data_ "coupon-id" "5164" ] $ do
                                        "\n  "
                                        a_ [ href_ "http://www.foliageoutdoors.com/coupon/register-in-a-group-of-8-students-or-more-and-avail-group-discount-rs-1000-per-student", class_ "coupon-page-link", title_ "Group of 8 or more & Save Rs 1000 - Coupon" ] $ do
                                            "\n\n    "
                                            toHtmlRaw  "<!-- Using lazy image loading -->"
                                            "\n    "
                                            div_ [ class_ "bg-cover-container b-lazy b-loading", data_ "src" "//d1j3wd17d78ehn.cloudfront.net/system/images/000/105/100/945bdc2213c244a18590eb408b3527e5/list_wide/freedom-307791_960_720.png?1511510314", title_ "Group of 8 or more & Save Rs 1000 - Coupon" ] $ ""
                                            "\n\n    "
                                            div_ [ class_ "black-50-overlay" ] $ ""
                                            "\n    "
                                            div_ [ class_ "content-wrapper" ] $ do
                                                "\n      "
                                                div_ [ class_ "coupon-code-container" ] $ do
                                                    "\n        "
                                                    div_ [ class_ "code-use small-text" ] $ "Use coupon code"
                                                    "\n        "
                                                    div_ [ class_ "coupon-code-badge coupon-code-badge-small" ] $ do
                                                        "\n            "
                                                        div_ [ class_ "coupon-code" ] $ "GROUPOF8"
                                                        "\n        "
                                                    "\n      "
                                                "\n\n      "
                                                div_ [ class_ "coupon-description" ] $ do
                                                    "\n        "
                                                    div_ [ class_ "h2 discount_basis" ] $ "Group of 8 or more & Save Rs 1000"
                                                    "\n        "
                                                    toHtmlRaw  "<!--  (section.coupons.length == 1 ) -->"
                                                    "\n      "
                                                "\n\n    "
                                            "\n"
                                        "\n"
                                    "\n        "
                                "\n"
                            "\n\n            "
                        "\n"
                    "          "
                    div_ [ class_ "content-area-full-width tour-cards-container ", style_ "background-color: transparent;color: rgb(76, 126, 77);" ] $ do
                        "\n            "
                        div_ [ class_ "content-area" ] $ "\n              \n            "
                        "\n"
                    "          "
                    div_ [ class_ "content-area-full-width collection-cards-container ", style_ "background-color: transparent;color: rgb(76, 126, 77);" ] $ do
                        "\n            "
                        div_ [ class_ "content-area" ] $ do
                            "\n                    "
                            div_ [ class_ "section section-type-activities-we-provide", data_ "section-id" "25187", data_ "section-type" "activities_we_provide" ] $ do
                                "\n              "
                                h2_ [ class_ "section-title-side-lines", style_ "color: rgb(76, 126, 77)" ] $ do
                                    "\n      "
                                    span_ [ class_ "heading-decor" ] $ "\n        Start Exploring !!!\n      "
                                    "\n    "
                                "\n\n\n\n    "
                                div_ [ class_ "content count-8" ] $ do
                                    "\n        "
                                    div_ [ class_ "collection collection-1", data_ "collection-id" "4106" ] $ do
                                        "\n          "
                                        a_ [ href_ "/collections/upcoming-tours", class_ "collection-href", title_ "Upcoming Tours - Collection" ] $ do
                                            "\n            "
                                            toHtmlRaw  "<!-- Using lazy image loading -->"
                                            "\n            "
                                            div_ [ class_ "bg-cover-container b-lazy b-loading", data_ "src" "//d1j3wd17d78ehn.cloudfront.net/system/images/000/104/776/24923cbdd6c4cf5914ed53fa2883c00f/list_wide/f818d1ba-0da8-4a9f-a485-17a86a54a1b4.jpg?1511774995", title_ "Upcoming Tours - Collection" ] $ ""
                                            "\n\n              "
                                            div_ [ class_ "image-gradient-overlay" ] $ ""
                                            "\n\n            "
                                            div_ [ class_ "collection-content" ] $ do
                                                "\n              "
                                                div_ [ class_ "h3 title truncatable" ] $ "Upcoming Tours"
                                                "\n              "
                                                div_ [ class_ "content-group" ] $ do
                                                    "\n                "
                                                    div_ [ class_ "collection-desc" ] $ do
                                                        "\n                  "
                                                        div_ [ class_ "tours" ] $ do
                                                            "\n                    "
                                                            span_ [ class_ "small-text" ] $ "Tours"
                                                            "\n                    "
                                                            span_ [ class_ "h3 tour-count" ] $ "71"
                                                            "\n                  "
                                                        "\n                  "
                                                        div_ [ class_ "pricing" ] $ do
                                                            "\n                    "
                                                            span_ [ class_ "small-text" ] $ "Starting from"
                                                            "\n                    "
                                                            span_ [ class_ "h3 price" ] $ "\8377 3"
                                                            "\n                  "
                                                        "\n                "
                                                    "\n                "
                                                    div_ [ class_ "outline-button hidden-xs hidden-sm" ] $ "View tours"
                                                    "\n              "
                                                "\n            "
                                            "\n"
                                        "        "
                                    "\n        "
                                    div_ [ class_ "collection collection-2", data_ "collection-id" "4991" ] $ do
                                        "\n          "
                                        a_ [ href_ "/collections/adventure-camps-and-treks-10-16-years", class_ "collection-href", title_ "Adventure Camps and Treks (10-16 years) - Collection" ] $ do
                                            "\n            "
                                            toHtmlRaw  "<!-- Using lazy image loading -->"
                                            "\n            "
                                            div_ [ class_ "bg-cover-container b-lazy b-loading", data_ "src" "//d1j3wd17d78ehn.cloudfront.net/system/images/000/101/601/fee99eeccee9b0915d637289e3544028/list_wide/Adventure_Camps.JPG?1511273761", title_ "Adventure Camps and Treks (10-16 years) - Collection" ] $ ""
                                            "\n\n              "
                                            div_ [ class_ "image-gradient-overlay" ] $ ""
                                            "\n\n            "
                                            div_ [ class_ "collection-content" ] $ do
                                                "\n              "
                                                div_ [ class_ "h3 title truncatable" ] $ "Adventure Camps and Treks (10-16 years)"
                                                "\n              "
                                                div_ [ class_ "content-group" ] $ do
                                                    "\n                "
                                                    div_ [ class_ "collection-desc" ] $ do
                                                        "\n                  "
                                                        div_ [ class_ "tours" ] $ do
                                                            "\n                    "
                                                            span_ [ class_ "small-text" ] $ "Tours"
                                                            "\n                    "
                                                            span_ [ class_ "h3 tour-count" ] $ "6"
                                                            "\n                  "
                                                        "\n                  "
                                                        div_ [ class_ "pricing" ] $ do
                                                            "\n                    "
                                                            span_ [ class_ "small-text" ] $ "Starting from"
                                                            "\n                    "
                                                            span_ [ class_ "h3 price" ] $ "\8377 18,900"
                                                            "\n                  "
                                                        "\n                "
                                                    "\n                "
                                                    div_ [ class_ "outline-button hidden-xs hidden-sm" ] $ "View tours"
                                                    "\n              "
                                                "\n            "
                                            "\n"
                                        "        "
                                    "\n        "
                                    div_ [ class_ "collection collection-3", data_ "collection-id" "5028" ] $ do
                                        "\n          "
                                        a_ [ href_ "/collections/adventure-camps-and-treks-14-18-years", class_ "collection-href", title_ "Adventure Camps and Treks (14-18 years) - Collection" ] $ do
                                            "\n            "
                                            toHtmlRaw  "<!-- Using lazy image loading -->"
                                            "\n            "
                                            div_ [ class_ "bg-cover-container b-lazy b-loading", data_ "src" "//d1j3wd17d78ehn.cloudfront.net/system/images/000/102/864/104f2b0b4678038fd0cfaf9b5891e17f/list_wide/DSC_0138.JPG?1511273762", title_ "Adventure Camps and Treks (14-18 years) - Collection" ] $ ""
                                            "\n\n              "
                                            div_ [ class_ "image-gradient-overlay" ] $ ""
                                            "\n\n            "
                                            div_ [ class_ "collection-content" ] $ do
                                                "\n              "
                                                div_ [ class_ "h3 title truncatable" ] $ "Adventure Camps and Treks (14-18 years)"
                                                "\n              "
                                                div_ [ class_ "content-group" ] $ do
                                                    "\n                "
                                                    div_ [ class_ "collection-desc" ] $ do
                                                        "\n                  "
                                                        div_ [ class_ "tours" ] $ do
                                                            "\n                    "
                                                            span_ [ class_ "small-text" ] $ "Tours"
                                                            "\n                    "
                                                            span_ [ class_ "h3 tour-count" ] $ "7"
                                                            "\n                  "
                                                        "\n                  "
                                                        div_ [ class_ "pricing" ] $ do
                                                            "\n                    "
                                                            span_ [ class_ "small-text" ] $ "Starting from"
                                                            "\n                    "
                                                            span_ [ class_ "h3 price" ] $ "\8377 27,400"
                                                            "\n                  "
                                                        "\n                "
                                                    "\n                "
                                                    div_ [ class_ "outline-button hidden-xs hidden-sm" ] $ "View tours"
                                                    "\n              "
                                                "\n            "
                                            "\n"
                                        "        "
                                    "\n        "
                                    div_ [ class_ "collection collection-4", data_ "collection-id" "4416" ] $ do
                                        "\n          "
                                        a_ [ href_ "/collections/wildlife-camps-10-16-years", class_ "collection-href", title_ "Wildlife Camps (10-16 years) - Collection" ] $ do
                                            "\n            "
                                            toHtmlRaw  "<!-- Using lazy image loading -->"
                                            "\n            "
                                            div_ [ class_ "bg-cover-container b-lazy b-loading", data_ "src" "//d1j3wd17d78ehn.cloudfront.net/system/images/000/105/859/2711997bb6dc9fc24139ec5b0290140f/list_wide/001Kanha_Banner_image.JPG?1511776571", title_ "Wildlife Camps (10-16 years) - Collection" ] $ ""
                                            "\n\n              "
                                            div_ [ class_ "image-gradient-overlay" ] $ ""
                                            "\n\n            "
                                            div_ [ class_ "collection-content" ] $ do
                                                "\n              "
                                                div_ [ class_ "h3 title truncatable" ] $ "Wildlife Camps (10-16 years)"
                                                "\n              "
                                                div_ [ class_ "content-group" ] $ do
                                                    "\n                "
                                                    div_ [ class_ "collection-desc" ] $ do
                                                        "\n                  "
                                                        div_ [ class_ "tours" ] $ do
                                                            "\n                    "
                                                            span_ [ class_ "small-text" ] $ "Tours"
                                                            "\n                    "
                                                            span_ [ class_ "h3 tour-count" ] $ "11"
                                                            "\n                  "
                                                        "\n                  "
                                                        div_ [ class_ "pricing" ] $ do
                                                            "\n                    "
                                                            span_ [ class_ "small-text" ] $ "Starting from"
                                                            "\n                    "
                                                            span_ [ class_ "h3 price" ] $ "\8377 19,600"
                                                            "\n                  "
                                                        "\n                "
                                                    "\n                "
                                                    div_ [ class_ "outline-button hidden-xs hidden-sm" ] $ "View tours"
                                                    "\n              "
                                                "\n            "
                                            "\n"
                                        "        "
                                    "\n        "
                                    div_ [ class_ "collection collection-5", data_ "collection-id" "4108" ] $ do
                                        "\n          "
                                        a_ [ href_ "/collections/kids-camps", class_ "collection-href", title_ "Kids' Camps (8-12 years) - Collection" ] $ do
                                            "\n            "
                                            toHtmlRaw  "<!-- Using lazy image loading -->"
                                            "\n            "
                                            div_ [ class_ "bg-cover-container b-lazy b-loading", data_ "src" "//d1j3wd17d78ehn.cloudfront.net/system/images/000/098/704/a4cefe61174e361e18e8de4e951ec562/list_wide/Rajgad_base_Camp_170417IMG_4682.jpg?1510054355", title_ "Kids' Camps (8-12 years) - Collection" ] $ ""
                                            "\n\n              "
                                            div_ [ class_ "image-gradient-overlay" ] $ ""
                                            "\n\n            "
                                            div_ [ class_ "collection-content" ] $ do
                                                "\n              "
                                                div_ [ class_ "h3 title truncatable" ] $ "Kids' Camps (8-12 years)"
                                                "\n              "
                                                div_ [ class_ "content-group" ] $ do
                                                    "\n                "
                                                    div_ [ class_ "collection-desc" ] $ do
                                                        "\n                  "
                                                        div_ [ class_ "tours" ] $ do
                                                            "\n                    "
                                                            span_ [ class_ "small-text" ] $ "Tours"
                                                            "\n                    "
                                                            span_ [ class_ "h3 tour-count" ] $ "10"
                                                            "\n                  "
                                                        "\n                  "
                                                        div_ [ class_ "pricing" ] $ do
                                                            "\n                    "
                                                            span_ [ class_ "small-text" ] $ "Starting from"
                                                            "\n                    "
                                                            span_ [ class_ "h3 price" ] $ "\8377 5,800"
                                                            "\n                  "
                                                        "\n                "
                                                    "\n                "
                                                    div_ [ class_ "outline-button hidden-xs hidden-sm" ] $ "View tours"
                                                    "\n              "
                                                "\n            "
                                            "\n"
                                        "        "
                                    "\n        "
                                    div_ [ class_ "collection collection-6", data_ "collection-id" "4437" ] $ do
                                        "\n          "
                                        a_ [ href_ "/collections/international-tours", class_ "collection-href", title_ "International Tours - Collection" ] $ do
                                            "\n            "
                                            toHtmlRaw  "<!-- Using lazy image loading -->"
                                            "\n            "
                                            div_ [ class_ "bg-cover-container b-lazy b-loading", data_ "src" "//d1j3wd17d78ehn.cloudfront.net/system/images/000/105/286/759ac1162a1bb1a0f107ffc8e9244ce9/list_wide/IMG_8610a.JPG?1511774995", title_ "International Tours - Collection" ] $ ""
                                            "\n\n              "
                                            div_ [ class_ "image-gradient-overlay" ] $ ""
                                            "\n\n            "
                                            div_ [ class_ "collection-content" ] $ do
                                                "\n              "
                                                div_ [ class_ "h3 title truncatable" ] $ "International Tours"
                                                "\n              "
                                                div_ [ class_ "content-group" ] $ do
                                                    "\n                "
                                                    div_ [ class_ "collection-desc" ] $ do
                                                        "\n                  "
                                                        div_ [ class_ "tours" ] $ do
                                                            "\n                    "
                                                            span_ [ class_ "small-text" ] $ "Tours"
                                                            "\n                    "
                                                            span_ [ class_ "h3 tour-count" ] $ "7"
                                                            "\n                  "
                                                        "\n                  "
                                                        div_ [ class_ "pricing" ] $ do
                                                            "\n                    "
                                                            span_ [ class_ "small-text" ] $ "Starting from"
                                                            "\n                    "
                                                            span_ [ class_ "h3 price" ] $ "\8377 52,000"
                                                            "\n                  "
                                                        "\n                "
                                                    "\n                "
                                                    div_ [ class_ "outline-button hidden-xs hidden-sm" ] $ "View tours"
                                                    "\n              "
                                                "\n            "
                                            "\n"
                                        "        "
                                    "\n        "
                                    div_ [ class_ "collection collection-7", data_ "collection-id" "4107" ] $ do
                                        "\n          "
                                        a_ [ href_ "/collections/wildlife-tours", class_ "collection-href", title_ "Wildlife Tours for All Ages - Collection" ] $ do
                                            "\n            "
                                            toHtmlRaw  "<!-- Using lazy image loading -->"
                                            "\n            "
                                            div_ [ class_ "bg-cover-container b-lazy b-loading", data_ "src" "//d1j3wd17d78ehn.cloudfront.net/system/images/000/102/868/3493203e64043683a4ca7789c0942f35/list_wide/IMG_1928aa.jpg?1511273763", title_ "Wildlife Tours for All Ages - Collection" ] $ ""
                                            "\n\n              "
                                            div_ [ class_ "image-gradient-overlay" ] $ ""
                                            "\n\n            "
                                            div_ [ class_ "collection-content" ] $ do
                                                "\n              "
                                                div_ [ class_ "h3 title truncatable" ] $ "Wildlife Tours for All Ages"
                                                "\n              "
                                                div_ [ class_ "content-group" ] $ do
                                                    "\n                "
                                                    div_ [ class_ "collection-desc" ] $ do
                                                        "\n                  "
                                                        div_ [ class_ "tours" ] $ do
                                                            "\n                    "
                                                            span_ [ class_ "small-text" ] $ "Tours"
                                                            "\n                    "
                                                            span_ [ class_ "h3 tour-count" ] $ "11"
                                                            "\n                  "
                                                        "\n                  "
                                                        div_ [ class_ "pricing" ] $ do
                                                            "\n                    "
                                                            span_ [ class_ "small-text" ] $ "Starting from"
                                                            "\n                    "
                                                            span_ [ class_ "h3 price" ] $ "\8377 23,000"
                                                            "\n                  "
                                                        "\n                "
                                                    "\n                "
                                                    div_ [ class_ "outline-button hidden-xs hidden-sm" ] $ "View tours"
                                                    "\n              "
                                                "\n            "
                                            "\n"
                                        "        "
                                    "\n        "
                                    div_ [ class_ "collection collection-8", data_ "collection-id" "5490" ] $ do
                                        "\n          "
                                        a_ [ href_ "/collections/treks-and-leisure-treks", class_ "collection-href", title_ "Treks and Leisure Treks for All Ages - Collection" ] $ do
                                            "\n            "
                                            toHtmlRaw  "<!-- Using lazy image loading -->"
                                            "\n            "
                                            div_ [ class_ "bg-cover-container b-lazy b-loading", data_ "src" "//d1j3wd17d78ehn.cloudfront.net/system/images/000/109/566/d44a5626e9cba2631b6a6133fd06ae73/list_wide/IMG_0539.JPG?1512639103", title_ "Treks and Leisure Treks for All Ages - Collection" ] $ ""
                                            "\n\n              "
                                            div_ [ class_ "image-gradient-overlay" ] $ ""
                                            "\n\n            "
                                            div_ [ class_ "collection-content" ] $ do
                                                "\n              "
                                                div_ [ class_ "h3 title truncatable" ] $ "Treks and Leisure Treks for All Ages"
                                                "\n              "
                                                div_ [ class_ "content-group" ] $ do
                                                    "\n                "
                                                    div_ [ class_ "collection-desc" ] $ do
                                                        "\n                  "
                                                        div_ [ class_ "tours" ] $ do
                                                            "\n                    "
                                                            span_ [ class_ "small-text" ] $ "Tours"
                                                            "\n                    "
                                                            span_ [ class_ "h3 tour-count" ] $ "7"
                                                            "\n                  "
                                                        "\n                  "
                                                        div_ [ class_ "pricing" ] $ do
                                                            "\n                    "
                                                            span_ [ class_ "small-text" ] $ "Starting from"
                                                            "\n                    "
                                                            span_ [ class_ "h3 price" ] $ "\8377 29,400"
                                                            "\n                  "
                                                        "\n                "
                                                    "\n                "
                                                    div_ [ class_ "outline-button hidden-xs hidden-sm" ] $ "View tours"
                                                    "\n              "
                                                "\n            "
                                            "\n"
                                        "        "
                                    "\n    "
                                "\n    \n"
                            "\n\n            "
                        "\n"
                    "          "
                    div_ [ class_ "content-area-full-width facebook-widget-container ", style_ "background-image: url('//d1j3wd17d78ehn.cloudfront.net/system/images/000/103/861/76d2d13e5727a226a7cc96fc3a0e1dea/original/Foliage-Outdoors-Facebook01.jpg?1511276487'); background-repeat: no-repeat; background-size: cover;" ] $ div_ [ class_ "{}", style_ "background-color: transparent;color: #FFFFFF;" ] $ do
                        "\n            "
                        div_ [ class_ "content-area" ] $ do
                            "\n                "
                            div_ [ class_ "section section-type-facebook-widget right-iframe", data_ "section-id" "25189", data_ "section-type" "facebook_widget" ] $ do
                                "\n    "
                                div_ [ class_ "row" ] $ do
                                    "\n      "
                                    div_ [ class_ "col-xs-12" ] $ do
                                        "\n        "
                                        div_ [ class_ "social-holder" ] $ do
                                            "\n          "
                                            div_ [ class_ "text-block" ] $ do
                                                "\n                      "
                                                h2_ [ class_ "section-title-side-lines", style_ "color: #FFFFFF" ] $ do
                                                    "\n      "
                                                    span_ [ class_ "heading-decor" ] $ "\n        See what we've been upto!\n      "
                                                    "\n    "
                                                "\n\n\n          "
                                            "\n          "
                                            div_ [ class_ "iframe-block" ] $ do
                                                "\n            "
                                                div_ [ class_ "iframe-holder" ] $ do
                                                    "\n                "
                                                    div_ [ class_ "facebook-iframe" ] $ do
                                                        "\n                  "
                                                        div_ [ class_ "fb-page", data_ "href" "https://www.facebook.com/Foliagers/", data_ "tabs" "timeline", data_ "width" "468", data_ "height" "409", data_ "small-header" "false", data_ "adapt-container-width" "true", data_ "hide-cover" "false", data_ "show-facepile" "true" ] $ div_ [ class_ "fb-xfbml-parse-ignore" ] $ blockquote_ [ cite_ "https://www.facebook.com/Foliagers/" ] $ a_ [ href_ "https://www.facebook.com/Foliagers/", rel_ "nofollow", title_ "facebook-widget" ] $ ""
                                                        "\n                "
                                                    "\n              "
                                                    div_ [ class_ "facebook-dummy" ] $ do
                                                        "\n                "
                                                        img_ [ alt_ "facebook-dummy-pic", class_ "facebook-dummy-pic", src_ "//d1j3wd17d78ehn.cloudfront.net/assets/fb-dummy-6f458d5395040512781149c636a617d5.png", title_ "facebook-dummy-pic" ]
                                                        "\n              "
                                                    "\n            "
                                                "\n          "
                                            "\n        "
                                        "\n      "
                                    "\n    "
                                "\n"
                            "\n            "
                        "\n"
                    "          "
                    div_ [ class_ "content-area-full-width homepage-accreditations-container ", style_ "background-color: transparent;color: rgb(76, 126, 77);" ] $ do
                        "\n            "
                        div_ [ class_ "content-area" ] $ do
                            "\n                "
                            div_ [ class_ "section section-type-accreditations", data_ "section-id" "25191", data_ "section-type" "accreditations" ] $ do
                                "\n              "
                                h2_ [ class_ "section-title-side-lines", style_ "color: rgb(76, 126, 77)" ] $ do
                                    "\n      "
                                    span_ [ class_ "heading-decor" ] $ "\n        Recognised By\n      "
                                    "\n    "
                                "\n\n\n    "
                                div_ [ class_ "content logo-list count-4 " ] $ do
                                    "\n        "
                                    div_ [ class_ "logo-item" ] $ do
                                        "\n              "
                                        img_ [ alt_ "ATOAI_Logo.jpg - logo", class_ "logo", src_ "//d1j3wd17d78ehn.cloudfront.net/system/images/000/085/850/5e338399c64fcc4223c28f1ec9b806e4/website_logo/ATOAI_Logo.jpg?1505468648", title_ "ATOAI_Logo.jpg - logo" ]
                                        "\n        "
                                    "\n\n        "
                                    div_ [ class_ "logo-item" ] $ do
                                        "\n              "
                                        img_ [ alt_ "ATOM_Logo.jpg - logo", class_ "logo", src_ "//d1j3wd17d78ehn.cloudfront.net/system/images/000/085/851/2add5dc92cc5ade99cbd4d5a107b7b45/website_logo/ATOM_Logo.jpg?1505468648", title_ "ATOM_Logo.jpg - logo" ]
                                        "\n        "
                                    "\n          "
                                    div_ [ class_ "clearfix visible-xs  " ] $ ""
                                    "\n\n        "
                                    div_ [ class_ "logo-item" ] $ do
                                        "\n              "
                                        img_ [ alt_ "Ministry-of-tourism-_Govt_of_INDIA.png - logo", class_ "logo", src_ "//d1j3wd17d78ehn.cloudfront.net/system/images/000/085/854/9b179f96fe8306e1c7571a39839a461e/website_logo/Ministry-of-tourism-_Govt_of_INDIA.png?1505468647", title_ "Ministry-of-tourism-_Govt_of_INDIA.png - logo" ]
                                        "\n        "
                                    "\n          "
                                    div_ [ class_ "clearfix visible-sm" ] $ ""
                                    "\n\n        "
                                    div_ [ class_ "logo-item" ] $ do
                                        "\n              "
                                        img_ [ alt_ "IMF_Logo_new.jpg - logo", class_ "logo", src_ "//d1j3wd17d78ehn.cloudfront.net/system/images/000/085/855/b98badfd55de6f6ec4446e6ae6181630/website_logo/IMF_Logo_new.jpg?1505468864", title_ "IMF_Logo_new.jpg - logo" ]
                                        "\n        "
                                    "\n          "
                                    div_ [ class_ "clearfix visible-xs  visible-lg visible-md " ] $ ""
                                    "\n\n    "
                                "\n"
                            "\n            "
                        "\n"
                "\n"
            "\n\n    "
            div_ [ class_ "footer-container footer-multi-column" ] $ do
                "\n  "
                div_ [ class_ "content-area footer " ] $ do
                    "\n        "
                    div_ [ class_ "clearfix widgets count-5" ] $ do
                        "\n              "
                        div_ [ class_ "widget" ] $ do
                            "\n                "
                            div_ [ class_ "secondary-section-title title" ] $ "\n                  Company Info\n                "
                            "\n                "
                            div_ [ class_ "content" ] $ do
                                "\n                    "
                                ul_ $ do
                                    "\n                        "
                                    li_ $ a_ [ href_ "/who-we-are", target_ "_self", title_ "About Us" ] $ "About Us"
                                    "\n                        "
                                    li_ $ a_ [ href_ "/contact-us", target_ "_self", title_ "Contact Us" ] $ "Contact Us"
                                    "\n                        "
                                    li_ $ a_ [ href_ "/terms-and-conditions", target_ "_self", title_ "Cancellation Policy" ] $ "Cancellation Policy"
                                    "\n                        "
                                    li_ $ a_ [ href_ "/privacy-policy", target_ "_self", title_ "Privacy Policy" ] $ "Privacy Policy"
                                    "\n                        "
                                    li_ $ a_ [ href_ "/sitemap", target_ "_self", title_ "Sitemap" ] $ "Sitemap"
                                    "\n                    "
                                "\n                "
                            "\n              "
                        "\n              "
                        div_ [ class_ "widget" ] $ do
                            "\n                "
                            div_ [ class_ "secondary-section-title title" ] $ "\n                  Our Tours\n                "
                            "\n                "
                            div_ [ class_ "content" ] $ do
                                "\n                    "
                                ul_ $ do
                                    "\n                        "
                                    li_ $ a_ [ href_ "/collections/upcoming-tours", target_ "_blank", title_ "Upcoming Tours" ] $ "Upcoming Tours"
                                    "\n                        "
                                    li_ $ a_ [ href_ "/collections/adventure-camps-and-treks-10-16-years", target_ "_blank", title_ "Adventure Camps and Treks (10-16 years)" ] $ "Adventure Camps and Treks (10-16 years)"
                                    "\n                        "
                                    li_ $ a_ [ href_ "/collections/adventure-camps-and-treks-14-18-years", target_ "_self", title_ "Adventure Camps and Treks (14-18 years)" ] $ "Adventure Camps and Treks (14-18 years)"
                                    "\n                        "
                                    li_ $ a_ [ href_ "/collections/kids-camps", target_ "_self", title_ "Kids' Camps (8-12 years)" ] $ "Kids' Camps (8-12 years)"
                                    "\n                        "
                                    li_ $ a_ [ href_ "/collections/wildlife-camps-10-16-years", target_ "_blank", title_ "Wildlife Camps (10-16 years)" ] $ "Wildlife Camps (10-16 years)"
                                    "\n                        "
                                    li_ $ a_ [ href_ "/collections/youthcamps", target_ "_self", title_ "Youth Camps (18-22 years)" ] $ "Youth Camps (18-22 years)"
                                    "\n                        "
                                    li_ $ a_ [ href_ "/collections/international-tours", target_ "_blank", title_ "International Tours" ] $ "International Tours"
                                    "\n                        "
                                    li_ $ a_ [ href_ "/collections/wildlife-tours", target_ "_blank", title_ "Wildlife Tours for All Ages" ] $ "Wildlife Tours for All Ages"
                                    "\n                    "
                                "\n                "
                            "\n              "
                        "\n                "
                        div_ [ class_ "clearfix visible-xs visible-sm" ] $ ""
                        "\n              "
                        div_ [ class_ "widget" ] $ do
                            "\n                "
                            div_ [ class_ "secondary-section-title title" ] $ "\n                  Address\n                "
                            "\n                "
                            div_ [ class_ "content" ] $ do
                                "\n                    "
                                p_ $ strong_ "Kothrud Office"
                                "\n\n"
                                p_ $ do
                                    "103, Mahadkar Chambers, Karve Road,"
                                    br_ []
                                    "\nNear Kothrud McDonalds,"
                                    br_ []
                                    "\nKothrud, Pune 411038, India.\160"
                                    br_ []
                                    "\nReach us on: +912066447777"
                                "\n\n"
                                p_ "\160"
                                "\n\n"
                                p_ $ strong_ "Aundh Office"
                                "\n\n"
                                p_ $ do
                                    "Plot Number: A-1 (AB) Second Floor, Abhimanshree Society, Above Hotel Abhiman, Near B U Bhandari Showroom, Opp St Joseph School NCL - Pashan Road, Aundh, Pune 411008."
                                    br_ []
                                    "\nReach us on: +917276061111"
                                "\n\n                "
                            "\n              "
                        "\n          "
                        div_ [ class_ "widget default-footer-widget" ] $ do
                            "\n              "
                            div_ [ class_ "secondary-section-title title" ] $ "\n                Contact Us\n              "
                            "\n            "
                            div_ [ class_ "content" ] $ do
                                "\n              "
                                span_ "MON-SAT from 10AM-07PM and SUN from 11AM-07PM"
                                "\n\n            "
                                a_ [ href_ "mailto:info@foliageoutdoors.com", class_ "support-email skip-title-check" ] $ "info@foliageoutdoors.com"
                                "\n\n              "
                                a_ [ href_ "tel://+91 2066447777", class_ "support-phone skip-title-check" ] $ "+91 2066447777"
                                "\n\n                  "
                                a_ [ href_ "https://www.facebook.com/Foliagers/", rel_ "nofollow", target_ "_blank", title_ "facebook-social-media" ] $ do
                                    "\n    "
                                    div_ [ class_ "icon" ] $ do
                                        "\n      "
                                        div_ [ class_ "svg svg-facebook" ] $ do
                                            "\n\n  "
                                            toHtmlRaw  "<!-- <svg version=\"1.1\" id=\"Layer_1\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" x=\"0px\" y=\"0px\"\n     width=\"512px\" height=\"512px\" viewBox=\"0 0 512 512\" enable-background=\"new 0 0 512 512\" xml:space=\"preserve\">\n  <path fill=\"#FFFFFF\" d=\"M256,7.098C118.535,7.098,7.098,118.535,7.098,256S118.535,504.902,256,504.902\n    c1.78,0,3.554-0.03,5.326-0.067V340.734h-55.124V271.83h55.124v-41.343c0-56.764,32.041-96.467,82.687-96.467\n    c24.255,0,41.343,0,55.124,0v68.905h-27.562c-27.535,0-41.343,13.781-41.343,41.343v27.562h68.905l-13.781,68.904h-55.124v152.908\n    C431.44,462.061,504.902,367.611,504.902,256C504.902,118.535,393.465,7.098,256,7.098z\"/>\n  </svg>\n  -->"
                                            "\n\n"
                                        " Facebook\n    "
                                    "\n"
                                "\n                  "
                                a_ [ href_ "https://twitter.com/foliageoutdoors", rel_ "nofollow", target_ "_blank", title_ "twitter-social-media" ] $ do
                                    "\n    "
                                    div_ [ class_ "icon" ] $ do
                                        "\n      "
                                        div_ [ class_ "svg svg-twitter" ] $ do
                                            "\n  "
                                            toHtmlRaw  "<!-- <svg version=\"1.1\"\n     id=\"svg2\" xmlns:rdf=\"http://www.w3.org/1999/02/22-rdf-syntax-ns#\" xmlns:sodipodi=\"http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd\" xmlns:inkscape=\"http://www.inkscape.org/namespaces/inkscape\" xmlns:cc=\"http://creativecommons.org/ns#\" xmlns:dc=\"http://purl.org/dc/elements/1.1/\" xmlns:svg=\"http://www.w3.org/2000/svg\"\n     xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" x=\"0px\" y=\"0px\" width=\"500px\" height=\"500px\"\n     viewBox=\"0 0 500 500\" enable-background=\"new 0 0 500 500\" xml:space=\"preserve\">\n  <g id=\"layer1\" transform=\"translate(0,-552.36218)\">\n    <path fill=\"#FFFFFF\" d=\"M250,552.362c-69.04,0-131.54,27.98-176.78,73.22C27.98,670.822,0,733.322,0,802.362\n      s27.98,131.54,73.22,176.78c45.24,45.239,107.74,73.22,176.78,73.22s131.54-27.98,176.78-73.22\n      c45.239-45.24,73.22-107.74,73.22-176.78C500,664.292,388.071,552.362,250,552.362z M377.25,737.032c0.12,2.82,0.17,5.68,0.17,8.53\n      c0,86.76-66.03,186.8-186.8,186.8c-37.07,0-71.56-10.86-100.62-29.5c5.14,0.61,10.38,0.9,15.67,0.9\n      c30.77,0,59.04-10.49,81.5-28.101c-28.72-0.53-52.93-19.52-61.29-45.6c4,0.77,8.11,1.18,12.34,1.18c5.99,0,11.8-0.81,17.3-2.3\n      c-30.03-6.05-52.67-32.55-52.67-64.35c0-0.28-0.01-0.58,0-0.85c8.85,4.91,18.99,7.88,29.75,8.22\n      c-17.62-11.77-29.22-31.85-29.22-54.62c0-12.05,3.24-23.34,8.89-33.03c32.39,39.72,80.76,65.86,135.33,68.6\n      c-1.12-4.81-1.68-9.84-1.68-14.97c0-35.7,28.46-64.73,63.93-65.63c0.561-0.01,1.131,0,1.7,0c18.88,0,35.95,7.97,47.92,20.72\n      c14.96-2.94,29.021-8.42,41.7-15.94c-4.9,15.34-15.31,28.2-28.87,36.32c13.28-1.58,25.94-5.12,37.7-10.35\n      C401.2,716.232,390.071,727.802,377.25,737.032z\"/>\n    <g id=\"layer1-9\" transform=\"translate(-549.00515,80.294372)\">\n    </g>\n    <g id=\"layer1-6\" transform=\"translate(-575.71429,39.999999)\">\n    </g>\n    <g id=\"layer1-93\" transform=\"matrix(0.99928945,0,0,0.99928945,474.7002,-40.81928)\">\n    </g>\n  </g>\n  </svg>\n  -->"
                                            "\n"
                                        " Twitter\n    "
                                    "\n"
                                "\n              \n              \n              \n                  "
                                a_ [ href_ "https://www.youtube.com/user/foliageoutdoors/videos", rel_ "nofollow", target_ "_blank", title_ "youtube-social-media" ] $ do
                                    "\n    "
                                    div_ [ class_ "icon" ] $ do
                                        "\n      "
                                        div_ [ class_ "svg svg-youtube" ] $ do
                                            "\n  "
                                            toHtmlRaw  "<!-- <svg version=\"1.1\" id=\"Layer_1\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" x=\"0px\" y=\"0px\"\n     width=\"512px\" height=\"512px\" viewBox=\"0 0 512 512\" enable-background=\"new 0 0 512 512\" xml:space=\"preserve\">\n  <g>\n    <polygon fill=\"#FFFFFF\" points=\"217.949,313.148 313.196,256 217.949,198.851   \"/>\n    <path fill=\"#FFFFFF\" d=\"M256,7.098C118.535,7.098,7.098,118.535,7.098,256S118.535,504.902,256,504.902\n      S504.902,393.465,504.902,256S393.465,7.098,256,7.098z M408.349,268.287c0,26.307-3.048,52.605-3.048,52.605\n      s-2.981,22.401-12.106,32.25c-11.592,12.936-24.574,13.012-30.526,13.773C320.026,370.184,256,370.297,256,370.297\n      s-79.228-0.771-103.602-3.268c-6.781-1.353-21.993-0.961-33.594-13.896c-9.134-9.849-12.105-32.251-12.105-32.251\n      s-3.049-26.289-3.049-52.604v-24.65c0-26.298,3.049-52.596,3.049-52.596s2.98-22.412,12.105-32.279\n      c11.601-12.935,24.574-13.011,30.527-13.744c42.633-3.305,106.592-3.305,106.592-3.305h0.143c0,0,63.959,0,106.602,3.305\n      c5.952,0.733,18.935,0.81,30.526,13.744c9.134,9.868,12.106,32.279,12.106,32.279s3.048,26.298,3.048,52.604V268.287\n      L408.349,268.287z\"/>\n  </g>\n  </svg>\n  -->"
                                            "\n\n"
                                        " Youtube\n    "
                                    "\n"
                                "\n            "
                            "\n          "
                        "\n        "
                    "\n  "
                "\n  "
                toHtmlRaw  "<!-- This is a Hacked Footer for Coorg Tour -->"
                "\n  "
                toHtmlRaw  "<!-- coorg tour footer end -->"
                "\n  "
                div_ [ class_ "copyright-container" ] $ do
                    "\n    "
                    div_ [ class_ "content-area" ] $ do
                        "\n      "
                        p_ [ class_ "copyright" ] $ do
                            "Online Booking system by "
                            a_ [ class_ "company test", target_ "_blank", rel_ "nofollow", href_ "http://www.vacationlabs.com", title_ "VacationLabs - Online booking engine for tours and travels" ] $ "VacationLabs"
                            " | \169 2017"
                            span_ [ class_ "company" ] $ " Foliage Outdoors "
                        "\n    "
                    "\n  "
                "\n\n"
            "\n\n  "
            div_ [ id_ "fb-root" ] $ ""
            "\n  "
            script_ "(function(d, s, id) {\n    var js, fjs = d.getElementsByTagName(s)[0];\n    if (d.getElementById(id)) return;\n    js = d.createElement(s); js.id = id;\n    js.src = \"//connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v2.5\";\n    fjs.parentNode.insertBefore(js, fjs);\n  }(document, 'script', 'facebook-jssdk'));"
            "\n\n"
            toHtmlRaw  "<!-- jQuery -->"
            "\n"
            script_ [ type_ "text/javascript", async_ "" ] $ "         var head = document.getElementsByTagName(\"head\")[0];\n        var link_tag = document.createElement(\"link\");\n        link_tag.rel = 'stylesheet';\n        link_tag.href = 'https://fonts.googleapis.com/css?family=Cabin:700,100,300,regular,600|Lato:300';\n        link_tag.media = 'none';\n        head.appendChild(link_tag, head.firstChild);\n        setTimeout(function () {\n          link_tag.media = 'all';\n        });\n "
            "\n\n"
            script_ [ async_ "async", src_ "//d1j3wd17d78ehn.cloudfront.net/assets/common/store_front/themes/flexi_theme/main-bce44e3dc83251a0cc55ee489df07d46.js", type_ "text/javascript" ] $ ""
            "\n\n"
            toHtmlRaw  "<!--Start of Tawk.to Script-->"
            "\n"
            script_ [ type_ "text/javascript" ] $ "\nvar Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();\n(function(){\nvar s1=document.createElement(\"script\"),s0=document.getElementsByTagName(\"script\")[0];\ns1.async=true;\ns1.src='https://embed.tawk.to/59b7cf384854b82732fef8cf/default';\ns1.charset='UTF-8';\ns1.setAttribute('crossorigin','*');\ns0.parentNode.insertBefore(s1,s0);\n})();\n"
            "\n"
            toHtmlRaw  "<!--End of Tawk.to Script-->"
            "\n\n\n"
        "\n"
    "\n\n"

