{-# LANGUAGE OverloadedStrings, ExtendedDefaultRules #-}

import Lucid
import Lucid.Supplemental
import System.IO (stdout, hSetEncoding, utf8)
import Data.Text.Lazy.IO as L

main :: IO ()
main = do
  hSetEncoding stdout utf8
  L.hPutStr stdout (renderText template1)


-- Template for file: tests/issue_7-attribs.html
template1 :: Html ()
template1 = do
    ul_ [ class_ "info-list list-unstyled" ] $ do
        "\n    "
        li_ $ do
            a_ [ href_ "tel://#{@client.support_phone}" ] $ do
                i_ [ class_ "fa fa-phone skip-title-check", ariaHidden_ "true" ] $ ""
                " +91 2066447777 "
        "\n    "
        li_ $ do
            a_ [ href_ "mailto:#{@client.support_email}" ] $ do
                i_ [ class_ "fa fa-envelope", ariaHidden_ "true" ] $ ""
                "info@foliageoutdoors.com"
        "\n"
    "\n"

