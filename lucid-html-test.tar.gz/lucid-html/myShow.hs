{-# LANGUAGE ScopedTypeVariables #-}

module MyShow where


myShow :: Show a => a -> String
myShow x = go (show x)
  where
    go :: String -> String
    go [] = []
    go s@(x:xs) = case x of
      '\"' -> '\"' : str ++ "\"" ++ go rest
      '\'' -> '\'' : char : '\'' : go rest'
      _    -> x : go xs
      where
        (str :: String, rest):_ = reads s
        (char :: Char, rest'):_ = reads s

