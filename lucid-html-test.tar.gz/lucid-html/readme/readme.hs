{-# LANGUAGE OverloadedStrings, ExtendedDefaultRules #-}

import Lucid
import Lucid.Supplemental
import System.IO (stdout)
import Data.Text.Lazy.IO as L

main :: IO ()
main = L.hPutStr stdout (renderText template1)

-- Template for file: readme.html
template1 :: Html ()
template1 = do
    "\n\n\n\n\n\n"
    doctype_
    "\n"
    html_ [ lang_ "en" ] $ do
        "\n  "
        head_ $ do
            "\n    "
            meta_ [ charset_ "utf-8" ]
            "\n  "
            link_ [ rel_ "dns-prefetch", href_ "https://assets-cdn.github.com" ]
            "\n  "
            link_ [ rel_ "dns-prefetch", href_ "https://avatars0.githubusercontent.com" ]
            "\n  "
            link_ [ rel_ "dns-prefetch", href_ "https://avatars1.githubusercontent.com" ]
            "\n  "
            link_ [ rel_ "dns-prefetch", href_ "https://avatars2.githubusercontent.com" ]
            "\n  "
            link_ [ rel_ "dns-prefetch", href_ "https://avatars3.githubusercontent.com" ]
            "\n  "
            link_ [ rel_ "dns-prefetch", href_ "https://github-cloud.s3.amazonaws.com" ]
            "\n  "
            link_ [ rel_ "dns-prefetch", href_ "https://user-images.githubusercontent.com/" ]
            "\n\n\n\n  "
            link_ [ crossorigin_ "anonymous", href_ "https://assets-cdn.github.com/assets/frameworks-1c2c316b7a17f15536c6a26ed744654fc228a24658a7ae395cdcbf8329c8406b.css", media_ "all", rel_ "stylesheet" ]
            "\n  "
            link_ [ crossorigin_ "anonymous", href_ "https://assets-cdn.github.com/assets/github-8100b9bf1eb6ed8b38eaad2fe7ba51d1895aa0602aafe4a87068d444e07e8c5c.css", media_ "all", rel_ "stylesheet" ]
            "\n  \n  \n  "
            link_ [ crossorigin_ "anonymous", href_ "https://assets-cdn.github.com/assets/site-44b6bba3881278f33c221b6526379b55fbd098af3e553f54e81cab4c9a517c8e.css", media_ "all", rel_ "stylesheet" ]
            "\n  \n\n  "
            meta_ [ name_ "viewport", content_ "width=device-width" ]
            "\n  \n  "
            title_ "lucid-from-html/README.md at master \183 alogic0/lucid-from-html \183 GitHub"
            "\n  "
            link_ [ rel_ "search", type_ "application/opensearchdescription+xml", href_ "/opensearch.xml", title_ "GitHub" ]
            "\n  "
            link_ [ rel_ "fluid-icon", href_ "https://github.com/fluidicon.png", title_ "GitHub" ]
            "\n  "
            meta_ [ property_ "fb:app_id", content_ "1401488693436528" ]
            "\n\n    \n    "
            meta_ [ content_ "https://avatars1.githubusercontent.com/u/446277?s=400&v=4", property_ "og:image" ]
            meta_ [ content_ "GitHub", property_ "og:site_name" ]
            meta_ [ content_ "object", property_ "og:type" ]
            meta_ [ content_ "alogic0/lucid-from-html", property_ "og:title" ]
            meta_ [ content_ "https://github.com/alogic0/lucid-from-html", property_ "og:url" ]
            meta_ [ content_ "lucid-from-html - Generate Lucid code from html page", property_ "og:description" ]
            "\n\n  "
            link_ [ rel_ "assets", href_ "https://assets-cdn.github.com/" ]
            "\n  \n  "
            meta_ [ name_ "pjax-timeout", content_ "1000" ]
            "\n  \n  "
            meta_ [ name_ "request-id", content_ "C964:4563:25B687F:4511B93:5A3D4163", data_ "pjax-transient" "" ]
            "\n  \n\n  "
            meta_ [ name_ "selected-link", value_ "repo_source", data_ "pjax-transient" "" ]
            "\n\n    "
            meta_ [ name_ "google-site-verification", content_ "KT5gs8h0wvaagLKAVWq8bbeNwnZZK1r1XQysX3xurLU" ]
            "\n  "
            meta_ [ name_ "google-site-verification", content_ "ZzhVyEFwb7w3e0-uOTltm8Jsck2F5StVihD0exw2fsA" ]
            "\n  "
            meta_ [ name_ "google-site-verification", content_ "GXs5KoUUkNCoaAZn7wPN-t01Pywp9M3sEjnt_3_ZWPc" ]
            "\n    "
            meta_ [ name_ "google-analytics", content_ "UA-3769691-2" ]
            "\n\n"
            meta_ [ content_ "collector.githubapp.com", name_ "octolytics-host" ]
            meta_ [ content_ "github", name_ "octolytics-app-id" ]
            meta_ [ content_ "https://collector.githubapp.com/github-external/browser_event", name_ "octolytics-event-url" ]
            meta_ [ content_ "C964:4563:25B687F:4511B93:5A3D4163", name_ "octolytics-dimension-request_id" ]
            meta_ [ content_ "iad", name_ "octolytics-dimension-region_edge" ]
            meta_ [ content_ "iad", name_ "octolytics-dimension-region_render" ]
            "\n"
            meta_ [ content_ "/<user-name>/<repo-name>/blob/show", data_ "pjax-transient" "true", name_ "analytics-location" ]
            "\n\n\n\n\n  "
            meta_ [ class_ "js-ga-set", name_ "dimension1", content_ "Logged Out" ]
            "\n\n\n  \n\n      "
            meta_ [ name_ "hostname", content_ "github.com" ]
            "\n  "
            meta_ [ name_ "user-login", content_ "" ]
            "\n\n      "
            meta_ [ name_ "expected-hostname", content_ "github.com" ]
            "\n    "
            meta_ [ name_ "js-proxy-site-detection-payload", content_ "OGNkMzQ5MDViYzI5YWFmZDdlYmE5ZmVmMDZlOTAyMTcyNTlhYmYzNGRiOWU2ZGJkMjA0ZjkxOWRjZGI4MmNkMXx7InJlbW90ZV9hZGRyZXNzIjoiMzcuMjAzLjI2LjE5NiIsInJlcXVlc3RfaWQiOiJDOTY0OjQ1NjM6MjVCNjg3Rjo0NTExQjkzOjVBM0Q0MTYzIiwidGltZXN0YW1wIjoxNTEzOTYzODc1LCJob3N0IjoiZ2l0aHViLmNvbSJ9" ]
            "\n\n\n  "
            meta_ [ name_ "html-safe-nonce", content_ "27f90ea286eb92857d6636f86c306bd7723bc06f" ]
            "\n\n  "
            meta_ [ httpEquiv_ "x-pjax-version", content_ "e6dbf537b2eb3990c0cae54500f32daf" ]
            "\n  \n\n      "
            link_ [ href_ "https://github.com/alogic0/lucid-from-html/commits/master.atom", rel_ "alternate", title_ "Recent Commits to lucid-from-html:master", type_ "application/atom+xml" ]
            "\n\n  "
            meta_ [ name_ "description", content_ "lucid-from-html - Generate Lucid code from html page" ]
            "\n  "
            meta_ [ name_ "go-import", content_ "github.com/alogic0/lucid-from-html git https://github.com/alogic0/lucid-from-html.git" ]
            "\n\n  "
            meta_ [ content_ "446277", name_ "octolytics-dimension-user_id" ]
            meta_ [ content_ "alogic0", name_ "octolytics-dimension-user_login" ]
            meta_ [ content_ "112899028", name_ "octolytics-dimension-repository_id" ]
            meta_ [ content_ "alogic0/lucid-from-html", name_ "octolytics-dimension-repository_nwo" ]
            meta_ [ content_ "true", name_ "octolytics-dimension-repository_public" ]
            meta_ [ content_ "true", name_ "octolytics-dimension-repository_is_fork" ]
            meta_ [ content_ "90380206", name_ "octolytics-dimension-repository_parent_id" ]
            meta_ [ content_ "dbaynard/lucid-from-html", name_ "octolytics-dimension-repository_parent_nwo" ]
            meta_ [ content_ "79511391", name_ "octolytics-dimension-repository_network_root_id" ]
            meta_ [ content_ "jaspervdj/blaze-from-html", name_ "octolytics-dimension-repository_network_root_nwo" ]
            meta_ [ content_ "false", name_ "octolytics-dimension-repository_explore_github_marketplace_ci_cta_shown" ]
            "\n\n\n    "
            link_ [ rel_ "canonical", href_ "https://github.com/alogic0/lucid-from-html/blob/master/README.md", data_ "pjax-transient" "" ]
            "\n\n\n  "
            meta_ [ name_ "browser-stats-url", content_ "https://api.github.com/_private/browser/stats" ]
            "\n\n  "
            meta_ [ name_ "browser-errors-url", content_ "https://api.github.com/_private/browser/errors" ]
            "\n\n  "
            link_ [ rel_ "mask-icon", href_ "https://assets-cdn.github.com/pinned-octocat.svg", color_ "#000000" ]
            "\n  "
            link_ [ rel_ "icon", type_ "image/x-icon", class_ "js-site-favicon", href_ "https://assets-cdn.github.com/favicon.ico" ]
            "\n\n"
            meta_ [ name_ "theme-color", content_ "#1e2327" ]
            "\n\n\n\n  "
        "\n\n  "
        body_ [ class_ "logged-out env-production page-blob" ] $ do
            "\n    \n\n  "
            div_ [ class_ "position-relative js-header-wrapper " ] $ do
                "\n    "
                a_ [ href_ "#start-of-content", tabindex_ "1", class_ "px-2 py-4 show-on-focus js-skip-to-content" ] $ "Skip to content"
                "\n    "
                div_ [ id_ "js-pjax-loader-bar", class_ "pjax-loader-bar" ] $ div_ [ class_ "progress" ] $ ""
                "\n\n    \n    \n    \n      \n\n\n\n        "
                header_ [ class_ "Header header-logged-out  position-relative f4 py-3", role_ "banner" ] $ do
                    "\n  "
                    div_ [ class_ "container-lg d-flex px-3" ] $ do
                        "\n    "
                        div_ [ class_ "d-flex flex-justify-between flex-items-center" ] $ do
                            "\n      "
                            a_ [ class_ "header-logo-invertocat my-0", href_ "https://github.com/", ariaLabel_ "Homepage", data_ "ga-click" "(Logged out) Header, go to homepage, icon:logo-wordmark" ] $ do
                                "\n        "
                                toHtmlRaw  "<!-- <svg aria-hidden=\"true\" class=\"octicon octicon-mark-github\" height=\"32\" version=\"1.1\" viewBox=\"0 0 16 16\" width=\"32\"><path fill-rule=\"evenodd\" d=\"M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.013 8.013 0 0 0 16 8c0-4.42-3.58-8-8-8z\"/></svg>\n        -->"
                                "\n      "
                            "\n\n    "
                        "\n\n    "
                        div_ [ class_ "HeaderMenu HeaderMenu--bright d-flex flex-justify-between flex-auto" ] $ do
                            "\n        "
                            nav_ [ class_ "mt-0" ] $ do
                                "\n          "
                                ul_ [ class_ "d-flex list-style-none" ] $ do
                                    "\n              "
                                    li_ [ class_ "ml-2" ] $ do
                                        "\n                "
                                        a_ [ href_ "/features", class_ "js-selected-navigation-item HeaderNavlink px-0 py-2 m-0", data_ "ga-click" "Header, click, Nav menu - item:features", data_ "selected-links" "/features /features/project-management /features/code-review /features/project-management /features/integrations /features" ] $ "\n                  Features\n"
                                        "              "
                                    "\n              "
                                    li_ [ class_ "ml-4" ] $ do
                                        "\n                "
                                        a_ [ href_ "/business", class_ "js-selected-navigation-item HeaderNavlink px-0 py-2 m-0", data_ "ga-click" "Header, click, Nav menu - item:business", data_ "selected-links" "/business /business/security /business/customers /business" ] $ "\n                  Business\n"
                                        "              "
                                    "\n\n              "
                                    li_ [ class_ "ml-4" ] $ do
                                        "\n                "
                                        a_ [ href_ "/explore", class_ "js-selected-navigation-item HeaderNavlink px-0 py-2 m-0", data_ "ga-click" "Header, click, Nav menu - item:explore", data_ "selected-links" "/explore /trending /trending/developers /integrations /integrations/feature/code /integrations/feature/collaborate /integrations/feature/ship showcases showcases_search showcases_landing /explore" ] $ "\n                  Explore\n"
                                        "              "
                                    "\n\n              "
                                    li_ [ class_ "ml-4" ] $ do
                                        "\n                    "
                                        a_ [ href_ "/marketplace", class_ "js-selected-navigation-item HeaderNavlink px-0 py-2 m-0", data_ "ga-click" "Header, click, Nav menu - item:marketplace", data_ "selected-links" " /marketplace" ] $ "\n                      Marketplace\n"
                                        "              "
                                    "\n              "
                                    li_ [ class_ "ml-4" ] $ do
                                        "\n                "
                                        a_ [ href_ "/pricing", class_ "js-selected-navigation-item HeaderNavlink px-0 py-2 m-0", data_ "ga-click" "Header, click, Nav menu - item:pricing", data_ "selected-links" "/pricing /pricing/developer /pricing/team /pricing/business-hosted /pricing/business-enterprise /pricing" ] $ "\n                  Pricing\n"
                                        "              "
                                    "\n          "
                                "\n        "
                            "\n\n      "
                            div_ [ class_ "d-flex" ] $ do
                                "\n          "
                                div_ [ class_ "d-lg-flex flex-items-center mr-3" ] $ do
                                    "\n            "
                                    div_ [ class_ "header-search scoped-search site-scoped-search js-site-search", role_ "search" ] $ do
                                        "\n  "
                                        toHtmlRaw  "<!-- '\"` -->"
                                        toHtmlRaw  "<!-- </textarea></xmp> -->"
                                        toHtmlRaw  "<!-- </option></form> -->"
                                        form_ [ acceptCharset_ "UTF-8", action_ "/alogic0/lucid-from-html/search", class_ "js-site-search-form", data_ "scoped-search-url" "/alogic0/lucid-from-html/search", data_ "unscoped-search-url" "/search", method_ "get" ] $ do
                                            div_ [ style_ "margin:0;padding:0;display:inline" ] $ input_ [ name_ "utf8", type_ "hidden", value_ "\10003" ]
                                            "\n    "
                                            label_ [ class_ "form-control header-search-wrapper js-chromeless-input-container" ] $ do
                                                "\n        "
                                                a_ [ href_ "/alogic0/lucid-from-html/blob/master/README.md", class_ "header-search-scope no-underline" ] $ "This repository"
                                                "\n      "
                                                input_ [ type_ "text", class_ "form-control header-search-input js-site-search-focus js-site-search-field is-clearable", data_ "hotkey" "s", name_ "q", value_ "", placeholder_ "Search", ariaLabel_ "Search this repository", data_ "unscoped-placeholder" "Search GitHub", data_ "scoped-placeholder" "Search", autocapitalize_ "off" ]
                                                "\n        "
                                                input_ [ type_ "hidden", class_ "js-site-search-type-field", name_ "type" ]
                                                "\n    "
                                            "\n"
                                    "\n\n          "
                                "\n\n        "
                                span_ [ class_ "d-inline-block" ] $ do
                                    "\n            "
                                    div_ [ class_ "HeaderNavlink px-0 py-2 m-0" ] $ do
                                        "\n              "
                                        a_ [ class_ "text-bold text-white no-underline", href_ "/login?return_to=%2Falogic0%2Flucid-from-html%2Fblob%2Fmaster%2FREADME.md", data_ "ga-click" "(Logged out) Header, clicked Sign in, text:sign-in" ] $ "Sign in"
                                        "\n                "
                                        span_ [ class_ "text-gray" ] $ "or"
                                        "\n                "
                                        a_ [ class_ "text-bold text-white no-underline", href_ "/join?source=header-repo", data_ "ga-click" "(Logged out) Header, clicked Sign up, text:sign-up" ] $ "Sign up"
                                        "\n            "
                                    "\n        "
                                "\n      "
                            "\n    "
                        "\n  "
                    "\n"
                "\n\n\n  "
            "\n\n  "
            div_ [ id_ "start-of-content", class_ "show-on-focus" ] $ ""
            "\n\n    "
            div_ [ id_ "js-flash-container" ] $ "\n"
            "\n\n\n\n  "
            div_ [ role_ "main" ] $ do
                "\n        "
                div_ [ itemscope_ "", itemtype_ "http://schema.org/SoftwareSourceCode" ] $ do
                    "\n    "
                    div_ [ id_ "js-repo-pjax-container", data_ "pjax-container" "" ] $ do
                        "\n      \n\n\n\n\n\n  "
                        div_ [ class_ "pagehead repohead instapaper_ignore readability-menu experiment-repo-nav " ] $ do
                            "\n    "
                            div_ [ class_ "repohead-details-container clearfix container " ] $ do
                                "\n\n      "
                                ul_ [ class_ "pagehead-actions" ] $ do
                                    "\n  "
                                    li_ $ do
                                        "\n      "
                                        a_ [ href_ "/login?return_to=%2Falogic0%2Flucid-from-html", class_ "btn btn-sm btn-with-count tooltipped tooltipped-n", ariaLabel_ "You must be signed in to watch a repository", rel_ "nofollow" ] $ do
                                            "\n    "
                                            toHtmlRaw  "<!-- <svg aria-hidden=\"true\" class=\"octicon octicon-eye\" height=\"16\" version=\"1.1\" viewBox=\"0 0 16 16\" width=\"16\"><path fill-rule=\"evenodd\" d=\"M8.06 2C3 2 0 8 0 8s3 6 8.06 6C13 14 16 8 16 8s-3-6-7.94-6zM8 12c-2.2 0-4-1.78-4-4 0-2.2 1.8-4 4-4 2.22 0 4 1.8 4 4 0 2.22-1.78 4-4 4zm2-4c0 1.11-.89 2-2 2-1.11 0-2-.89-2-2 0-1.11.89-2 2-2 1.11 0 2 .89 2 2z\"/></svg>\n    -->"
                                            "\n    Watch\n  "
                                        "\n  "
                                        a_ [ class_ "social-count", href_ "/alogic0/lucid-from-html/watchers", ariaLabel_ "1 user is watching this repository" ] $ "\n    1\n  "
                                        "\n\n  "
                                    "\n\n  "
                                    li_ $ do
                                        "\n      "
                                        a_ [ href_ "/login?return_to=%2Falogic0%2Flucid-from-html", class_ "btn btn-sm btn-with-count tooltipped tooltipped-n", ariaLabel_ "You must be signed in to star a repository", rel_ "nofollow" ] $ do
                                            "\n    "
                                            toHtmlRaw  "<!-- <svg aria-hidden=\"true\" class=\"octicon octicon-star\" height=\"16\" version=\"1.1\" viewBox=\"0 0 14 16\" width=\"14\"><path fill-rule=\"evenodd\" d=\"M14 6l-4.9-.64L7 1 4.9 5.36 0 6l3.6 3.26L2.67 14 7 11.67 11.33 14l-.93-4.74z\"/></svg>\n    -->"
                                            "\n    Star\n  "
                                        "\n\n    "
                                        a_ [ class_ "social-count js-social-count", href_ "/alogic0/lucid-from-html/stargazers", ariaLabel_ "0 users starred this repository" ] $ "\n      0\n    "
                                        "\n\n  "
                                    "\n\n  "
                                    li_ $ do
                                        "\n      "
                                        a_ [ href_ "/login?return_to=%2Falogic0%2Flucid-from-html", class_ "btn btn-sm btn-with-count tooltipped tooltipped-n", ariaLabel_ "You must be signed in to fork a repository", rel_ "nofollow" ] $ do
                                            "\n        "
                                            toHtmlRaw  "<!-- <svg aria-hidden=\"true\" class=\"octicon octicon-repo-forked\" height=\"16\" version=\"1.1\" viewBox=\"0 0 10 16\" width=\"10\"><path fill-rule=\"evenodd\" d=\"M8 1a1.993 1.993 0 0 0-1 3.72V6L5 8 3 6V4.72A1.993 1.993 0 0 0 2 1a1.993 1.993 0 0 0-1 3.72V6.5l3 3v1.78A1.993 1.993 0 0 0 5 15a1.993 1.993 0 0 0 1-3.72V9.5l3-3V4.72A1.993 1.993 0 0 0 8 1zM2 4.2C1.34 4.2.8 3.65.8 3c0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2 0 .65-.55 1.2-1.2 1.2zm3 10c-.66 0-1.2-.55-1.2-1.2 0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2 0 .65-.55 1.2-1.2 1.2zm3-10c-.66 0-1.2-.55-1.2-1.2 0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2 0 .65-.55 1.2-1.2 1.2z\"/></svg>\n        -->"
                                            "\n        Fork\n      "
                                        "\n\n    "
                                        a_ [ href_ "/alogic0/lucid-from-html/network", class_ "social-count", ariaLabel_ "4 users forked this repository" ] $ "\n      4\n    "
                                        "\n  "
                                    "\n"
                                "\n\n      "
                                h1_ [ class_ "public " ] $ do
                                    "\n  "
                                    toHtmlRaw  "<!-- <svg aria-hidden=\"true\" class=\"octicon octicon-repo-forked\" height=\"16\" version=\"1.1\" viewBox=\"0 0 10 16\" width=\"10\"><path fill-rule=\"evenodd\" d=\"M8 1a1.993 1.993 0 0 0-1 3.72V6L5 8 3 6V4.72A1.993 1.993 0 0 0 2 1a1.993 1.993 0 0 0-1 3.72V6.5l3 3v1.78A1.993 1.993 0 0 0 5 15a1.993 1.993 0 0 0 1-3.72V9.5l3-3V4.72A1.993 1.993 0 0 0 8 1zM2 4.2C1.34 4.2.8 3.65.8 3c0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2 0 .65-.55 1.2-1.2 1.2zm3 10c-.66 0-1.2-.55-1.2-1.2 0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2 0 .65-.55 1.2-1.2 1.2zm3-10c-.66 0-1.2-.55-1.2-1.2 0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2 0 .65-.55 1.2-1.2 1.2z\"/></svg>\n  -->"
                                    "\n  "
                                    span_ [ class_ "author", itemprop_ "author" ] $ a_ [ href_ "/alogic0", class_ "url fn", rel_ "author" ] $ "alogic0"
                                    toHtmlRaw  "<!--\n-->"
                                    span_ [ class_ "path-divider" ] $ "/"
                                    toHtmlRaw  "<!--\n-->"
                                    strong_ [ itemprop_ "name" ] $ a_ [ href_ "/alogic0/lucid-from-html", data_ "pjax" "#js-repo-pjax-container" ] $ "lucid-from-html"
                                    "\n\n    "
                                    span_ [ class_ "fork-flag" ] $ do
                                        "\n      "
                                        span_ [ class_ "text" ] $ do
                                            "forked from "
                                            a_ [ href_ "/dbaynard/lucid-from-html" ] $ "dbaynard/lucid-from-html"
                                        "\n    "
                                    "\n"
                                "\n\n    "
                            "\n    \n"
                            nav_ [ class_ "reponav js-repo-nav js-sidenav-container-pjax container", itemscope_ "", itemtype_ "http://schema.org/BreadcrumbList", role_ "navigation", data_ "pjax" "#js-repo-pjax-container" ] $ do
                                "\n\n  "
                                span_ [ itemscope_ "", itemtype_ "http://schema.org/ListItem", itemprop_ "itemListElement" ] $ do
                                    "\n    "
                                    a_ [ href_ "/alogic0/lucid-from-html", class_ "js-selected-navigation-item selected reponav-item", data_ "hotkey" "g c", data_ "selected-links" "repo_source repo_downloads repo_commits repo_releases repo_tags repo_branches repo_packages /alogic0/lucid-from-html", itemprop_ "url" ] $ do
                                        "\n      "
                                        toHtmlRaw  "<!-- <svg aria-hidden=\"true\" class=\"octicon octicon-code\" height=\"16\" version=\"1.1\" viewBox=\"0 0 14 16\" width=\"14\"><path fill-rule=\"evenodd\" d=\"M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z\"/></svg>\n      -->"
                                        "\n      "
                                        span_ [ itemprop_ "name" ] $ "Code"
                                        "\n      "
                                        meta_ [ itemprop_ "position", content_ "1" ]
                                        "\n"
                                    "  "
                                "\n\n    "
                                span_ [ itemscope_ "", itemtype_ "http://schema.org/ListItem", itemprop_ "itemListElement" ] $ do
                                    "\n      "
                                    a_ [ href_ "/alogic0/lucid-from-html/issues", class_ "js-selected-navigation-item reponav-item", data_ "hotkey" "g i", data_ "selected-links" "repo_issues repo_labels repo_milestones /alogic0/lucid-from-html/issues", itemprop_ "url" ] $ do
                                        "\n        "
                                        toHtmlRaw  "<!-- <svg aria-hidden=\"true\" class=\"octicon octicon-issue-opened\" height=\"16\" version=\"1.1\" viewBox=\"0 0 14 16\" width=\"14\"><path fill-rule=\"evenodd\" d=\"M7 2.3c3.14 0 5.7 2.56 5.7 5.7s-2.56 5.7-5.7 5.7A5.71 5.71 0 0 1 1.3 8c0-3.14 2.56-5.7 5.7-5.7zM7 1C3.14 1 0 4.14 0 8s3.14 7 7 7 7-3.14 7-7-3.14-7-7-7zm1 3H6v5h2V4zm0 6H6v2h2v-2z\"/></svg>\n        -->"
                                        "\n        "
                                        span_ [ itemprop_ "name" ] $ "Issues"
                                        "\n        "
                                        span_ [ class_ "Counter" ] $ "6"
                                        "\n        "
                                        meta_ [ itemprop_ "position", content_ "2" ]
                                        "\n"
                                    "    "
                                "\n\n  "
                                span_ [ itemscope_ "", itemtype_ "http://schema.org/ListItem", itemprop_ "itemListElement" ] $ do
                                    "\n    "
                                    a_ [ href_ "/alogic0/lucid-from-html/pulls", class_ "js-selected-navigation-item reponav-item", data_ "hotkey" "g p", data_ "selected-links" "repo_pulls /alogic0/lucid-from-html/pulls", itemprop_ "url" ] $ do
                                        "\n      "
                                        toHtmlRaw  "<!-- <svg aria-hidden=\"true\" class=\"octicon octicon-git-pull-request\" height=\"16\" version=\"1.1\" viewBox=\"0 0 12 16\" width=\"12\"><path fill-rule=\"evenodd\" d=\"M11 11.28V5c-.03-.78-.34-1.47-.94-2.06C9.46 2.35 8.78 2.03 8 2H7V0L4 3l3 3V4h1c.27.02.48.11.69.31.21.2.3.42.31.69v6.28A1.993 1.993 0 0 0 10 15a1.993 1.993 0 0 0 1-3.72zm-1 2.92c-.66 0-1.2-.55-1.2-1.2 0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2 0 .65-.55 1.2-1.2 1.2zM4 3c0-1.11-.89-2-2-2a1.993 1.993 0 0 0-1 3.72v6.56A1.993 1.993 0 0 0 2 15a1.993 1.993 0 0 0 1-3.72V4.72c.59-.34 1-.98 1-1.72zm-.8 10c0 .66-.55 1.2-1.2 1.2-.65 0-1.2-.55-1.2-1.2 0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2zM2 4.2C1.34 4.2.8 3.65.8 3c0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2 0 .65-.55 1.2-1.2 1.2z\"/></svg>\n      -->"
                                        "\n      "
                                        span_ [ itemprop_ "name" ] $ "Pull requests"
                                        "\n      "
                                        span_ [ class_ "Counter" ] $ "0"
                                        "\n      "
                                        meta_ [ itemprop_ "position", content_ "3" ]
                                        "\n"
                                    "  "
                                "\n\n    "
                                a_ [ href_ "/alogic0/lucid-from-html/projects", class_ "js-selected-navigation-item reponav-item", data_ "hotkey" "g b", data_ "selected-links" "repo_projects new_repo_project repo_project /alogic0/lucid-from-html/projects" ] $ do
                                    "\n      "
                                    toHtmlRaw  "<!-- <svg aria-hidden=\"true\" class=\"octicon octicon-project\" height=\"16\" version=\"1.1\" viewBox=\"0 0 15 16\" width=\"15\"><path fill-rule=\"evenodd\" d=\"M10 12h3V2h-3v10zm-4-2h3V2H6v8zm-4 4h3V2H2v12zm-1 1h13V1H1v14zM14 0H1a1 1 0 0 0-1 1v14a1 1 0 0 0 1 1h13a1 1 0 0 0 1-1V1a1 1 0 0 0-1-1z\"/></svg>\n      -->"
                                    "\n      Projects\n      "
                                    span_ [ class_ "Counter" ] $ "0"
                                    "\n"
                                "\n\n\n  "
                                a_ [ href_ "/alogic0/lucid-from-html/pulse", class_ "js-selected-navigation-item reponav-item", data_ "selected-links" "repo_graphs repo_contributors dependency_graph pulse /alogic0/lucid-from-html/pulse" ] $ do
                                    "\n    "
                                    toHtmlRaw  "<!-- <svg aria-hidden=\"true\" class=\"octicon octicon-graph\" height=\"16\" version=\"1.1\" viewBox=\"0 0 16 16\" width=\"16\"><path fill-rule=\"evenodd\" d=\"M16 14v1H0V0h1v14h15zM5 13H3V8h2v5zm4 0H7V3h2v10zm4 0h-2V6h2v7z\"/></svg>\n    -->"
                                    "\n    Insights\n"
                                "\n\n"
                            "\n\n\n  "
                        "\n\n"
                        div_ [ class_ "container new-discussion-timeline experiment-repo-nav" ] $ do
                            "\n  "
                            div_ [ class_ "repository-content" ] $ do
                                "\n\n    \n  "
                                a_ [ href_ "/alogic0/lucid-from-html/blob/87186ff128a9522947ab384df7b0e2a7ff07da26/README.md", class_ "d-none js-permalink-shortcut", data_ "hotkey" "y" ] $ "Permalink"
                                "\n\n  "
                                toHtmlRaw  "<!-- blob contrib key: blob_contributors:v21:a568fce3419b0bb60a63d1404ab5dda0 -->"
                                "\n\n  "
                                div_ [ class_ "file-navigation js-zeroclipboard-container" ] $ do
                                    "\n    \n"
                                    div_ [ class_ "select-menu branch-select-menu js-menu-container js-select-menu float-left" ] $ do
                                        "\n  "
                                        button_ [ class_ " btn btn-sm select-menu-button js-menu-target css-truncate", data_ "hotkey" "w", type_ "button", ariaLabel_ "Switch branches or tags", ariaExpanded_ "false", ariaHaspopup_ "true" ] $ do
                                            "\n      "
                                            i_ "Branch:"
                                            "\n      "
                                            span_ [ class_ "js-select-button css-truncate-target" ] $ "master"
                                            "\n  "
                                        "\n\n  "
                                        div_ [ class_ "select-menu-modal-holder js-menu-content js-navigation-container", data_ "pjax" "" ] $ do
                                            "\n\n    "
                                            div_ [ class_ "select-menu-modal" ] $ do
                                                "\n      "
                                                div_ [ class_ "select-menu-header" ] $ do
                                                    "\n        "
                                                    toHtmlRaw  "<!-- <svg aria-label=\"Close\" class=\"octicon octicon-x js-menu-close\" height=\"16\" role=\"img\" version=\"1.1\" viewBox=\"0 0 12 16\" width=\"12\"><path fill-rule=\"evenodd\" d=\"M7.48 8l3.75 3.75-1.48 1.48L6 9.48l-3.75 3.75-1.48-1.48L4.52 8 .77 4.25l1.48-1.48L6 6.52l3.75-3.75 1.48 1.48z\"/></svg>\n        -->"
                                                    "\n        "
                                                    span_ [ class_ "select-menu-title" ] $ "Switch branches/tags"
                                                    "\n      "
                                                "\n\n      "
                                                div_ [ class_ "select-menu-filters" ] $ do
                                                    "\n        "
                                                    div_ [ class_ "select-menu-text-filter" ] $ do
                                                        "\n          "
                                                        input_ [ type_ "text", ariaLabel_ "Filter branches/tags", id_ "context-commitish-filter-field", class_ "form-control js-filterable-field js-navigation-enable", placeholder_ "Filter branches/tags" ]
                                                        "\n        "
                                                    "\n        "
                                                    div_ [ class_ "select-menu-tabs" ] $ do
                                                        "\n          "
                                                        ul_ $ do
                                                            "\n            "
                                                            li_ [ class_ "select-menu-tab" ] $ do
                                                                "\n              "
                                                                a_ [ href_ "#", data_ "tab-filter" "branches", data_ "filter-placeholder" "Filter branches/tags", class_ "js-select-menu-tab", role_ "tab" ] $ "Branches"
                                                                "\n            "
                                                            "\n            "
                                                            li_ [ class_ "select-menu-tab" ] $ do
                                                                "\n              "
                                                                a_ [ href_ "#", data_ "tab-filter" "tags", data_ "filter-placeholder" "Find a tag\8230", class_ "js-select-menu-tab", role_ "tab" ] $ "Tags"
                                                                "\n            "
                                                            "\n          "
                                                        "\n        "
                                                    "\n      "
                                                "\n\n      "
                                                div_ [ class_ "select-menu-list select-menu-tab-bucket js-select-menu-tab-bucket", data_ "tab-filter" "branches", role_ "menu" ] $ do
                                                    "\n\n        "
                                                    div_ [ data_ "filterable-for" "context-commitish-filter-field", data_ "filterable-type" "substring" ] $ do
                                                        "\n\n\n            "
                                                        a_ [ class_ "select-menu-item js-navigation-item js-navigation-open ", href_ "/alogic0/lucid-from-html/blob/dbaynard/README.md", data_ "name" "dbaynard", data_ "skip-pjax" "true", rel_ "nofollow" ] $ do
                                                            "\n              "
                                                            toHtmlRaw  "<!-- <svg aria-hidden=\"true\" class=\"octicon octicon-check select-menu-item-icon\" height=\"16\" version=\"1.1\" viewBox=\"0 0 12 16\" width=\"12\"><path fill-rule=\"evenodd\" d=\"M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5z\"/></svg>\n              -->"
                                                            "\n              "
                                                            span_ [ class_ "select-menu-item-text css-truncate-target js-select-menu-filter-text" ] $ "\n                dbaynard\n              "
                                                            "\n            "
                                                        "\n            "
                                                        a_ [ class_ "select-menu-item js-navigation-item js-navigation-open ", href_ "/alogic0/lucid-from-html/blob/lucid/README.md", data_ "name" "lucid", data_ "skip-pjax" "true", rel_ "nofollow" ] $ do
                                                            "\n              "
                                                            toHtmlRaw  "<!-- <svg aria-hidden=\"true\" class=\"octicon octicon-check select-menu-item-icon\" height=\"16\" version=\"1.1\" viewBox=\"0 0 12 16\" width=\"12\"><path fill-rule=\"evenodd\" d=\"M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5z\"/></svg>\n              -->"
                                                            "\n              "
                                                            span_ [ class_ "select-menu-item-text css-truncate-target js-select-menu-filter-text" ] $ "\n                lucid\n              "
                                                            "\n            "
                                                        "\n            "
                                                        a_ [ class_ "select-menu-item js-navigation-item js-navigation-open selected", href_ "/alogic0/lucid-from-html/blob/master/README.md", data_ "name" "master", data_ "skip-pjax" "true", rel_ "nofollow" ] $ do
                                                            "\n              "
                                                            toHtmlRaw  "<!-- <svg aria-hidden=\"true\" class=\"octicon octicon-check select-menu-item-icon\" height=\"16\" version=\"1.1\" viewBox=\"0 0 12 16\" width=\"12\"><path fill-rule=\"evenodd\" d=\"M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5z\"/></svg>\n              -->"
                                                            "\n              "
                                                            span_ [ class_ "select-menu-item-text css-truncate-target js-select-menu-filter-text" ] $ "\n                master\n              "
                                                            "\n            "
                                                        "\n            "
                                                        a_ [ class_ "select-menu-item js-navigation-item js-navigation-open ", href_ "/alogic0/lucid-from-html/blob/svg/README.md", data_ "name" "svg", data_ "skip-pjax" "true", rel_ "nofollow" ] $ do
                                                            "\n              "
                                                            toHtmlRaw  "<!-- <svg aria-hidden=\"true\" class=\"octicon octicon-check select-menu-item-icon\" height=\"16\" version=\"1.1\" viewBox=\"0 0 12 16\" width=\"12\"><path fill-rule=\"evenodd\" d=\"M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5z\"/></svg>\n              -->"
                                                            "\n              "
                                                            span_ [ class_ "select-menu-item-text css-truncate-target js-select-menu-filter-text" ] $ "\n                svg\n              "
                                                            "\n            "
                                                        "\n            "
                                                        a_ [ class_ "select-menu-item js-navigation-item js-navigation-open ", href_ "/alogic0/lucid-from-html/blob/test/README.md", data_ "name" "test", data_ "skip-pjax" "true", rel_ "nofollow" ] $ do
                                                            "\n              "
                                                            toHtmlRaw  "<!-- <svg aria-hidden=\"true\" class=\"octicon octicon-check select-menu-item-icon\" height=\"16\" version=\"1.1\" viewBox=\"0 0 12 16\" width=\"12\"><path fill-rule=\"evenodd\" d=\"M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5z\"/></svg>\n              -->"
                                                            "\n              "
                                                            span_ [ class_ "select-menu-item-text css-truncate-target js-select-menu-filter-text" ] $ "\n                test\n              "
                                                            "\n            "
                                                        "\n        "
                                                    "\n\n          "
                                                    div_ [ class_ "select-menu-no-results" ] $ "Nothing to show"
                                                    "\n      "
                                                "\n\n      "
                                                div_ [ class_ "select-menu-list select-menu-tab-bucket js-select-menu-tab-bucket", data_ "tab-filter" "tags" ] $ do
                                                    "\n        "
                                                    div_ [ data_ "filterable-for" "context-commitish-filter-field", data_ "filterable-type" "substring" ] $ do
                                                        "\n\n\n            "
                                                        a_ [ class_ "select-menu-item js-navigation-item js-navigation-open ", href_ "/alogic0/lucid-from-html/tree/0.1.0.0/README.md", data_ "name" "0.1.0.0", data_ "skip-pjax" "true", rel_ "nofollow" ] $ do
                                                            "\n              "
                                                            toHtmlRaw  "<!-- <svg aria-hidden=\"true\" class=\"octicon octicon-check select-menu-item-icon\" height=\"16\" version=\"1.1\" viewBox=\"0 0 12 16\" width=\"12\"><path fill-rule=\"evenodd\" d=\"M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5z\"/></svg>\n              -->"
                                                            "\n              "
                                                            span_ [ class_ "select-menu-item-text css-truncate-target", title_ "0.1.0.0" ] $ "\n                0.1.0.0\n              "
                                                            "\n            "
                                                        "\n        "
                                                    "\n\n        "
                                                    div_ [ class_ "select-menu-no-results" ] $ "Nothing to show"
                                                    "\n      "
                                                "\n\n    "
                                            "\n  "
                                        "\n"
                                    "\n\n    "
                                    div_ [ class_ "BtnGroup float-right" ] $ do
                                        "\n      "
                                        a_ [ href_ "/alogic0/lucid-from-html/find/master", class_ "js-pjax-capture-input btn btn-sm BtnGroup-item", data_ "pjax" "", data_ "hotkey" "t" ] $ "\n        Find file\n      "
                                        "\n      "
                                        button_ [ ariaLabel_ "Copy file path to clipboard", class_ "js-zeroclipboard btn btn-sm BtnGroup-item tooltipped tooltipped-s", data_ "copied-hint" "Copied!", type_ "button" ] $ "Copy path"
                                        "\n    "
                                    "\n    "
                                    div_ [ class_ "breadcrumb js-zeroclipboard-target" ] $ do
                                        "\n      "
                                        span_ [ class_ "repo-root js-repo-root" ] $ span_ [ class_ "js-path-segment" ] $ a_ [ href_ "/alogic0/lucid-from-html" ] $ span_ "lucid-from-html"
                                        span_ [ class_ "separator" ] $ "/"
                                        strong_ [ class_ "final-path" ] $ "README.md"
                                        "\n    "
                                    "\n  "
                                "\n\n\n  \n  "
                                div_ [ class_ "commit-tease" ] $ do
                                    "\n      "
                                    span_ [ class_ "float-right" ] $ do
                                        "\n        "
                                        a_ [ class_ "commit-tease-sha", href_ "/alogic0/lucid-from-html/commit/87186ff128a9522947ab384df7b0e2a7ff07da26", data_ "pjax" "" ] $ "\n          87186ff\n        "
                                        "\n        "
                                        relativeTime_ [ datetime_ "2017-12-22T17:23:46Z" ]
                                        "Dec 22, 2017"
                                        "\n      "
                                    "\n      "
                                    div_ $ do
                                        "\n        "
                                        img_ [ alt_ "@alogic0", class_ "avatar", height_ "20", src_ "https://avatars3.githubusercontent.com/u/446277?s=40&v=4", width_ "20" ]
                                        "\n        "
                                        a_ [ href_ "/alogic0", class_ "user-mention", rel_ "author" ] $ "alogic0"
                                        "\n          "
                                        a_ [ href_ "/alogic0/lucid-from-html/commit/87186ff128a9522947ab384df7b0e2a7ff07da26", class_ "message", data_ "pjax" "true", title_ "Update README.md" ] $ "Update README.md"
                                        "\n      "
                                    "\n\n    "
                                    div_ [ class_ "commit-tease-contributors" ] $ do
                                        "\n      "
                                        button_ [ type_ "button", class_ "btn-link muted-link contributors-toggle", data_ "facebox" "#blob_contributors_box" ] $ do
                                            "\n        "
                                            strong_ "3"
                                            "\n         contributors\n      "
                                        "\n          "
                                        a_ [ class_ "avatar-link tooltipped tooltipped-s", ariaLabel_ "alogic0", href_ "/alogic0/lucid-from-html/commits/master/README.md?author=alogic0" ] $ do
                                            img_ [ alt_ "@alogic0", class_ "avatar", height_ "20", src_ "https://avatars3.githubusercontent.com/u/446277?s=40&v=4", width_ "20" ]
                                            " "
                                        "\n    "
                                        a_ [ class_ "avatar-link tooltipped tooltipped-s", ariaLabel_ "dbaynard", href_ "/alogic0/lucid-from-html/commits/master/README.md?author=dbaynard" ] $ do
                                            img_ [ alt_ "@dbaynard", class_ "avatar", height_ "20", src_ "https://avatars1.githubusercontent.com/u/870937?s=40&v=4", width_ "20" ]
                                            " "
                                        "\n    "
                                        a_ [ class_ "avatar-link tooltipped tooltipped-s", ariaLabel_ "jaspervdj", href_ "/alogic0/lucid-from-html/commits/master/README.md?author=jaspervdj" ] $ do
                                            img_ [ alt_ "@jaspervdj", class_ "avatar", height_ "20", src_ "https://avatars0.githubusercontent.com/u/95501?s=40&v=4", width_ "20" ]
                                            " "
                                        "\n\n\n    "
                                    "\n\n    "
                                    div_ [ id_ "blob_contributors_box", style_ "display:none" ] $ do
                                        "\n      "
                                        h2_ [ class_ "facebox-header", data_ "facebox-id" "facebox-header" ] $ "Users who have contributed to this file"
                                        "\n      "
                                        ul_ [ class_ "facebox-user-list", data_ "facebox-id" "facebox-description" ] $ do
                                            "\n          "
                                            li_ [ class_ "facebox-user-list-item" ] $ do
                                                "\n            "
                                                img_ [ alt_ "@alogic0", height_ "24", src_ "https://avatars2.githubusercontent.com/u/446277?s=48&v=4", width_ "24" ]
                                                "\n            "
                                                a_ [ href_ "/alogic0" ] $ "alogic0"
                                                "\n          "
                                            "\n          "
                                            li_ [ class_ "facebox-user-list-item" ] $ do
                                                "\n            "
                                                img_ [ alt_ "@dbaynard", height_ "24", src_ "https://avatars0.githubusercontent.com/u/870937?s=48&v=4", width_ "24" ]
                                                "\n            "
                                                a_ [ href_ "/dbaynard" ] $ "dbaynard"
                                                "\n          "
                                            "\n          "
                                            li_ [ class_ "facebox-user-list-item" ] $ do
                                                "\n            "
                                                img_ [ alt_ "@jaspervdj", height_ "24", src_ "https://avatars1.githubusercontent.com/u/95501?s=48&v=4", width_ "24" ]
                                                "\n            "
                                                a_ [ href_ "/jaspervdj" ] $ "jaspervdj"
                                                "\n          "
                                            "\n      "
                                        "\n    "
                                    "\n  "
                                "\n\n\n  "
                                div_ [ class_ "file" ] $ do
                                    "\n    "
                                    div_ [ class_ "file-header" ] $ do
                                        "\n  "
                                        div_ [ class_ "file-actions" ] $ do
                                            "\n\n    "
                                            div_ [ class_ "BtnGroup" ] $ do
                                                "\n      "
                                                a_ [ href_ "/alogic0/lucid-from-html/raw/master/README.md", class_ "btn btn-sm BtnGroup-item", id_ "raw-url" ] $ "Raw"
                                                "\n        "
                                                a_ [ href_ "/alogic0/lucid-from-html/blame/master/README.md", class_ "btn btn-sm js-update-url-with-hash BtnGroup-item", data_ "hotkey" "b" ] $ "Blame"
                                                "\n      "
                                                a_ [ href_ "/alogic0/lucid-from-html/commits/master/README.md", class_ "btn btn-sm BtnGroup-item", rel_ "nofollow" ] $ "History"
                                                "\n    "
                                            "\n\n\n        "
                                            button_ [ type_ "button", class_ "btn-octicon disabled tooltipped tooltipped-nw", ariaLabel_ "You must be signed in to make or propose changes" ] $ do
                                                "\n          "
                                                toHtmlRaw  "<!-- <svg aria-hidden=\"true\" class=\"octicon octicon-pencil\" height=\"16\" version=\"1.1\" viewBox=\"0 0 14 16\" width=\"14\"><path fill-rule=\"evenodd\" d=\"M0 12v3h3l8-8-3-3-8 8zm3 2H1v-2h1v1h1v1zm10.3-9.3L12 6 9 3l1.3-1.3a.996.996 0 0 1 1.41 0l1.59 1.59c.39.39.39 1.02 0 1.41z\"/></svg>\n          -->"
                                                "\n        "
                                            "\n        "
                                            button_ [ type_ "button", class_ "btn-octicon btn-octicon-danger disabled tooltipped tooltipped-nw", ariaLabel_ "You must be signed in to make or propose changes" ] $ do
                                                "\n          "
                                                toHtmlRaw  "<!-- <svg aria-hidden=\"true\" class=\"octicon octicon-trashcan\" height=\"16\" version=\"1.1\" viewBox=\"0 0 12 16\" width=\"12\"><path fill-rule=\"evenodd\" d=\"M11 2H9c0-.55-.45-1-1-1H5c-.55 0-1 .45-1 1H2c-.55 0-1 .45-1 1v1c0 .55.45 1 1 1v9c0 .55.45 1 1 1h7c.55 0 1-.45 1-1V5c.55 0 1-.45 1-1V3c0-.55-.45-1-1-1zm-1 12H3V5h1v8h1V5h1v8h1V5h1v8h1V5h1v9zm1-10H2V3h9v1z\"/></svg>\n          -->"
                                                "\n        "
                                            "\n  "
                                        "\n\n  "
                                        div_ [ class_ "file-info" ] $ do
                                            "\n      27 lines (14 sloc)\n      "
                                            span_ [ class_ "file-info-divider" ] $ ""
                                            "\n    709 Bytes\n  "
                                        "\n"
                                    "\n\n    \n  "
                                    div_ [ id_ "readme", class_ "readme blob instapaper_body" ] $ do
                                        "\n    "
                                        article_ [ class_ "markdown-body entry-content", itemprop_ "text" ] $ do
                                            p_ $ do
                                                "This repository hosts the code to the "
                                                code_ "lucid-from-html"
                                                " tool, derived from "
                                                a_ [ href_ "https://github.com/dbaynard/lucid-from-html/" ] $ "@dbaynard"
                                                "."
                                            "\n"
                                            p_ $ do
                                                "Please report any issues (including examples of html files that don\8217t parse correctly) at the "
                                                a_ [ href_ "https://github.com/alogic0/lucid-from-html/issues" ] $ "issue tracker"
                                                "."
                                            "\n"
                                            h1_ $ do
                                                a_ [ href_ "#install", ariaHidden_ "true", class_ "anchor", id_ "user-content-install" ] $ toHtmlRaw  "<!-- <svg aria-hidden=\"true\" class=\"octicon octicon-link\" height=\"16\" version=\"1.1\" viewBox=\"0 0 16 16\" width=\"16\"><path fill-rule=\"evenodd\" d=\"M4 9h1v1H4c-1.5 0-3-1.69-3-3.5S2.55 3 4 3h4c1.45 0 3 1.69 3 3.5 0 1.41-.91 2.72-2 3.25V8.59c.58-.45 1-1.27 1-2.09C10 5.22 8.98 4 8 4H4c-.98 0-2 1.22-2 2.5S3 9 4 9zm9-3h-1v1h1c1 0 2 1.22 2 2.5S13.98 12 13 12H9c-.98 0-2-1.22-2-2.5 0-.83.42-1.64 1-2.09V6.25c-1.09.53-2 1.84-2 3.25C6 11.31 7.55 13 9 13h4c1.45 0 3-1.69 3-3.5S14.5 6 13 6z\"></path></svg> -->"
                                                "Install"
                                            "\n"
                                            ol_ $ do
                                                "\n"
                                                li_ $ do
                                                    "\n"
                                                    p_ "Clone the repository."
                                                    "\n"
                                                "\n"
                                                li_ $ do
                                                    "\n"
                                                    p_ "Change to the directory of the repository."
                                                    "\n"
                                                "\n"
                                                li_ $ do
                                                    "\n"
                                                    p_ "Run"
                                                    "\n"
                                                    pre_ $ code_ "> cabal install\n"
                                                    "\n"
                                                "\n"
                                            "\n"
                                            h1_ $ do
                                                a_ [ href_ "#run", ariaHidden_ "true", class_ "anchor", id_ "user-content-run" ] $ toHtmlRaw  "<!-- <svg aria-hidden=\"true\" class=\"octicon octicon-link\" height=\"16\" version=\"1.1\" viewBox=\"0 0 16 16\" width=\"16\"><path fill-rule=\"evenodd\" d=\"M4 9h1v1H4c-1.5 0-3-1.69-3-3.5S2.55 3 4 3h4c1.45 0 3 1.69 3 3.5 0 1.41-.91 2.72-2 3.25V8.59c.58-.45 1-1.27 1-2.09C10 5.22 8.98 4 8 4H4c-.98 0-2 1.22-2 2.5S3 9 4 9zm9-3h-1v1h1c1 0 2 1.22 2 2.5S13.98 12 13 12H9c-.98 0-2-1.22-2-2.5 0-.83.42-1.64 1-2.09V6.25c-1.09.53-2 1.84-2 3.25C6 11.31 7.55 13 9 13h4c1.45 0 3-1.69 3-3.5S14.5 6 13 6z\"></path></svg> -->"
                                                "Run"
                                            "\n"
                                            p_ $ do
                                                "To convert "
                                                em_ "filename"
                                                ".html to lucid text, run"
                                            "\n"
                                            pre_ $ code_ "> lucid-from-html -t -s filename.html > filename.hs\n"
                                            "\n"
                                            p_ $ do
                                                "The options here: "
                                                em_ "Do not trim ends of the strings from the space-symbols"
                                                "\nand "
                                                em_ "Create standalone code, ready to compile"
                                            "\n"
                                            p_ "To see all options, run"
                                            "\n"
                                            pre_ $ code_ "> lucid-from-html --help\n"
                                            "\n"
                                        "\n  "
                                    "\n\n  "
                                "\n\n  "
                                button_ [ type_ "button", data_ "facebox" "#jump-to-line", data_ "facebox-class" "linejump", data_ "hotkey" "l", class_ "d-none" ] $ "Jump to Line"
                                "\n  "
                                div_ [ id_ "jump-to-line", style_ "display:none" ] $ do
                                    "\n    "
                                    toHtmlRaw  "<!-- '\"` -->"
                                    toHtmlRaw  "<!-- </textarea></xmp> -->"
                                    toHtmlRaw  "<!-- </option></form> -->"
                                    form_ [ acceptCharset_ "UTF-8", action_ "", class_ "js-jump-to-line-form", method_ "get" ] $ do
                                        div_ [ style_ "margin:0;padding:0;display:inline" ] $ input_ [ name_ "utf8", type_ "hidden", value_ "\10003" ]
                                        "\n      "
                                        input_ [ class_ "form-control linejump-input js-jump-to-line-field", type_ "text", placeholder_ "Jump to line\8230", ariaLabel_ "Jump to line", autofocus_ ]
                                        "\n      "
                                        button_ [ type_ "submit", class_ "btn" ] $ "Go"
                                        "\n"
                                    "  "
                                "\n\n\n  "
                            "\n  "
                            div_ [ class_ "modal-backdrop js-touch-events" ] $ ""
                            "\n"
                        "\n\n    "
                    "\n  "
                "\n\n  "
            "\n\n      \n"
            div_ [ class_ "footer container-lg px-3", role_ "contentinfo" ] $ do
                "\n  "
                div_ [ class_ "position-relative d-flex flex-justify-between py-6 mt-6 f6 text-gray border-top border-gray-light " ] $ do
                    "\n    "
                    ul_ [ class_ "list-style-none d-flex flex-wrap " ] $ do
                        "\n      "
                        li_ [ class_ "mr-3" ] $ do
                            "\169 2017 "
                            span_ [ title_ "0.10575s from unicorn-3459850534-s61qx" ] $ "GitHub"
                            ", Inc."
                        "\n        "
                        li_ [ class_ "mr-3" ] $ a_ [ href_ "https://github.com/site/terms", data_ "ga-click" "Footer, go to terms, text:terms" ] $ "Terms"
                        "\n        "
                        li_ [ class_ "mr-3" ] $ a_ [ href_ "https://github.com/site/privacy", data_ "ga-click" "Footer, go to privacy, text:privacy" ] $ "Privacy"
                        "\n        "
                        li_ [ class_ "mr-3" ] $ a_ [ href_ "https://github.com/security", data_ "ga-click" "Footer, go to security, text:security" ] $ "Security"
                        "\n        "
                        li_ [ class_ "mr-3" ] $ a_ [ href_ "https://status.github.com/", data_ "ga-click" "Footer, go to status, text:status" ] $ "Status"
                        "\n        "
                        li_ $ a_ [ href_ "https://help.github.com", data_ "ga-click" "Footer, go to help, text:help" ] $ "Help"
                        "\n    "
                    "\n\n    "
                    a_ [ href_ "https://github.com", ariaLabel_ "Homepage", class_ "footer-octicon", title_ "GitHub" ] $ do
                        "\n      "
                        toHtmlRaw  "<!-- <svg aria-hidden=\"true\" class=\"octicon octicon-mark-github\" height=\"24\" version=\"1.1\" viewBox=\"0 0 16 16\" width=\"24\"><path fill-rule=\"evenodd\" d=\"M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.013 8.013 0 0 0 16 8c0-4.42-3.58-8-8-8z\"/></svg>\n      -->"
                        "\n"
                    "\n    "
                    ul_ [ class_ "list-style-none d-flex flex-wrap " ] $ do
                        "\n        "
                        li_ [ class_ "mr-3" ] $ a_ [ href_ "https://github.com/contact", data_ "ga-click" "Footer, go to contact, text:contact" ] $ "Contact GitHub"
                        "\n      "
                        li_ [ class_ "mr-3" ] $ a_ [ href_ "https://developer.github.com", data_ "ga-click" "Footer, go to api, text:api" ] $ "API"
                        "\n      "
                        li_ [ class_ "mr-3" ] $ a_ [ href_ "https://training.github.com", data_ "ga-click" "Footer, go to training, text:training" ] $ "Training"
                        "\n      "
                        li_ [ class_ "mr-3" ] $ a_ [ href_ "https://shop.github.com", data_ "ga-click" "Footer, go to shop, text:shop" ] $ "Shop"
                        "\n        "
                        li_ [ class_ "mr-3" ] $ a_ [ href_ "https://github.com/blog", data_ "ga-click" "Footer, go to blog, text:blog" ] $ "Blog"
                        "\n        "
                        li_ $ a_ [ href_ "https://github.com/about", data_ "ga-click" "Footer, go to about, text:about" ] $ "About"
                        "\n\n    "
                    "\n  "
                "\n"
            "\n\n\n\n  "
            div_ [ id_ "ajax-error-message", class_ "ajax-error-message flash flash-error" ] $ do
                "\n    "
                toHtmlRaw  "<!-- <svg aria-hidden=\"true\" class=\"octicon octicon-alert\" height=\"16\" version=\"1.1\" viewBox=\"0 0 16 16\" width=\"16\"><path fill-rule=\"evenodd\" d=\"M8.865 1.52c-.18-.31-.51-.5-.87-.5s-.69.19-.87.5L.275 13.5c-.18.31-.18.69 0 1 .19.31.52.5.87.5h13.7c.36 0 .69-.19.86-.5.17-.31.18-.69.01-1L8.865 1.52zM8.995 13h-2v-2h2v2zm0-3h-2V6h2v4z\"/></svg>\n    -->"
                "\n    "
                button_ [ type_ "button", class_ "flash-close js-ajax-error-dismiss", ariaLabel_ "Dismiss error" ] $ do
                    "\n      "
                    toHtmlRaw  "<!-- <svg aria-hidden=\"true\" class=\"octicon octicon-x\" height=\"16\" version=\"1.1\" viewBox=\"0 0 12 16\" width=\"12\"><path fill-rule=\"evenodd\" d=\"M7.48 8l3.75 3.75-1.48 1.48L6 9.48l-3.75 3.75-1.48-1.48L4.52 8 .77 4.25l1.48-1.48L6 6.52l3.75-3.75 1.48 1.48z\"/></svg>\n      -->"
                    "\n    "
                "\n    You can't perform that action at this time.\n  "
            "\n\n\n    "
            script_ [ crossorigin_ "anonymous", src_ "https://assets-cdn.github.com/assets/compat-e42a8bf9c380758734e39851db04de7cbeeb2f3860efbd481c96ac12c25a6ecb.js" ] $ ""
            "\n    "
            script_ [ crossorigin_ "anonymous", src_ "https://assets-cdn.github.com/assets/frameworks-3907d9aad812b8c94147c88165cb4a9693c57cf99f0e8e01053fc79de7a9d911.js" ] $ ""
            "\n    \n    "
            script_ [ async_ "async", crossorigin_ "anonymous", src_ "https://assets-cdn.github.com/assets/github-c1b10da21f1932a4173fcfb60676e2ad32e515f7ae77563ddb658f04cd26368d.js" ] $ ""
            "\n    \n    \n    \n    \n  "
            div_ [ class_ "js-stale-session-flash stale-session-flash flash flash-warn flash-banner d-none" ] $ do
                "\n    "
                toHtmlRaw  "<!-- <svg aria-hidden=\"true\" class=\"octicon octicon-alert\" height=\"16\" version=\"1.1\" viewBox=\"0 0 16 16\" width=\"16\"><path fill-rule=\"evenodd\" d=\"M8.865 1.52c-.18-.31-.51-.5-.87-.5s-.69.19-.87.5L.275 13.5c-.18.31-.18.69 0 1 .19.31.52.5.87.5h13.7c.36 0 .69-.19.86-.5.17-.31.18-.69.01-1L8.865 1.52zM8.995 13h-2v-2h2v2zm0-3h-2V6h2v4z\"/></svg>\n    -->"
                "\n    "
                span_ [ class_ "signed-in-tab-flash" ] $ do
                    "You signed in with another tab or window. "
                    a_ [ href_ "" ] $ "Reload"
                    " to refresh your session."
                "\n    "
                span_ [ class_ "signed-out-tab-flash" ] $ do
                    "You signed out in another tab or window. "
                    a_ [ href_ "" ] $ "Reload"
                    " to refresh your session."
                "\n  "
            "\n  "
            div_ [ class_ "facebox", id_ "facebox", style_ "display:none;" ] $ do
                "\n  "
                div_ [ class_ "facebox-popup" ] $ do
                    "\n    "
                    div_ [ class_ "facebox-content", role_ "dialog", ariaLabelledby_ "facebox-header", ariaDescribedby_ "facebox-description" ] $ "\n    "
                    "\n    "
                    button_ [ type_ "button", class_ "facebox-close js-facebox-close", ariaLabel_ "Close modal" ] $ do
                        "\n      "
                        toHtmlRaw  "<!-- <svg aria-hidden=\"true\" class=\"octicon octicon-x\" height=\"16\" version=\"1.1\" viewBox=\"0 0 12 16\" width=\"12\"><path fill-rule=\"evenodd\" d=\"M7.48 8l3.75 3.75-1.48 1.48L6 9.48l-3.75 3.75-1.48-1.48L4.52 8 .77 4.25l1.48-1.48L6 6.52l3.75-3.75 1.48 1.48z\"/></svg>\n      -->"
                        "\n    "
                    "\n  "
                "\n"
            "\n\n\n  "
        "\n"
    "\n\n"

