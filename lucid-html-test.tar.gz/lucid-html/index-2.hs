{-# LANGUAGE OverloadedStrings, ExtendedDefaultRules #-}

import Lucid
import Lucid.Base
import Data.Text
import System.IO (stdout)
import Data.Text.Lazy.IO as L

main :: IO ()
main = L.hPutStr stdout (renderText template1)

ariaHidden_ :: Text -> Attribute
ariaHidden_ = makeAttribute "aria-hidden"

property_ :: Text -> Attribute
property_ = makeAttribute "property"

-- tag is deprecated
language_ :: Text -> Attribute
language_ = makeAttribute "language"

-- tag is obsolete!
align_ :: Text -> Attribute
align_ = makeAttribute "align"

-- Template for file: index.html
template1 :: Html ()
template1 = do
    doctype_
    html_ $ do
        head_ $ title_ "GHC Documentation"
        body_ $ do
            h1_ "GHC Documentation"
            p_ "Welcome to GHC!"
            p_ "This is the top of the GHC documentation tree, where you will find\n      links to all the supplied documentation about GHC and its libraries."
            ul_ $ do
                li_ $ do
                    p_ $ b_ $ a_ [ href_ "users_guide/index.html" ] $ "The User's Guide"
                    p_ "The User's Guide has all you need to know about using GHC:\n          command line options, language extensions, GHCi, etc."
                li_ $ do
                    p_ $ b_ $ a_ [ href_ "libraries/index.html" ] $ "Libraries"
                    p_ "Documentation for the libraries that come with GHC."
                li_ $ do
                    p_ $ b_ $ a_ [ href_ "libraries/ghc-8.2.1/index.html" ] $ "GHC API"
                    p_ "Documentation for the GHC API."
            p_ "For more information, see the following:"
            ul_ $ do
                li_ $ p_ $ a_ [ href_ "http://www.haskell.org/ghc/" ] $ "GHC Home Page"
                li_ $ p_ $ a_ [ href_ "http://ghc.haskell.org/trac/ghc/" ] $ "GHC Developers Home"

