{-# LANGUAGE OverloadedStrings, ExtendedDefaultRules #-}

import Lucid
import System.IO (stdout)
import qualified Data.Text.Lazy.IO as L

main :: IO ()
main = L.hPutStr stdout (renderText template1)

-- Template for file: /home/tim/ghc/share/doc/ghc-8.2.1/html/index.html
template1 :: Html ()
template1 = do
    doctype_
    html_ $ do
        head_ $ title_ "GHC Documentation"
        body_ $ do
            h1_ "GHC Documentation"
            p_ "Welcome to GHC!"
            p_ "This is the top of the GHC documentation tree, where you will find\n      links to all the supplied documentation about GHC and its libraries."
            ul_ $ do
                li_ $ do
                    p_ $ b_ $ a_ [ href_ "users_guide/index.html" ] $ "The User's Guide"
                    p_ "The User's Guide has all you need to know about using GHC:\n          command line options, language extensions, GHCi, etc."
                li_ $ do
                    p_ $ b_ $ a_ [ href_ "libraries/index.html" ] $ "Libraries"
                    p_ "Documentation for the libraries that come with GHC."
                li_ $ do
                    p_ $ b_ $ a_ [ href_ "libraries/ghc-8.2.1/index.html" ] $ "GHC API"
                    p_ "Documentation for the GHC API."
            p_ "For more information, see the following:"
            ul_ $ do
                li_ $ p_ $ a_ [ href_ "http://www.haskell.org/ghc/" ] $ "GHC Home Page"
                li_ $ p_ $ a_ [ href_ "http://ghc.haskell.org/trac/ghc/" ] $ "GHC Developers Home"

-- Template for file: /home/tim/ghc/share/doc/ghc-8.2.1/html/users_guide/index.html
template2 :: Html ()
template2 = do
    doctype_
    html_ [ xmlns_ "http://www.w3.org/1999/xhtml" ] $ do
        head_ $ do
            meta_ [ httpEquiv_ "Content-Type", content_ "text/html; charset=utf-8" ]
            title_ "Welcome to the GHC User’s Guide — Glasgow Haskell Compiler <release> User's Guide"
            link_ [ rel_ "stylesheet", href_ "_static/ghc-theme.css", type_ "text/css" ]
            link_ [ rel_ "stylesheet", href_ "_static/pygments.css", type_ "text/css" ]
            script_ [ type_ "text/javascript" ] $ "var DOCUMENTATION_OPTIONS = {\n        URL_ROOT:    './',\n        VERSION:     '8.2.1',\n        COLLAPSE_INDEX: false,\n        FILE_SUFFIX: '.html',\n        HAS_SOURCE:  true\n      };"
            script_ [ type_ "text/javascript", src_ "_static/jquery.js" ] $ ""
            script_ [ type_ "text/javascript", src_ "_static/underscore.js" ] $ ""
            script_ [ type_ "text/javascript", src_ "_static/doctools.js" ] $ ""
            link_ [ rel_ "search", type_ "application/opensearchdescription+xml", title_ "Search within Glasgow Haskell Compiler <release> User's Guide", href_ "_static/opensearch.xml" ]
            link_ [ rel_ "top", title_ "Glasgow Haskell Compiler <release> User's Guide", href_ "#" ]
            link_ [ rel_ "next", title_ "1. The Glasgow Haskell Compiler License", href_ "license.html" ]
        body_ $ do
            div_ [ class_ "logo" ] $ h1_ $ a_ [ href_ "#" ] $ "Glasgow Haskell Compiler User's Guide"
            div_ [ class_ "related" ] $ do
                h3_ "Navigation"
                ul_ $ do
                    li_ [ class_ "right", style_ "margin-right: 10px" ] $ a_ [ href_ "genindex.html", title_ "General Index", accesskey_ "I" ] $ "index"
                    li_ [ class_ "right" ] $ do
                        a_ [ href_ "license.html", title_ "1. The Glasgow Haskell Compiler License", accesskey_ "N" ] $ "next"
                        "|"
                    li_ $ do
                        a_ [ href_ "#" ] $ "GHC 8.2.1 User's Guide"
                        "»"
            div_ [ class_ "sphinxsidebar" ] $ div_ [ class_ "sphinxsidebarwrapper" ] $ do
                h3_ $ a_ [ href_ "#" ] $ "Table Of Contents"
                ul_ $ do
                    li_ $ a_ [ class_ "reference internal", href_ "#" ] $ "Welcome to the GHC User’s Guide"
                    li_ $ a_ [ class_ "reference internal", href_ "#indices-and-tables" ] $ "Indices and tables"
                h4_ "Next topic"
                p_ [ class_ "topless" ] $ a_ [ href_ "license.html", title_ "next chapter" ] $ "1. The Glasgow Haskell Compiler License"
                h3_ "This Page"
                ul_ [ class_ "this-page-menu" ] $ li_ $ a_ [ href_ "_sources/index.txt", rel_ "nofollow" ] $ "Show Source"
                div_ [ id_ "searchbox", style_ "display: none" ] $ do
                    h3_ "Quick search"
                    form_ [ class_ "search", action_ "search.html", method_ "get" ] $ do
                        input_ [ type_ "text", name_ "q" ]
                        input_ [ type_ "submit", value_ "Go" ]
                        input_ [ type_ "hidden", name_ "check_keywords", value_ "yes" ]
                        input_ [ type_ "hidden", name_ "area", value_ "default" ]
                    p_ [ class_ "searchtip", style_ "font-size: 90%" ] $ "Enter search terms or a module, class or function name."
                script_ [ type_ "text/javascript" ] $ "$('#searchbox').show(0);"
            div_ [ class_ "document" ] $ do
                div_ [ class_ "documentwrapper" ] $ div_ [ class_ "bodywrapper" ] $ div_ [ class_ "body" ] $ do
                    div_ [ class_ "section", id_ "welcome-to-the-ghc-user-s-guide" ] $ do
                        h1_ $ do
                            "Welcome to the GHC User’s Guide"
                            a_ [ class_ "headerlink", href_ "#welcome-to-the-ghc-user-s-guide", title_ "Permalink to this headline" ] $ "¶"
                        p_ "Contents:"
                        div_ [ class_ "toctree-wrapper compound" ] $ ul_ $ do
                            li_ [ class_ "toctree-l1" ] $ a_ [ class_ "reference internal", href_ "license.html" ] $ "1. The Glasgow Haskell Compiler License"
                            li_ [ class_ "toctree-l1" ] $ do
                                a_ [ class_ "reference internal", href_ "intro.html" ] $ "2. Introduction to GHC"
                                ul_ $ do
                                    li_ [ class_ "toctree-l2" ] $ a_ [ class_ "reference internal", href_ "intro.html#obtaining-ghc" ] $ "2.1. Obtaining GHC"
                                    li_ [ class_ "toctree-l2" ] $ a_ [ class_ "reference internal", href_ "intro.html#meta-information-web-sites-mailing-lists-etc" ] $ "2.2. Meta-information: Web sites, mailing lists, etc."
                                    li_ [ class_ "toctree-l2" ] $ a_ [ class_ "reference internal", href_ "intro.html#reporting-bugs-in-ghc" ] $ "2.3. Reporting bugs in GHC"
                                    li_ [ class_ "toctree-l2" ] $ a_ [ class_ "reference internal", href_ "intro.html#ghc-version-numbering-policy" ] $ "2.4. GHC version numbering policy"
                            li_ [ class_ "toctree-l1" ] $ do
                                a_ [ class_ "reference internal", href_ "8.2.1-notes.html" ] $ "3. Release notes for version 8.2.1"
                                ul_ $ do
                                    li_ [ class_ "toctree-l2" ] $ a_ [ class_ "reference internal", href_ "8.2.1-notes.html#highlights" ] $ "3.1. Highlights"
                                    li_ [ class_ "toctree-l2" ] $ do
                                        a_ [ class_ "reference internal", href_ "8.2.1-notes.html#full-details" ] $ "3.2. Full details"
                                        ul_ $ do
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "8.2.1-notes.html#language" ] $ "3.2.1. Language"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "8.2.1-notes.html#compiler" ] $ "3.2.2. Compiler"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "8.2.1-notes.html#ghci" ] $ "3.2.3. GHCi"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "8.2.1-notes.html#template-haskell" ] $ "3.2.4. Template Haskell"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "8.2.1-notes.html#runtime-system" ] $ "3.2.5. Runtime system"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "8.2.1-notes.html#hsc2hs" ] $ "3.2.6. hsc2hs"
                                    li_ [ class_ "toctree-l2" ] $ do
                                        a_ [ class_ "reference internal", href_ "8.2.1-notes.html#libraries" ] $ "3.3. Libraries"
                                        ul_ $ do
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "8.2.1-notes.html#array" ] $ "3.3.1. array"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "8.2.1-notes.html#base" ] $ "3.3.2. base"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "8.2.1-notes.html#binary" ] $ "3.3.3. binary"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "8.2.1-notes.html#bytestring" ] $ "3.3.4. bytestring"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "8.2.1-notes.html#cabal" ] $ "3.3.5. Cabal"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "8.2.1-notes.html#containers" ] $ "3.3.6. containers"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "8.2.1-notes.html#deepseq" ] $ "3.3.7. deepseq"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "8.2.1-notes.html#directory" ] $ "3.3.8. directory"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "8.2.1-notes.html#filepath" ] $ "3.3.9. filepath"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "8.2.1-notes.html#ghc" ] $ "3.3.10. ghc"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "8.2.1-notes.html#ghc-boot" ] $ "3.3.11. ghc-boot"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "8.2.1-notes.html#ghc-compact" ] $ "3.3.12. ghc-compact"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "8.2.1-notes.html#ghc-prim" ] $ "3.3.13. ghc-prim"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "8.2.1-notes.html#hoopl" ] $ "3.3.14. hoopl"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "8.2.1-notes.html#hpc" ] $ "3.3.15. hpc"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "8.2.1-notes.html#integer-gmp" ] $ "3.3.16. integer-gmp"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "8.2.1-notes.html#process" ] $ "3.3.17. process"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "8.2.1-notes.html#id1" ] $ "3.3.18. template-haskell"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "8.2.1-notes.html#time" ] $ "3.3.19. time"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "8.2.1-notes.html#unix" ] $ "3.3.20. unix"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "8.2.1-notes.html#win32" ] $ "3.3.21. Win32"
                                    li_ [ class_ "toctree-l2" ] $ a_ [ class_ "reference internal", href_ "8.2.1-notes.html#known-bugs" ] $ "3.4. Known bugs"
                            li_ [ class_ "toctree-l1" ] $ do
                                a_ [ class_ "reference internal", href_ "ghci.html" ] $ "4. Using GHCi"
                                ul_ $ do
                                    li_ [ class_ "toctree-l2" ] $ a_ [ class_ "reference internal", href_ "ghci.html#introduction-to-ghci" ] $ "4.1. Introduction to GHCi"
                                    li_ [ class_ "toctree-l2" ] $ do
                                        a_ [ class_ "reference internal", href_ "ghci.html#loading-source-files" ] $ "4.2. Loading source files"
                                        ul_ $ do
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "ghci.html#modules-vs-filenames" ] $ "4.2.1. Modules vs. filenames"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "ghci.html#making-changes-and-recompilation" ] $ "4.2.2. Making changes and recompilation"
                                    li_ [ class_ "toctree-l2" ] $ a_ [ class_ "reference internal", href_ "ghci.html#loading-compiled-code" ] $ "4.3. Loading compiled code"
                                    li_ [ class_ "toctree-l2" ] $ do
                                        a_ [ class_ "reference internal", href_ "ghci.html#interactive-evaluation-at-the-prompt" ] $ "4.4. Interactive evaluation at the prompt"
                                        ul_ $ do
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "ghci.html#i-o-actions-at-the-prompt" ] $ "4.4.1. I/O actions at the prompt"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "ghci.html#using-do-notation-at-the-prompt" ] $ do
                                                "4.4.2. Using"
                                                code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ "do"
                                                "notation at the prompt"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "ghci.html#multiline-input" ] $ "4.4.3. Multiline input"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "ghci.html#type-class-and-other-declarations" ] $ "4.4.4. Type, class and other declarations"
                                            li_ [ class_ "toctree-l3" ] $ do
                                                a_ [ class_ "reference internal", href_ "ghci.html#what-s-really-in-scope-at-the-prompt" ] $ "4.4.5. What’s really in scope at the prompt?"
                                                ul_ $ do
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "ghci.html#the-effect-of-load-on-what-is-in-scope" ] $ do
                                                        "4.4.5.1. The effect of"
                                                        code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ ":load"
                                                        "on what is in scope"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "ghci.html#controlling-what-is-in-scope-with-import" ] $ do
                                                        "4.4.5.2. Controlling what is in scope with"
                                                        code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ "import"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "ghci.html#controlling-what-is-in-scope-with-the-module-command" ] $ do
                                                        "4.4.5.3. Controlling what is in scope with the"
                                                        code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ ":module"
                                                        "command"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "ghci.html#qualified-names" ] $ "4.4.5.4. Qualified names"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "ghci.html#module-and-load" ] $ do
                                                        "4.4.5.5."
                                                        code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ ":module"
                                                        "and"
                                                        code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ ":load"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "ghci.html#the-main-and-run-commands" ] $ do
                                                "4.4.6. The"
                                                code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ ":main"
                                                "and"
                                                code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ ":run"
                                                "commands"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "ghci.html#the-it-variable" ] $ do
                                                "4.4.7. The"
                                                code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ "it"
                                                "variable"
                                            li_ [ class_ "toctree-l3" ] $ do
                                                a_ [ class_ "reference internal", href_ "ghci.html#type-defaulting-in-ghci" ] $ "4.4.8. Type defaulting in GHCi"
                                                ul_ $ do
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "ghci.html#interactive-classes" ] $ "4.4.8.1. Interactive classes"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "ghci.html#extended-rules-around-default-declarations" ] $ do
                                                        "4.4.8.2. Extended rules around"
                                                        code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ "default"
                                                        "declarations"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "ghci.html#using-a-custom-interactive-printing-function" ] $ "4.4.9. Using a custom interactive printing function"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "ghci.html#stack-traces-in-ghci" ] $ "4.4.10. Stack Traces in GHCi"
                                    li_ [ class_ "toctree-l2" ] $ do
                                        a_ [ class_ "reference internal", href_ "ghci.html#the-ghci-debugger" ] $ "4.5. The GHCi Debugger"
                                        ul_ $ do
                                            li_ [ class_ "toctree-l3" ] $ do
                                                a_ [ class_ "reference internal", href_ "ghci.html#breakpoints-and-inspecting-variables" ] $ "4.5.1. Breakpoints and inspecting variables"
                                                ul_ $ do
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "ghci.html#setting-breakpoints" ] $ "4.5.1.1. Setting breakpoints"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "ghci.html#listing-and-deleting-breakpoints" ] $ "4.5.1.2. Listing and deleting breakpoints"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "ghci.html#single-stepping" ] $ "4.5.2. Single-stepping"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "ghci.html#nested-breakpoints" ] $ "4.5.3. Nested breakpoints"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "ghci.html#the-result-variable" ] $ do
                                                "4.5.4. The"
                                                code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ "_result"
                                                "variable"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "ghci.html#tracing-and-history" ] $ "4.5.5. Tracing and history"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "ghci.html#debugging-exceptions" ] $ "4.5.6. Debugging exceptions"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "ghci.html#example-inspecting-functions" ] $ "4.5.7. Example: inspecting functions"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "ghci.html#limitations" ] $ "4.5.8. Limitations"
                                    li_ [ class_ "toctree-l2" ] $ do
                                        a_ [ class_ "reference internal", href_ "ghci.html#invoking-ghci" ] $ "4.6. Invoking GHCi"
                                        ul_ $ do
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "ghci.html#packages" ] $ "4.6.1. Packages"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "ghci.html#extra-libraries" ] $ "4.6.2. Extra libraries"
                                    li_ [ class_ "toctree-l2" ] $ a_ [ class_ "reference internal", href_ "ghci.html#ghci-commands" ] $ "4.7. GHCi commands"
                                    li_ [ class_ "toctree-l2" ] $ do
                                        a_ [ class_ "reference internal", href_ "ghci.html#the-set-and-seti-commands" ] $ do
                                            "4.8. The"
                                            code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ ":set"
                                            "and"
                                            code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ ":seti"
                                            "commands"
                                        ul_ $ do
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "ghci.html#ghci-options" ] $ "4.8.1. GHCi options"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "ghci.html#setting-ghc-command-line-options-in-ghci" ] $ "4.8.2. Setting GHC command-line options in GHCi"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "ghci.html#setting-options-for-interactive-evaluation-only" ] $ "4.8.3. Setting options for interactive evaluation only"
                                    li_ [ class_ "toctree-l2" ] $ do
                                        a_ [ class_ "reference internal", href_ "ghci.html#the-ghci-and-haskeline-files" ] $ do
                                            "4.9. The"
                                            code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ ".ghci"
                                            "and"
                                            code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ ".haskeline"
                                            "files"
                                        ul_ $ do
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "ghci.html#the-ghci-files" ] $ do
                                                "4.9.1. The"
                                                code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ ".ghci"
                                                "files"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "ghci.html#the-haskeline-file" ] $ do
                                                "4.9.2. The"
                                                code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ ".haskeline"
                                                "file"
                                    li_ [ class_ "toctree-l2" ] $ a_ [ class_ "reference internal", href_ "ghci.html#compiling-to-object-code-inside-ghci" ] $ "4.10. Compiling to object code inside GHCi"
                                    li_ [ class_ "toctree-l2" ] $ a_ [ class_ "reference internal", href_ "ghci.html#running-the-interpreter-in-a-separate-process" ] $ "4.11. Running the interpreter in a separate process"
                                    li_ [ class_ "toctree-l2" ] $ a_ [ class_ "reference internal", href_ "ghci.html#faq-and-things-to-watch-out-for" ] $ "4.12. FAQ and Things To Watch Out For"
                            li_ [ class_ "toctree-l1" ] $ do
                                a_ [ class_ "reference internal", href_ "runghc.html" ] $ "5. Using runghc"
                                ul_ $ do
                                    li_ [ class_ "toctree-l2" ] $ a_ [ class_ "reference internal", href_ "runghc.html#usage" ] $ "5.1. Usage"
                                    li_ [ class_ "toctree-l2" ] $ a_ [ class_ "reference internal", href_ "runghc.html#runghc-flags" ] $ "5.2. runghc flags"
                                    li_ [ class_ "toctree-l2" ] $ a_ [ class_ "reference internal", href_ "runghc.html#ghc-flags" ] $ "5.3. GHC Flags"
                            li_ [ class_ "toctree-l1" ] $ do
                                a_ [ class_ "reference internal", href_ "usage.html" ] $ "6. Using GHC"
                                ul_ $ do
                                    li_ [ class_ "toctree-l2" ] $ do
                                        a_ [ class_ "reference internal", href_ "using.html" ] $ "6.1. Using GHC"
                                        ul_ $ do
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "using.html#getting-started-compiling-programs" ] $ "6.1.1. Getting started: compiling programs"
                                            li_ [ class_ "toctree-l3" ] $ do
                                                a_ [ class_ "reference internal", href_ "using.html#options-overview" ] $ "6.1.2. Options overview"
                                                ul_ $ do
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "using.html#command-line-arguments" ] $ "6.1.2.1. Command-line arguments"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "using.html#command-line-options-in-source-files" ] $ "6.1.2.2. Command line options in source files"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "using.html#setting-options-in-ghci" ] $ "6.1.2.3. Setting options in GHCi"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "using.html#static-dynamic-and-mode-options" ] $ "6.1.3. Static, Dynamic, and Mode options"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "using.html#meaningful-file-suffixes" ] $ "6.1.4. Meaningful file suffixes"
                                            li_ [ class_ "toctree-l3" ] $ do
                                                a_ [ class_ "reference internal", href_ "using.html#modes-of-operation" ] $ "6.1.5. Modes of operation"
                                                ul_ $ do
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "using.html#using-ghc-make" ] $ do
                                                        "6.1.5.1. Using"
                                                        code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ "ghc"
                                                        code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ "--make"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "using.html#expression-evaluation-mode" ] $ "6.1.5.2. Expression evaluation mode"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "using.html#batch-compiler-mode" ] $ "6.1.5.3. Batch compiler mode"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "using.html#verbosity-options" ] $ "6.1.6. Verbosity options"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "using.html#platform-specific-flags" ] $ "6.1.7. Platform-specific Flags"
                                    li_ [ class_ "toctree-l2" ] $ a_ [ class_ "reference internal", href_ "using-warnings.html" ] $ "6.2. Warnings and sanity-checking"
                                    li_ [ class_ "toctree-l2" ] $ do
                                        a_ [ class_ "reference internal", href_ "using-optimisation.html" ] $ "6.3. Optimisation (code improvement)"
                                        ul_ $ do
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "using-optimisation.html#o-convenient-packages-of-optimisation-flags" ] $ do
                                                "6.3.1."
                                                code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ "-O*"
                                                ": convenient “packages” of optimisation flags."
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "using-optimisation.html#f-platform-independent-flags" ] $ do
                                                "6.3.2."
                                                code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ "-f*"
                                                ": platform-independent flags"
                                    li_ [ class_ "toctree-l2" ] $ a_ [ class_ "reference internal", href_ "using-concurrent.html" ] $ "6.4. Using Concurrent Haskell"
                                    li_ [ class_ "toctree-l2" ] $ do
                                        a_ [ class_ "reference internal", href_ "using-concurrent.html#using-smp-parallelism" ] $ "6.5. Using SMP parallelism"
                                        ul_ $ do
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "using-concurrent.html#compile-time-options-for-smp-parallelism" ] $ "6.5.1. Compile-time options for SMP parallelism"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "using-concurrent.html#rts-options-for-smp-parallelism" ] $ "6.5.2. RTS options for SMP parallelism"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "using-concurrent.html#hints-for-using-smp-parallelism" ] $ "6.5.3. Hints for using SMP parallelism"
                                    li_ [ class_ "toctree-l2" ] $ do
                                        a_ [ class_ "reference internal", href_ "flags.html" ] $ "6.6. Flag reference"
                                        ul_ $ do
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "flags.html#verbosity-options" ] $ "6.6.1. Verbosity options"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "flags.html#alternative-modes-of-operation" ] $ "6.6.2. Alternative modes of operation"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "flags.html#which-phases-to-run" ] $ "6.6.3. Which phases to run"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "flags.html#redirecting-output" ] $ "6.6.4. Redirecting output"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "flags.html#keeping-intermediate-files" ] $ "6.6.5. Keeping intermediate files"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "flags.html#temporary-files" ] $ "6.6.6. Temporary files"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "flags.html#finding-imports" ] $ "6.6.7. Finding imports"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "flags.html#interface-file-options" ] $ "6.6.8. Interface file options"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "flags.html#recompilation-checking" ] $ "6.6.9. Recompilation checking"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "flags.html#interactive-mode-options" ] $ "6.6.10. Interactive-mode options"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "flags.html#packages" ] $ "6.6.11. Packages"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "flags.html#language-options" ] $ "6.6.12. Language options"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "flags.html#warnings" ] $ "6.6.13. Warnings"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "flags.html#optimisation-levels" ] $ "6.6.14. Optimisation levels"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "flags.html#individual-optimisations" ] $ "6.6.15. Individual optimisations"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "flags.html#profiling-options" ] $ "6.6.16. Profiling options"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "flags.html#program-coverage-options" ] $ "6.6.17. Program coverage options"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "flags.html#c-pre-processor-options" ] $ "6.6.18. C pre-processor options"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "flags.html#code-generation-options" ] $ "6.6.19. Code generation options"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "flags.html#linking-options" ] $ "6.6.20. Linking options"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "flags.html#plugin-options" ] $ "6.6.21. Plugin options"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "flags.html#replacing-phases" ] $ "6.6.22. Replacing phases"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "flags.html#forcing-options-to-particular-phases" ] $ "6.6.23. Forcing options to particular phases"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "flags.html#platform-specific-options" ] $ "6.6.24. Platform-specific options"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "flags.html#compiler-debugging-options" ] $ "6.6.25. Compiler debugging options"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "flags.html#miscellaneous-compiler-options" ] $ "6.6.26. Miscellaneous compiler options"
                                    li_ [ class_ "toctree-l2" ] $ do
                                        a_ [ class_ "reference internal", href_ "runtime_control.html" ] $ "6.7. Running a compiled program"
                                        ul_ $ do
                                            li_ [ class_ "toctree-l3" ] $ do
                                                a_ [ class_ "reference internal", href_ "runtime_control.html#setting-rts-options" ] $ "6.7.1. Setting RTS options"
                                                ul_ $ do
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "runtime_control.html#setting-rts-options-on-the-command-line" ] $ "6.7.1.1. Setting RTS options on the command line"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "runtime_control.html#setting-rts-options-at-compile-time" ] $ "6.7.1.2. Setting RTS options at compile time"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "runtime_control.html#setting-rts-options-with-the-ghcrts-environment-variable" ] $ do
                                                        "6.7.1.3. Setting RTS options with the"
                                                        code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ "GHCRTS"
                                                        "environment variable"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "runtime_control.html#hooks-to-change-rts-behaviour" ] $ "6.7.1.4. “Hooks” to change RTS behaviour"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "runtime_control.html#miscellaneous-rts-options" ] $ "6.7.2. Miscellaneous RTS options"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "runtime_control.html#rts-options-to-control-the-garbage-collector" ] $ "6.7.3. RTS options to control the garbage collector"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "runtime_control.html#rts-options-to-produce-runtime-statistics" ] $ "6.7.4. RTS options to produce runtime statistics"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "runtime_control.html#rts-options-for-concurrency-and-parallelism" ] $ "6.7.5. RTS options for concurrency and parallelism"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "runtime_control.html#rts-options-for-profiling" ] $ "6.7.6. RTS options for profiling"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "runtime_control.html#tracing" ] $ "6.7.7. Tracing"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "runtime_control.html#rts-options-for-hackers-debuggers-and-over-interested-souls" ] $ "6.7.8. RTS options for hackers, debuggers, and over-interested souls"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "runtime_control.html#getting-information-about-the-rts" ] $ "6.7.9. Getting information about the RTS"
                                    li_ [ class_ "toctree-l2" ] $ do
                                        a_ [ class_ "reference internal", href_ "separate_compilation.html" ] $ "6.8. Filenames and separate compilation"
                                        ul_ $ do
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "separate_compilation.html#haskell-source-files" ] $ "6.8.1. Haskell source files"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "separate_compilation.html#output-files" ] $ "6.8.2. Output files"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "separate_compilation.html#the-search-path" ] $ "6.8.3. The search path"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "separate_compilation.html#redirecting-the-compilation-output-s" ] $ "6.8.4. Redirecting the compilation output(s)"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "separate_compilation.html#keeping-intermediate-files" ] $ "6.8.5. Keeping Intermediate Files"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "separate_compilation.html#redirecting-temporary-files" ] $ "6.8.6. Redirecting temporary files"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "separate_compilation.html#other-options-related-to-interface-files" ] $ "6.8.7. Other options related to interface files"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "separate_compilation.html#the-recompilation-checker" ] $ "6.8.8. The recompilation checker"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "separate_compilation.html#how-to-compile-mutually-recursive-modules" ] $ "6.8.9. How to compile mutually recursive modules"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "separate_compilation.html#module-signatures" ] $ "6.8.10. Module signatures"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "separate_compilation.html#using-make" ] $ do
                                                "6.8.11. Using"
                                                code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ "make"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "separate_compilation.html#dependency-generation" ] $ "6.8.12. Dependency generation"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "separate_compilation.html#orphan-modules-and-instance-declarations" ] $ "6.8.13. Orphan modules and instance declarations"
                                    li_ [ class_ "toctree-l2" ] $ do
                                        a_ [ class_ "reference internal", href_ "packages.html" ] $ "6.9. Packages"
                                        ul_ $ do
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "packages.html#using-packages" ] $ "6.9.1. Using Packages"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "packages.html#the-main-package" ] $ do
                                                "6.9.2. The"
                                                code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ "main"
                                                "package"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "packages.html#consequences-of-packages-for-the-haskell-language" ] $ "6.9.3. Consequences of packages for the Haskell language"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "packages.html#thinning-and-renaming-modules" ] $ "6.9.4. Thinning and renaming modules"
                                            li_ [ class_ "toctree-l3" ] $ do
                                                a_ [ class_ "reference internal", href_ "packages.html#package-databases" ] $ "6.9.5. Package Databases"
                                                ul_ $ do
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "packages.html#the-ghc-package-path-environment-variable" ] $ do
                                                        "6.9.5.1. The"
                                                        code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ "GHC_PACKAGE_PATH"
                                                        "environment variable"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "packages.html#package-environments" ] $ "6.9.5.2. Package environments"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "packages.html#installed-package-ids-dependencies-and-broken-packages" ] $ "6.9.6. Installed package IDs, dependencies, and broken packages"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "packages.html#package-management-the-ghc-pkg-command" ] $ do
                                                "6.9.7. Package management (the"
                                                code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ "ghc-pkg"
                                                "command)"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "packages.html#building-a-package-from-haskell-source" ] $ "6.9.8. Building a package from Haskell source"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "packages.html#installedpackageinfo-a-package-specification" ] $ do
                                                "6.9.9."
                                                code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ "InstalledPackageInfo"
                                                ": a package specification"
                                    li_ [ class_ "toctree-l2" ] $ do
                                        a_ [ class_ "reference internal", href_ "codegens.html" ] $ "6.10. GHC Backends"
                                        ul_ $ do
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "codegens.html#native-code-generator-fasm" ] $ do
                                                "6.10.1. Native code Generator ("
                                                code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ "-fasm"
                                                ")"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "codegens.html#llvm-code-generator-fllvm" ] $ do
                                                "6.10.2. LLVM Code Generator ("
                                                code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ "-fllvm"
                                                ")"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "codegens.html#c-code-generator-fvia-c" ] $ do
                                                "6.10.3. C Code Generator ("
                                                code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ "-fvia-C"
                                                ")"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "codegens.html#unregisterised-compilation" ] $ "6.10.4. Unregisterised compilation"
                                    li_ [ class_ "toctree-l2" ] $ do
                                        a_ [ class_ "reference internal", href_ "phases.html" ] $ "6.11. Options related to a particular phase"
                                        ul_ $ do
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "phases.html#replacing-the-program-for-one-or-more-phases" ] $ "6.11.1. Replacing the program for one or more phases"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "phases.html#forcing-options-to-a-particular-phase" ] $ "6.11.2. Forcing options to a particular phase"
                                            li_ [ class_ "toctree-l3" ] $ do
                                                a_ [ class_ "reference internal", href_ "phases.html#options-affecting-the-c-pre-processor" ] $ "6.11.3. Options affecting the C pre-processor"
                                                ul_ $ do
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "phases.html#standard-cpp-macros" ] $ "6.11.3.1. Standard CPP macros"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "phases.html#cpp-and-string-gaps" ] $ "6.11.3.2. CPP and string gaps"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "phases.html#options-affecting-a-haskell-pre-processor" ] $ "6.11.4. Options affecting a Haskell pre-processor"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "phases.html#options-affecting-code-generation" ] $ "6.11.5. Options affecting code generation"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "phases.html#options-affecting-linking" ] $ "6.11.6. Options affecting linking"
                                    li_ [ class_ "toctree-l2" ] $ do
                                        a_ [ class_ "reference internal", href_ "shared_libs.html" ] $ "6.12. Using shared libraries"
                                        ul_ $ do
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "shared_libs.html#building-programs-that-use-shared-libraries" ] $ "6.12.1. Building programs that use shared libraries"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "shared_libs.html#shared-libraries-for-haskell-packages" ] $ "6.12.2. Shared libraries for Haskell packages"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "shared_libs.html#shared-libraries-that-export-a-c-api" ] $ "6.12.3. Shared libraries that export a C API"
                                            li_ [ class_ "toctree-l3" ] $ do
                                                a_ [ class_ "reference internal", href_ "shared_libs.html#finding-shared-libraries-at-runtime" ] $ "6.12.4. Finding shared libraries at runtime"
                                                ul_ $ do
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "shared_libs.html#unix" ] $ "6.12.4.1. Unix"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "shared_libs.html#mac-os-x" ] $ "6.12.4.2. Mac OS X"
                                    li_ [ class_ "toctree-l2" ] $ do
                                        a_ [ class_ "reference internal", href_ "debugging.html" ] $ "6.13. Debugging the compiler"
                                        ul_ $ do
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "debugging.html#dumping-out-compiler-intermediate-structures" ] $ "6.13.1. Dumping out compiler intermediate structures"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "debugging.html#formatting-dumps" ] $ "6.13.2. Formatting dumps"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "debugging.html#suppressing-unwanted-information" ] $ "6.13.3. Suppressing unwanted information"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "debugging.html#checking-for-consistency" ] $ "6.13.4. Checking for consistency"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "debugging.html#checking-for-determinism" ] $ "6.13.5. Checking for determinism"
                            li_ [ class_ "toctree-l1" ] $ do
                                a_ [ class_ "reference internal", href_ "profiling.html" ] $ "7. Profiling"
                                ul_ $ do
                                    li_ [ class_ "toctree-l2" ] $ do
                                        a_ [ class_ "reference internal", href_ "profiling.html#cost-centres-and-cost-centre-stacks" ] $ "7.1. Cost centres and cost-centre stacks"
                                        ul_ $ do
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "profiling.html#inserting-cost-centres-by-hand" ] $ "7.1.1. Inserting cost centres by hand"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "profiling.html#rules-for-attributing-costs" ] $ "7.1.2. Rules for attributing costs"
                                    li_ [ class_ "toctree-l2" ] $ a_ [ class_ "reference internal", href_ "profiling.html#compiler-options-for-profiling" ] $ "7.2. Compiler options for profiling"
                                    li_ [ class_ "toctree-l2" ] $ do
                                        a_ [ class_ "reference internal", href_ "profiling.html#time-and-allocation-profiling" ] $ "7.3. Time and allocation profiling"
                                        ul_ $ li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "profiling.html#json-profile-format" ] $ "7.3.1. JSON profile format"
                                    li_ [ class_ "toctree-l2" ] $ do
                                        a_ [ class_ "reference internal", href_ "profiling.html#profiling-memory-usage" ] $ "7.4. Profiling memory usage"
                                        ul_ $ do
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "profiling.html#rts-options-for-heap-profiling" ] $ "7.4.1. RTS options for heap profiling"
                                            li_ [ class_ "toctree-l3" ] $ do
                                                a_ [ class_ "reference internal", href_ "profiling.html#retainer-profiling" ] $ "7.4.2. Retainer Profiling"
                                                ul_ $ li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "profiling.html#hints-for-using-retainer-profiling" ] $ "7.4.2.1. Hints for using retainer profiling"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "profiling.html#biographical-profiling" ] $ "7.4.3. Biographical Profiling"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "profiling.html#actual-memory-residency" ] $ "7.4.4. Actual memory residency"
                                    li_ [ class_ "toctree-l2" ] $ do
                                        a_ [ class_ "reference internal", href_ "profiling.html#hp2ps-rendering-heap-profiles-to-postscript" ] $ do
                                            "7.5."
                                            code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ "hp2ps"
                                            "– Rendering heap profiles to PostScript"
                                        ul_ $ do
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "profiling.html#manipulating-the-hp-file" ] $ do
                                                "7.5.1. Manipulating the"
                                                code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ "hp"
                                                "file"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "profiling.html#zooming-in-on-regions-of-your-profile" ] $ "7.5.2. Zooming in on regions of your profile"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "profiling.html#viewing-the-heap-profile-of-a-running-program" ] $ "7.5.3. Viewing the heap profile of a running program"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "profiling.html#viewing-a-heap-profile-in-real-time" ] $ "7.5.4. Viewing a heap profile in real time"
                                    li_ [ class_ "toctree-l2" ] $ a_ [ class_ "reference internal", href_ "profiling.html#profiling-parallel-and-concurrent-programs" ] $ "7.6. Profiling Parallel and Concurrent Programs"
                                    li_ [ class_ "toctree-l2" ] $ do
                                        a_ [ class_ "reference internal", href_ "profiling.html#observing-code-coverage" ] $ "7.7. Observing Code Coverage"
                                        ul_ $ do
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "profiling.html#a-small-example-reciprocation" ] $ "7.7.1. A small example: Reciprocation"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "profiling.html#options-for-instrumenting-code-for-coverage" ] $ "7.7.2. Options for instrumenting code for coverage"
                                            li_ [ class_ "toctree-l3" ] $ do
                                                a_ [ class_ "reference internal", href_ "profiling.html#the-hpc-toolkit" ] $ "7.7.3. The hpc toolkit"
                                                ul_ $ do
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "profiling.html#hpc-report" ] $ "7.7.3.1. hpc report"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "profiling.html#hpc-markup" ] $ "7.7.3.2. hpc markup"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "profiling.html#hpc-sum" ] $ "7.7.3.3. hpc sum"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "profiling.html#hpc-combine" ] $ "7.7.3.4. hpc combine"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "profiling.html#hpc-map" ] $ "7.7.3.5. hpc map"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "profiling.html#hpc-overlay-and-hpc-draft" ] $ "7.7.3.6. hpc overlay and hpc draft"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "profiling.html#caveats-and-shortcomings-of-haskell-program-coverage" ] $ "7.7.4. Caveats and Shortcomings of Haskell Program Coverage"
                                    li_ [ class_ "toctree-l2" ] $ a_ [ class_ "reference internal", href_ "profiling.html#using-ticky-ticky-profiling-for-implementors" ] $ "7.8. Using “ticky-ticky” profiling (for implementors)"
                            li_ [ class_ "toctree-l1" ] $ do
                                a_ [ class_ "reference internal", href_ "sooner.html" ] $ "8. Advice on: sooner, faster, smaller, thriftier"
                                ul_ $ do
                                    li_ [ class_ "toctree-l2" ] $ a_ [ class_ "reference internal", href_ "sooner.html#sooner-producing-a-program-more-quickly" ] $ "8.1. Sooner: producing a program more quickly"
                                    li_ [ class_ "toctree-l2" ] $ a_ [ class_ "reference internal", href_ "sooner.html#faster-producing-a-program-that-runs-quicker" ] $ "8.2. Faster: producing a program that runs quicker"
                                    li_ [ class_ "toctree-l2" ] $ a_ [ class_ "reference internal", href_ "sooner.html#smaller-producing-a-program-that-is-smaller" ] $ "8.3. Smaller: producing a program that is smaller"
                                    li_ [ class_ "toctree-l2" ] $ a_ [ class_ "reference internal", href_ "sooner.html#thriftier-producing-a-program-that-gobbles-less-heap-space" ] $ "8.4. Thriftier: producing a program that gobbles less heap space"
                            li_ [ class_ "toctree-l1" ] $ do
                                a_ [ class_ "reference internal", href_ "lang.html" ] $ "9. GHC Language Features"
                                ul_ $ do
                                    li_ [ class_ "toctree-l2" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html" ] $ "9.1. Language options"
                                    li_ [ class_ "toctree-l2" ] $ do
                                        a_ [ class_ "reference internal", href_ "glasgow_exts.html#unboxed-types-and-primitive-operations" ] $ "9.2. Unboxed types and primitive operations"
                                        ul_ $ do
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#unboxed-types" ] $ "9.2.1. Unboxed types"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#unboxed-type-kinds" ] $ "9.2.2. Unboxed type kinds"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#unboxed-tuples" ] $ "9.2.3. Unboxed tuples"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#unboxed-sums" ] $ "9.2.4. Unboxed sums"
                                    li_ [ class_ "toctree-l2" ] $ do
                                        a_ [ class_ "reference internal", href_ "glasgow_exts.html#syntactic-extensions" ] $ "9.3. Syntactic extensions"
                                        ul_ $ do
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#unicode-syntax" ] $ "9.3.1. Unicode syntax"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#the-magic-hash" ] $ "9.3.2. The magic hash"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#negative-literals" ] $ "9.3.3. Negative literals"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#fractional-looking-integer-literals" ] $ "9.3.4. Fractional looking integer literals"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#binary-integer-literals" ] $ "9.3.5. Binary integer literals"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#pattern-guards" ] $ "9.3.6. Pattern guards"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#view-patterns" ] $ "9.3.7. View patterns"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#n-k-patterns" ] $ "9.3.8. n+k patterns"
                                            li_ [ class_ "toctree-l3" ] $ do
                                                a_ [ class_ "reference internal", href_ "glasgow_exts.html#the-recursive-do-notation" ] $ "9.3.9. The recursive do-notation"
                                                ul_ $ do
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#recursive-binding-groups" ] $ "9.3.9.1. Recursive binding groups"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#the-mdo-notation" ] $ do
                                                        "9.3.9.2. The"
                                                        code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ "mdo"
                                                        "notation"
                                            li_ [ class_ "toctree-l3" ] $ do
                                                a_ [ class_ "reference internal", href_ "glasgow_exts.html#applicative-do-notation" ] $ "9.3.10. Applicative do-notation"
                                                ul_ $ do
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#existential-patterns-and-gadts" ] $ "9.3.10.1. Existential patterns and GADTs"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#things-to-watch-out-for" ] $ "9.3.10.2. Things to watch out for"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#parallel-list-comprehensions" ] $ "9.3.11. Parallel List Comprehensions"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#generalised-sql-like-list-comprehensions" ] $ "9.3.12. Generalised (SQL-like) List Comprehensions"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#monad-comprehensions" ] $ "9.3.13. Monad comprehensions"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#new-monadic-failure-desugaring-mechanism" ] $ "9.3.14. New monadic failure desugaring mechanism"
                                            li_ [ class_ "toctree-l3" ] $ do
                                                a_ [ class_ "reference internal", href_ "glasgow_exts.html#rebindable-syntax-and-the-implicit-prelude-import" ] $ "9.3.15. Rebindable syntax and the implicit Prelude import"
                                                ul_ $ li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#things-unaffected-by-xrebindablesyntax" ] $ do
                                                    "9.3.15.1. Things unaffected by"
                                                    code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ "-XRebindableSyntax"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#postfix-operators" ] $ "9.3.16. Postfix operators"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#tuple-sections" ] $ "9.3.17. Tuple sections"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#lambda-case" ] $ "9.3.18. Lambda-case"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#empty-case-alternatives" ] $ "9.3.19. Empty case alternatives"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#multi-way-if-expressions" ] $ "9.3.20. Multi-way if-expressions"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#local-fixity-declarations" ] $ "9.3.21. Local Fixity Declarations"
                                            li_ [ class_ "toctree-l3" ] $ do
                                                a_ [ class_ "reference internal", href_ "glasgow_exts.html#import-and-export-extensions" ] $ "9.3.22. Import and export extensions"
                                                ul_ $ do
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#hiding-things-the-imported-module-doesn-t-export" ] $ "9.3.22.1. Hiding things the imported module doesn’t export"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#package-qualified-imports" ] $ "9.3.22.2. Package-qualified imports"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#safe-imports" ] $ "9.3.22.3. Safe imports"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#explicit-namespaces-in-import-export" ] $ "9.3.22.4. Explicit namespaces in import/export"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#summary-of-stolen-syntax" ] $ "9.3.23. Summary of stolen syntax"
                                    li_ [ class_ "toctree-l2" ] $ do
                                        a_ [ class_ "reference internal", href_ "glasgow_exts.html#extensions-to-data-types-and-type-synonyms" ] $ "9.4. Extensions to data types and type synonyms"
                                        ul_ $ do
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#data-types-with-no-constructors" ] $ "9.4.1. Data types with no constructors"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#data-type-contexts" ] $ "9.4.2. Data type contexts"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#infix-type-constructors-classes-and-type-variables" ] $ "9.4.3. Infix type constructors, classes, and type variables"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#type-operators" ] $ "9.4.4. Type operators"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#liberalised-type-synonyms" ] $ "9.4.5. Liberalised type synonyms"
                                            li_ [ class_ "toctree-l3" ] $ do
                                                a_ [ class_ "reference internal", href_ "glasgow_exts.html#existentially-quantified-data-constructors" ] $ "9.4.6. Existentially quantified data constructors"
                                                ul_ $ do
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#why-existential" ] $ "9.4.6.1. Why existential?"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#existentials-and-type-classes" ] $ "9.4.6.2. Existentials and type classes"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#record-constructors" ] $ "9.4.6.3. Record Constructors"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#restrictions" ] $ "9.4.6.4. Restrictions"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#declaring-data-types-with-explicit-constructor-signatures" ] $ "9.4.7. Declaring data types with explicit constructor signatures"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#generalised-algebraic-data-types-gadts" ] $ "9.4.8. Generalised Algebraic Data Types (GADTs)"
                                    li_ [ class_ "toctree-l2" ] $ do
                                        a_ [ class_ "reference internal", href_ "glasgow_exts.html#extensions-to-the-record-system" ] $ "9.5. Extensions to the record system"
                                        ul_ $ do
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#traditional-record-syntax" ] $ "9.5.1. Traditional record syntax"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#record-field-disambiguation" ] $ "9.5.2. Record field disambiguation"
                                            li_ [ class_ "toctree-l3" ] $ do
                                                a_ [ class_ "reference internal", href_ "glasgow_exts.html#duplicate-record-fields" ] $ "9.5.3. Duplicate record fields"
                                                ul_ $ do
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#selector-functions" ] $ "9.5.3.1. Selector functions"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#record-updates" ] $ "9.5.3.2. Record updates"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#import-and-export-of-record-fields" ] $ "9.5.3.3. Import and export of record fields"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#record-puns" ] $ "9.5.4. Record puns"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#record-wildcards" ] $ "9.5.5. Record wildcards"
                                            li_ [ class_ "toctree-l3" ] $ do
                                                a_ [ class_ "reference internal", href_ "glasgow_exts.html#record-field-selector-polymorphism" ] $ "9.5.6. Record field selector polymorphism"
                                                ul_ $ do
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#solving-hasfield-constraints" ] $ "9.5.6.1. Solving HasField constraints"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#virtual-record-fields" ] $ "9.5.6.2. Virtual record fields"
                                    li_ [ class_ "toctree-l2" ] $ do
                                        a_ [ class_ "reference internal", href_ "glasgow_exts.html#extensions-to-the-deriving-mechanism" ] $ "9.6. Extensions to the “deriving” mechanism"
                                        ul_ $ do
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#inferred-context-for-deriving-clauses" ] $ "9.6.1. Inferred context for deriving clauses"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#stand-alone-deriving-declarations" ] $ "9.6.2. Stand-alone deriving declarations"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#deriving-instances-of-extra-classes-data-etc" ] $ do
                                                "9.6.3. Deriving instances of extra classes ("
                                                code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ "Data"
                                                ", etc.)"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#deriving-functor-instances" ] $ do
                                                "9.6.4. Deriving"
                                                code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ "Functor"
                                                "instances"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#deriving-foldable-instances" ] $ do
                                                "9.6.5. Deriving"
                                                code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ "Foldable"
                                                "instances"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#deriving-traversable-instances" ] $ do
                                                "9.6.6. Deriving"
                                                code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ "Traversable"
                                                "instances"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#deriving-data-instances" ] $ do
                                                "9.6.7. Deriving"
                                                code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ "Data"
                                                "instances"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#deriving-typeable-instances" ] $ do
                                                "9.6.8. Deriving"
                                                code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ "Typeable"
                                                "instances"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#deriving-lift-instances" ] $ do
                                                "9.6.9. Deriving"
                                                code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ "Lift"
                                                "instances"
                                            li_ [ class_ "toctree-l3" ] $ do
                                                a_ [ class_ "reference internal", href_ "glasgow_exts.html#generalised-derived-instances-for-newtypes" ] $ "9.6.10. Generalised derived instances for newtypes"
                                                ul_ $ do
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#generalising-the-deriving-clause" ] $ "9.6.10.1. Generalising the deriving clause"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#a-more-precise-specification" ] $ "9.6.10.2. A more precise specification"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#associated-type-families" ] $ "9.6.10.3. Associated type families"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#deriving-any-other-class" ] $ "9.6.11. Deriving any other class"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#deriving-strategies" ] $ "9.6.12. Deriving strategies"
                                    li_ [ class_ "toctree-l2" ] $ do
                                        a_ [ class_ "reference internal", href_ "glasgow_exts.html#pattern-synonyms" ] $ "9.7. Pattern synonyms"
                                        ul_ $ do
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#record-pattern-synonyms" ] $ "9.7.1. Record Pattern Synonyms"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#syntax-and-scoping-of-pattern-synonyms" ] $ "9.7.2. Syntax and scoping of pattern synonyms"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#import-and-export-of-pattern-synonyms" ] $ "9.7.3. Import and export of pattern synonyms"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#typing-of-pattern-synonyms" ] $ "9.7.4. Typing of pattern synonyms"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#matching-of-pattern-synonyms" ] $ "9.7.5. Matching of pattern synonyms"
                                    li_ [ class_ "toctree-l2" ] $ do
                                        a_ [ class_ "reference internal", href_ "glasgow_exts.html#class-and-instances-declarations" ] $ "9.8. Class and instances declarations"
                                        ul_ $ do
                                            li_ [ class_ "toctree-l3" ] $ do
                                                a_ [ class_ "reference internal", href_ "glasgow_exts.html#class-declarations" ] $ "9.8.1. Class declarations"
                                                ul_ $ do
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#multi-parameter-type-classes" ] $ "9.8.1.1. Multi-parameter type classes"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#the-superclasses-of-a-class-declaration" ] $ "9.8.1.2. The superclasses of a class declaration"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#constrained-class-method-types" ] $ "9.8.1.3. Constrained class method types"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#default-method-signatures" ] $ "9.8.1.4. Default method signatures"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#nullary-type-classes" ] $ "9.8.1.5. Nullary type classes"
                                            li_ [ class_ "toctree-l3" ] $ do
                                                a_ [ class_ "reference internal", href_ "glasgow_exts.html#functional-dependencies" ] $ "9.8.2. Functional dependencies"
                                                ul_ $ do
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#rules-for-functional-dependencies" ] $ "9.8.2.1. Rules for functional dependencies"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#background-on-functional-dependencies" ] $ "9.8.2.2. Background on functional dependencies"
                                            li_ [ class_ "toctree-l3" ] $ do
                                                a_ [ class_ "reference internal", href_ "glasgow_exts.html#instance-declarations" ] $ "9.8.3. Instance declarations"
                                                ul_ $ do
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#instance-resolution" ] $ "9.8.3.1. Instance resolution"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#relaxed-rules-for-the-instance-head" ] $ "9.8.3.2. Relaxed rules for the instance head"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#relaxed-rules-for-instance-contexts" ] $ "9.8.3.3. Relaxed rules for instance contexts"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#instance-termination-rules" ] $ "9.8.3.4. Instance termination rules"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#undecidable-instances" ] $ "9.8.3.5. Undecidable instances"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#overlapping-instances" ] $ "9.8.3.6. Overlapping instances"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#instance-signatures-type-signatures-in-instance-declarations" ] $ "9.8.3.7. Instance signatures: type signatures in instance declarations"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#overloaded-string-literals" ] $ "9.8.4. Overloaded string literals"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#overloaded-labels" ] $ "9.8.5. Overloaded labels"
                                            li_ [ class_ "toctree-l3" ] $ do
                                                a_ [ class_ "reference internal", href_ "glasgow_exts.html#overloaded-lists" ] $ "9.8.6. Overloaded lists"
                                                ul_ $ do
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#the-islist-class" ] $ do
                                                        "9.8.6.1. The"
                                                        code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ "IsList"
                                                        "class"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#id32" ] $ "9.8.6.2. Rebindable syntax"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#defaulting" ] $ "9.8.6.3. Defaulting"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#speculation-about-the-future" ] $ "9.8.6.4. Speculation about the future"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#undecidable-or-recursive-superclasses" ] $ "9.8.7. Undecidable (or recursive) superclasses"
                                    li_ [ class_ "toctree-l2" ] $ do
                                        a_ [ class_ "reference internal", href_ "glasgow_exts.html#type-families" ] $ "9.9. Type families"
                                        ul_ $ do
                                            li_ [ class_ "toctree-l3" ] $ do
                                                a_ [ class_ "reference internal", href_ "glasgow_exts.html#data-families" ] $ "9.9.1. Data families"
                                                ul_ $ do
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#data-family-declarations" ] $ "9.9.1.1. Data family declarations"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#data-instance-declarations" ] $ "9.9.1.2. Data instance declarations"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#overlap-of-data-instances" ] $ "9.9.1.3. Overlap of data instances"
                                            li_ [ class_ "toctree-l3" ] $ do
                                                a_ [ class_ "reference internal", href_ "glasgow_exts.html#synonym-families" ] $ "9.9.2. Synonym families"
                                                ul_ $ do
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#type-family-declarations" ] $ "9.9.2.1. Type family declarations"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#type-instance-declarations" ] $ "9.9.2.2. Type instance declarations"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#closed-type-families" ] $ "9.9.2.3. Closed type families"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#type-family-examples" ] $ "9.9.2.4. Type family examples"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#compatibility-and-apartness-of-type-family-equations" ] $ "9.9.2.5. Compatibility and apartness of type family equations"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#decidability-of-type-synonym-instances" ] $ "9.9.2.6. Decidability of type synonym instances"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#wildcards-on-the-lhs-of-data-and-type-family-instances" ] $ "9.9.3. Wildcards on the LHS of data and type family instances"
                                            li_ [ class_ "toctree-l3" ] $ do
                                                a_ [ class_ "reference internal", href_ "glasgow_exts.html#associated-data-and-type-families" ] $ "9.9.4. Associated data and type families"
                                                ul_ $ do
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#associated-instances" ] $ "9.9.4.1. Associated instances"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#associated-type-synonym-defaults" ] $ "9.9.4.2. Associated type synonym defaults"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#scoping-of-class-parameters" ] $ "9.9.4.3. Scoping of class parameters"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#instance-contexts-and-associated-type-and-data-instances" ] $ "9.9.4.4. Instance contexts and associated type and data instances"
                                            li_ [ class_ "toctree-l3" ] $ do
                                                a_ [ class_ "reference internal", href_ "glasgow_exts.html#import-and-export" ] $ "9.9.5. Import and export"
                                                ul_ $ do
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#examples" ] $ "9.9.5.1. Examples"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#instances" ] $ "9.9.5.2. Instances"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#type-families-and-instance-declarations" ] $ "9.9.6. Type families and instance declarations"
                                            li_ [ class_ "toctree-l3" ] $ do
                                                a_ [ class_ "reference internal", href_ "glasgow_exts.html#injective-type-families" ] $ "9.9.7. Injective type families"
                                                ul_ $ do
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#syntax-of-injectivity-annotation" ] $ "9.9.7.1. Syntax of injectivity annotation"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#verifying-injectivity-annotation-against-type-family-equations" ] $ "9.9.7.2. Verifying injectivity annotation against type family equations"
                                    li_ [ class_ "toctree-l2" ] $ do
                                        a_ [ class_ "reference internal", href_ "glasgow_exts.html#datatype-promotion" ] $ "9.10. Datatype promotion"
                                        ul_ $ do
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#motivation" ] $ "9.10.1. Motivation"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#overview" ] $ "9.10.2. Overview"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#distinguishing-between-types-and-constructors" ] $ "9.10.3. Distinguishing between types and constructors"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#promoted-list-and-tuple-types" ] $ "9.10.4. Promoted list and tuple types"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#promoting-existential-data-constructors" ] $ "9.10.5. Promoting existential data constructors"
                                    li_ [ class_ "toctree-l2" ] $ do
                                        a_ [ class_ "reference internal", href_ "glasgow_exts.html#kind-polymorphism-and-type-in-type" ] $ "9.11. Kind polymorphism and Type-in-Type"
                                        ul_ $ do
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#the-difference-between-xtypeintype-and-xpolykinds" ] $ do
                                                "9.11.1. The difference between"
                                                code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ "-XTypeInType"
                                                "and"
                                                code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ "-XPolyKinds"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#overview-of-kind-polymorphism" ] $ "9.11.2. Overview of kind polymorphism"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#overview-of-type-in-type" ] $ "9.11.3. Overview of Type-in-Type"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#principles-of-kind-inference" ] $ "9.11.4. Principles of kind inference"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#complete-user-supplied-kind-signatures-and-polymorphic-recursion" ] $ "9.11.5. Complete user-supplied kind signatures and polymorphic recursion"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#kind-inference-in-closed-type-families" ] $ "9.11.6. Kind inference in closed type families"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#kind-inference-in-class-instance-declarations" ] $ "9.11.7. Kind inference in class instance declarations"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#kind-inference-in-type-signatures" ] $ "9.11.8. Kind inference in type signatures"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#explicit-kind-quantification" ] $ "9.11.9. Explicit kind quantification"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#kind-indexed-gadts" ] $ "9.11.10. Kind-indexed GADTs"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#constraints-in-kinds" ] $ "9.11.11. Constraints in kinds"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#the-kind" ] $ do
                                                "9.11.12. The kind"
                                                code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ "*"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#inferring-dependency-in-datatype-declarations" ] $ "9.11.13. Inferring dependency in datatype declarations"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#kind-defaulting-without-xpolykinds" ] $ do
                                                "9.11.14. Kind defaulting without"
                                                code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ "-XPolyKinds"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#pretty-printing-in-the-presence-of-kind-polymorphism" ] $ "9.11.15. Pretty-printing in the presence of kind polymorphism"
                                    li_ [ class_ "toctree-l2" ] $ do
                                        a_ [ class_ "reference internal", href_ "glasgow_exts.html#levity-polymorphism" ] $ "9.12. Levity polymorphism"
                                        ul_ $ do
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#no-levity-polymorphic-variables-or-arguments" ] $ "9.12.1. No levity-polymorphic variables or arguments"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#levity-polymorphic-bottoms" ] $ "9.12.2. Levity-polymorphic bottoms"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#printing-levity-polymorphic-types" ] $ "9.12.3. Printing levity-polymorphic types"
                                    li_ [ class_ "toctree-l2" ] $ do
                                        a_ [ class_ "reference internal", href_ "glasgow_exts.html#type-level-literals" ] $ "9.13. Type-Level Literals"
                                        ul_ $ do
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#runtime-values-for-type-level-literals" ] $ "9.13.1. Runtime Values for Type-Level Literals"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#computing-with-type-level-naturals" ] $ "9.13.2. Computing With Type-Level Naturals"
                                    li_ [ class_ "toctree-l2" ] $ do
                                        a_ [ class_ "reference internal", href_ "glasgow_exts.html#constraints-in-types" ] $ "9.14. Constraints in types"
                                        ul_ $ do
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#equality-constraints" ] $ "9.14.1. Equality constraints"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#heterogeneous-equality" ] $ "9.14.2. Heterogeneous equality"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#unlifted-heterogeneous-equality" ] $ "9.14.3. Unlifted heterogeneous equality"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#the-coercible-constraint" ] $ do
                                                "9.14.4. The"
                                                code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ "Coercible"
                                                "constraint"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#the-constraint-kind" ] $ do
                                                "9.14.5. The"
                                                code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ "Constraint"
                                                "kind"
                                    li_ [ class_ "toctree-l2" ] $ do
                                        a_ [ class_ "reference internal", href_ "glasgow_exts.html#extensions-to-type-signatures" ] $ "9.15. Extensions to type signatures"
                                        ul_ $ do
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#explicit-universal-quantification-forall" ] $ "9.15.1. Explicit universal quantification (forall)"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#the-context-of-a-type-signature" ] $ "9.15.2. The context of a type signature"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#ambiguous-types-and-the-ambiguity-check" ] $ "9.15.3. Ambiguous types and the ambiguity check"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#explicitly-kinded-quantification" ] $ "9.15.4. Explicitly-kinded quantification"
                                    li_ [ class_ "toctree-l2" ] $ do
                                        a_ [ class_ "reference internal", href_ "glasgow_exts.html#lexically-scoped-type-variables" ] $ "9.16. Lexically scoped type variables"
                                        ul_ $ do
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#id48" ] $ "9.16.1. Overview"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#declaration-type-signatures" ] $ "9.16.2. Declaration type signatures"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#expression-type-signatures" ] $ "9.16.3. Expression type signatures"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#pattern-type-signatures" ] $ "9.16.4. Pattern type signatures"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#class-and-instance-declarations" ] $ "9.16.5. Class and instance declarations"
                                    li_ [ class_ "toctree-l2" ] $ do
                                        a_ [ class_ "reference internal", href_ "glasgow_exts.html#bindings-and-generalisation" ] $ "9.17. Bindings and generalisation"
                                        ul_ $ do
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#switching-off-the-dreaded-monomorphism-restriction" ] $ "9.17.1. Switching off the dreaded Monomorphism Restriction"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#let-generalisation" ] $ "9.17.2. Let-generalisation"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#kind-generalisation" ] $ "9.17.3. Kind generalisation"
                                    li_ [ class_ "toctree-l2" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#visible-type-application" ] $ "9.18. Visible type application"
                                    li_ [ class_ "toctree-l2" ] $ do
                                        a_ [ class_ "reference internal", href_ "glasgow_exts.html#implicit-parameters" ] $ "9.19. Implicit parameters"
                                        ul_ $ do
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#implicit-parameter-type-constraints" ] $ "9.19.1. Implicit-parameter type constraints"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#implicit-parameter-bindings" ] $ "9.19.2. Implicit-parameter bindings"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#implicit-parameters-and-polymorphic-recursion" ] $ "9.19.3. Implicit parameters and polymorphic recursion"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#implicit-parameters-and-monomorphism" ] $ "9.19.4. Implicit parameters and monomorphism"
                                    li_ [ class_ "toctree-l2" ] $ do
                                        a_ [ class_ "reference internal", href_ "glasgow_exts.html#arbitrary-rank-polymorphism" ] $ "9.20. Arbitrary-rank polymorphism"
                                        ul_ $ do
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#univ" ] $ "9.20.1. Examples"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#type-inference" ] $ "9.20.2. Type inference"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#implicit-quantification" ] $ "9.20.3. Implicit quantification"
                                    li_ [ class_ "toctree-l2" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#impredicative-polymorphism" ] $ "9.21. Impredicative polymorphism"
                                    li_ [ class_ "toctree-l2" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#typed-holes" ] $ "9.22. Typed Holes"
                                    li_ [ class_ "toctree-l2" ] $ do
                                        a_ [ class_ "reference internal", href_ "glasgow_exts.html#partial-type-signatures" ] $ "9.23. Partial Type Signatures"
                                        ul_ $ do
                                            li_ [ class_ "toctree-l3" ] $ do
                                                a_ [ class_ "reference internal", href_ "glasgow_exts.html#syntax" ] $ "9.23.1. Syntax"
                                                ul_ $ do
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#type-wildcards" ] $ "9.23.1.1. Type Wildcards"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#named-wildcards" ] $ "9.23.1.2. Named Wildcards"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#extra-constraints-wildcard" ] $ "9.23.1.3. Extra-Constraints Wildcard"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#where-can-they-occur" ] $ "9.23.2. Where can they occur?"
                                    li_ [ class_ "toctree-l2" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#custom-compile-time-errors" ] $ "9.24. Custom compile-time errors"
                                    li_ [ class_ "toctree-l2" ] $ do
                                        a_ [ class_ "reference internal", href_ "glasgow_exts.html#deferring-type-errors-to-runtime" ] $ "9.25. Deferring type errors to runtime"
                                        ul_ $ do
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#enabling-deferring-of-type-errors" ] $ "9.25.1. Enabling deferring of type errors"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#deferred-type-errors-in-ghci" ] $ "9.25.2. Deferred type errors in GHCi"
                                    li_ [ class_ "toctree-l2" ] $ do
                                        a_ [ class_ "reference internal", href_ "glasgow_exts.html#template-haskell" ] $ "9.26. Template Haskell"
                                        ul_ $ do
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#th-syntax" ] $ "9.26.1. Syntax"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#using-template-haskell" ] $ "9.26.2. Using Template Haskell"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#viewing-template-haskell-generated-code" ] $ "9.26.3. Viewing Template Haskell generated code"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#a-template-haskell-worked-example" ] $ "9.26.4. A Template Haskell Worked Example"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#using-template-haskell-with-profiling" ] $ "9.26.5. Using Template Haskell with Profiling"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#template-haskell-quasi-quotation" ] $ "9.26.6. Template Haskell Quasi-quotation"
                                    li_ [ class_ "toctree-l2" ] $ do
                                        a_ [ class_ "reference internal", href_ "glasgow_exts.html#arrow-notation" ] $ "9.27. Arrow notation"
                                        ul_ $ do
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#do-notation-for-commands" ] $ "9.27.1. do-notation for commands"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#conditional-commands" ] $ "9.27.2. Conditional commands"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#defining-your-own-control-structures" ] $ "9.27.3. Defining your own control structures"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#primitive-constructs" ] $ "9.27.4. Primitive constructs"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#differences-with-the-paper" ] $ "9.27.5. Differences with the paper"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#portability" ] $ "9.27.6. Portability"
                                    li_ [ class_ "toctree-l2" ] $ do
                                        a_ [ class_ "reference internal", href_ "glasgow_exts.html#bang-patterns-and-strict-haskell" ] $ "9.28. Bang patterns and Strict Haskell"
                                        ul_ $ do
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#bang-patterns-informal" ] $ "9.28.1. Bang patterns"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#strict-by-default-data-types" ] $ "9.28.2. Strict-by-default data types"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#strict-by-default-pattern-bindings" ] $ "9.28.3. Strict-by-default pattern bindings"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#modularity" ] $ "9.28.4. Modularity"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#dynamic-semantics-of-bang-patterns" ] $ "9.28.5. Dynamic semantics of bang patterns"
                                    li_ [ class_ "toctree-l2" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#assertions" ] $ "9.29. Assertions"
                                    li_ [ class_ "toctree-l2" ] $ do
                                        a_ [ class_ "reference internal", href_ "glasgow_exts.html#static-pointers" ] $ "9.30. Static pointers"
                                        ul_ $ do
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#using-static-pointers" ] $ "9.30.1. Using static pointers"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#static-semantics-of-static-pointers" ] $ "9.30.2. Static semantics of static pointers"
                                    li_ [ class_ "toctree-l2" ] $ do
                                        a_ [ class_ "reference internal", href_ "glasgow_exts.html#pragmas" ] $ "9.31. Pragmas"
                                        ul_ $ do
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#language-pragma" ] $ "9.31.1. LANGUAGE pragma"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#options-ghc-pragma" ] $ do
                                                "9.31.2."
                                                code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ "OPTIONS_GHC"
                                                "pragma"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#include-pragma" ] $ do
                                                "9.31.3."
                                                code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ "INCLUDE"
                                                "pragma"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#warning-and-deprecated-pragmas" ] $ do
                                                "9.31.4."
                                                code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ "WARNING"
                                                "and"
                                                code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ "DEPRECATED"
                                                "pragmas"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#minimal-pragma" ] $ "9.31.5. MINIMAL pragma"
                                            li_ [ class_ "toctree-l3" ] $ do
                                                a_ [ class_ "reference internal", href_ "glasgow_exts.html#inline-and-noinline-pragmas" ] $ "9.31.6. INLINE and NOINLINE pragmas"
                                                ul_ $ do
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#inline-pragma" ] $ "9.31.6.1. INLINE pragma"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#inlinable-pragma" ] $ "9.31.6.2. INLINABLE pragma"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#noinline-pragma" ] $ "9.31.6.3. NOINLINE pragma"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#conlike-modifier" ] $ "9.31.6.4. CONLIKE modifier"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#phase-control" ] $ "9.31.6.5. Phase control"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#line-pragma" ] $ do
                                                "9.31.7."
                                                code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ "LINE"
                                                "pragma"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#column-pragma" ] $ do
                                                "9.31.8."
                                                code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ "COLUMN"
                                                "pragma"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#rules-pragma" ] $ do
                                                "9.31.9."
                                                code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ "RULES"
                                                "pragma"
                                            li_ [ class_ "toctree-l3" ] $ do
                                                a_ [ class_ "reference internal", href_ "glasgow_exts.html#specialize-pragma" ] $ do
                                                    "9.31.10."
                                                    code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ "SPECIALIZE"
                                                    "pragma"
                                                ul_ $ do
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#specialize-inline" ] $ do
                                                        "9.31.10.1."
                                                        code_ [ class_ "docutils literal" ] $ do
                                                            span_ [ class_ "pre" ] $ "SPECIALIZE"
                                                            span_ [ class_ "pre" ] $ "INLINE"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#specialize-for-imported-functions" ] $ do
                                                        "9.31.10.2."
                                                        code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ "SPECIALIZE"
                                                        "for imported functions"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#obsolete-specialize-syntax" ] $ do
                                                        "9.31.10.3. Obsolete"
                                                        code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ "SPECIALIZE"
                                                        "syntax"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#specialize-instance-pragma" ] $ do
                                                "9.31.11."
                                                code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ "SPECIALIZE"
                                                "instance pragma"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#unpack-pragma" ] $ do
                                                "9.31.12."
                                                code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ "UNPACK"
                                                "pragma"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#nounpack-pragma" ] $ do
                                                "9.31.13."
                                                code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ "NOUNPACK"
                                                "pragma"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#source-pragma" ] $ do
                                                "9.31.14."
                                                code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ "SOURCE"
                                                "pragma"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#complete-pragmas" ] $ do
                                                "9.31.15."
                                                code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ "COMPLETE"
                                                "pragmas"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#overlapping-overlappable-overlaps-and-incoherent-pragmas" ] $ do
                                                "9.31.16."
                                                code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ "OVERLAPPING"
                                                ","
                                                code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ "OVERLAPPABLE"
                                                ","
                                                code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ "OVERLAPS"
                                                ", and"
                                                code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ "INCOHERENT"
                                                "pragmas"
                                    li_ [ class_ "toctree-l2" ] $ do
                                        a_ [ class_ "reference internal", href_ "glasgow_exts.html#rewrite-rules" ] $ "9.32. Rewrite rules"
                                        ul_ $ do
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#id86" ] $ "9.32.1. Syntax"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#semantics" ] $ "9.32.2. Semantics"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#how-rules-interact-with-inline-noinline-pragmas" ] $ do
                                                "9.32.3. How rules interact with"
                                                code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ "INLINE"
                                                "/"
                                                code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ "NOINLINE"
                                                "pragmas"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#how-rules-interact-with-conlike-pragmas" ] $ "9.32.4. How rules interact with CONLIKE pragmas"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#how-rules-interact-with-class-methods" ] $ "9.32.5. How rules interact with class methods"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#list-fusion" ] $ "9.32.6. List fusion"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#specialisation" ] $ "9.32.7. Specialisation"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#controlling-what-s-going-on-in-rewrite-rules" ] $ "9.32.8. Controlling what’s going on in rewrite rules"
                                    li_ [ class_ "toctree-l2" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#special-built-in-functions" ] $ "9.33. Special built-in functions"
                                    li_ [ class_ "toctree-l2" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#generic-classes" ] $ "9.34. Generic classes"
                                    li_ [ class_ "toctree-l2" ] $ do
                                        a_ [ class_ "reference internal", href_ "glasgow_exts.html#generic-programming" ] $ "9.35. Generic programming"
                                        ul_ $ do
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#deriving-representations" ] $ "9.35.1. Deriving representations"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#writing-generic-functions" ] $ "9.35.2. Writing generic functions"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#unlifted-representation-types" ] $ "9.35.3. Unlifted representation types"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#generic-defaults" ] $ "9.35.4. Generic defaults"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#more-information" ] $ "9.35.5. More information"
                                    li_ [ class_ "toctree-l2" ] $ do
                                        a_ [ class_ "reference internal", href_ "glasgow_exts.html#roles" ] $ "9.36. Roles"
                                        ul_ $ do
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#nominal-representational-and-phantom" ] $ "9.36.1. Nominal, Representational, and Phantom"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#role-inference" ] $ "9.36.2. Role inference"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#role-annotations" ] $ "9.36.3. Role annotations"
                                    li_ [ class_ "toctree-l2" ] $ do
                                        a_ [ class_ "reference internal", href_ "glasgow_exts.html#hascallstack" ] $ "9.37. HasCallStack"
                                        ul_ $ li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "glasgow_exts.html#compared-with-other-sources-of-stack-traces" ] $ "9.37.1. Compared with other sources of stack traces"
                                    li_ [ class_ "toctree-l2" ] $ do
                                        a_ [ class_ "reference internal", href_ "parallel.html" ] $ "9.38. Concurrent and Parallel Haskell"
                                        ul_ $ do
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "parallel.html#concurrent-haskell" ] $ "9.38.1. Concurrent Haskell"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "parallel.html#software-transactional-memory" ] $ "9.38.2. Software Transactional Memory"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "parallel.html#parallel-haskell" ] $ "9.38.3. Parallel Haskell"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "parallel.html#annotating-pure-code-for-parallelism" ] $ "9.38.4. Annotating pure code for parallelism"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "parallel.html#data-parallel-haskell" ] $ "9.38.5. Data Parallel Haskell"
                                    li_ [ class_ "toctree-l2" ] $ do
                                        a_ [ class_ "reference internal", href_ "safe_haskell.html" ] $ "9.39. Safe Haskell"
                                        ul_ $ do
                                            li_ [ class_ "toctree-l3" ] $ do
                                                a_ [ class_ "reference internal", href_ "safe_haskell.html#uses-of-safe-haskell" ] $ "9.39.1. Uses of Safe Haskell"
                                                ul_ $ do
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "safe_haskell.html#strict-type-safety-good-style" ] $ "9.39.1.1. Strict type-safety (good style)"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "safe_haskell.html#building-secure-systems-restricted-io-monads" ] $ "9.39.1.2. Building secure systems (restricted IO Monads)"
                                            li_ [ class_ "toctree-l3" ] $ do
                                                a_ [ class_ "reference internal", href_ "safe_haskell.html#safe-language" ] $ "9.39.2. Safe Language"
                                                ul_ $ li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "safe_haskell.html#safe-overlapping-instances" ] $ "9.39.2.1. Safe Overlapping Instances"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "safe_haskell.html#safe-imports" ] $ "9.39.3. Safe Imports"
                                            li_ [ class_ "toctree-l3" ] $ do
                                                a_ [ class_ "reference internal", href_ "safe_haskell.html#trust-and-safe-haskell-modes" ] $ "9.39.4. Trust and Safe Haskell Modes"
                                                ul_ $ do
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "safe_haskell.html#trust-check-fpackage-trust-disabled" ] $ do
                                                        "9.39.4.1. Trust check ("
                                                        code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ "-fpackage-trust"
                                                        "disabled)"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "safe_haskell.html#trust-check-fpackage-trust-enabled" ] $ do
                                                        "9.39.4.2. Trust check ("
                                                        code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ "-fpackage-trust"
                                                        "enabled)"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "safe_haskell.html#example" ] $ "9.39.4.3. Example"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "safe_haskell.html#trustworthy-requirements" ] $ "9.39.4.4. Trustworthy Requirements"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "safe_haskell.html#package-trust" ] $ "9.39.4.5. Package Trust"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "safe_haskell.html#safe-haskell-inference" ] $ "9.39.5. Safe Haskell Inference"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "safe_haskell.html#safe-haskell-flag-summary" ] $ "9.39.6. Safe Haskell Flag Summary"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "safe_haskell.html#safe-compilation" ] $ "9.39.7. Safe Compilation"
                            li_ [ class_ "toctree-l1" ] $ do
                                a_ [ class_ "reference internal", href_ "ffi-chap.html" ] $ "10. Foreign function interface (FFI)"
                                ul_ $ do
                                    li_ [ class_ "toctree-l2" ] $ do
                                        a_ [ class_ "reference internal", href_ "ffi-chap.html#ghc-extensions-to-the-ffi-addendum" ] $ "10.1. GHC extensions to the FFI Addendum"
                                        ul_ $ do
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "ffi-chap.html#unboxed-types" ] $ "10.1.1. Unboxed types"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "ffi-chap.html#newtype-wrapping-of-the-io-monad" ] $ "10.1.2. Newtype wrapping of the IO monad"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "ffi-chap.html#primitive-imports" ] $ "10.1.3. Primitive imports"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "ffi-chap.html#interruptible-foreign-calls" ] $ "10.1.4. Interruptible foreign calls"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "ffi-chap.html#the-capi-calling-convention" ] $ "10.1.5. The CAPI calling convention"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "ffi-chap.html#hs-thread-done" ] $ do
                                                "10.1.6."
                                                code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ "hs_thread_done()"
                                    li_ [ class_ "toctree-l2" ] $ do
                                        a_ [ class_ "reference internal", href_ "ffi-chap.html#using-the-ffi-with-ghc" ] $ "10.2. Using the FFI with GHC"
                                        ul_ $ do
                                            li_ [ class_ "toctree-l3" ] $ do
                                                a_ [ class_ "reference internal", href_ "ffi-chap.html#using-foreign-export-and-foreign-import-ccall-wrapper-with-ghc" ] $ do
                                                    "10.2.1. Using"
                                                    code_ [ class_ "docutils literal" ] $ do
                                                        span_ [ class_ "pre" ] $ "foreign"
                                                        span_ [ class_ "pre" ] $ "export"
                                                    "and"
                                                    code_ [ class_ "docutils literal" ] $ do
                                                        span_ [ class_ "pre" ] $ "foreign"
                                                        span_ [ class_ "pre" ] $ "import"
                                                        span_ [ class_ "pre" ] $ "ccall"
                                                        span_ [ class_ "pre" ] $ "\"wrapper\""
                                                    "with GHC"
                                                ul_ $ do
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "ffi-chap.html#using-your-own-main" ] $ do
                                                        "10.2.1.1. Using your own"
                                                        code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ "main()"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "ffi-chap.html#making-a-haskell-library-that-can-be-called-from-foreign-code" ] $ "10.2.1.2. Making a Haskell library that can be called from foreign code"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "ffi-chap.html#using-header-files" ] $ "10.2.2. Using header files"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "ffi-chap.html#memory-allocation" ] $ "10.2.3. Memory Allocation"
                                            li_ [ class_ "toctree-l3" ] $ do
                                                a_ [ class_ "reference internal", href_ "ffi-chap.html#multi-threading-and-the-ffi" ] $ "10.2.4. Multi-threading and the FFI"
                                                ul_ $ do
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "ffi-chap.html#foreign-imports-and-multi-threading" ] $ "10.2.4.1. Foreign imports and multi-threading"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "ffi-chap.html#the-relationship-between-haskell-threads-and-os-threads" ] $ "10.2.4.2. The relationship between Haskell threads and OS threads"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "ffi-chap.html#foreign-exports-and-multi-threading" ] $ "10.2.4.3. Foreign exports and multi-threading"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "ffi-chap.html#on-the-use-of-hs-exit" ] $ do
                                                        "10.2.4.4. On the use of"
                                                        code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ "hs_exit()"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "ffi-chap.html#waking-up-haskell-threads-from-c" ] $ "10.2.4.5. Waking up Haskell threads from C"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "ffi-chap.html#floating-point-and-the-ffi" ] $ "10.2.5. Floating point and the FFI"
                            li_ [ class_ "toctree-l1" ] $ do
                                a_ [ class_ "reference internal", href_ "extending_ghc.html" ] $ "11. Extending and using GHC as a Library"
                                ul_ $ do
                                    li_ [ class_ "toctree-l2" ] $ do
                                        a_ [ class_ "reference internal", href_ "extending_ghc.html#source-annotations" ] $ "11.1. Source annotations"
                                        ul_ $ do
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "extending_ghc.html#annotating-values" ] $ "11.1.1. Annotating values"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "extending_ghc.html#annotating-types" ] $ "11.1.2. Annotating types"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "extending_ghc.html#annotating-modules" ] $ "11.1.3. Annotating modules"
                                    li_ [ class_ "toctree-l2" ] $ a_ [ class_ "reference internal", href_ "extending_ghc.html#using-ghc-as-a-library" ] $ "11.2. Using GHC as a Library"
                                    li_ [ class_ "toctree-l2" ] $ do
                                        a_ [ class_ "reference internal", href_ "extending_ghc.html#compiler-plugins" ] $ "11.3. Compiler Plugins"
                                        ul_ $ do
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "extending_ghc.html#using-compiler-plugins" ] $ "11.3.1. Using compiler plugins"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "extending_ghc.html#writing-compiler-plugins" ] $ "11.3.2. Writing compiler plugins"
                                            li_ [ class_ "toctree-l3" ] $ do
                                                a_ [ class_ "reference internal", href_ "extending_ghc.html#core-plugins-in-more-detail" ] $ "11.3.3. Core plugins in more detail"
                                                ul_ $ do
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "extending_ghc.html#manipulating-bindings" ] $ "11.3.3.1. Manipulating bindings"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "extending_ghc.html#using-annotations" ] $ "11.3.3.2. Using Annotations"
                                            li_ [ class_ "toctree-l3" ] $ do
                                                a_ [ class_ "reference internal", href_ "extending_ghc.html#typechecker-plugins" ] $ "11.3.4. Typechecker plugins"
                                                ul_ $ li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "extending_ghc.html#constraint-solving-with-plugins" ] $ "11.3.4.1. Constraint solving with plugins"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "extending_ghc.html#frontend-plugins" ] $ "11.3.5. Frontend plugins"
                            li_ [ class_ "toctree-l1" ] $ do
                                a_ [ class_ "reference internal", href_ "gone_wrong.html" ] $ "12. What to do when something goes wrong"
                                ul_ $ do
                                    li_ [ class_ "toctree-l2" ] $ a_ [ class_ "reference internal", href_ "gone_wrong.html#when-the-compiler-does-the-wrong-thing" ] $ "12.1. When the compiler “does the wrong thing”"
                                    li_ [ class_ "toctree-l2" ] $ a_ [ class_ "reference internal", href_ "gone_wrong.html#when-your-program-does-the-wrong-thing" ] $ "12.2. When your program “does the wrong thing”"
                            li_ [ class_ "toctree-l1" ] $ do
                                a_ [ class_ "reference internal", href_ "debug-info.html" ] $ "13. Debugging compiled programs"
                                ul_ $ do
                                    li_ [ class_ "toctree-l2" ] $ a_ [ class_ "reference internal", href_ "debug-info.html#tutorial" ] $ "13.1. Tutorial"
                                    li_ [ class_ "toctree-l2" ] $ a_ [ class_ "reference internal", href_ "debug-info.html#requesting-a-stack-trace-from-haskell-code" ] $ "13.2. Requesting a stack trace from Haskell code"
                                    li_ [ class_ "toctree-l2" ] $ a_ [ class_ "reference internal", href_ "debug-info.html#requesting-a-stack-trace-with-sigusr2" ] $ do
                                        "13.3. Requesting a stack trace with"
                                        code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ "SIGUSR2"
                                    li_ [ class_ "toctree-l2" ] $ do
                                        a_ [ class_ "reference internal", href_ "debug-info.html#implementor-s-notes-dwarf-annotations" ] $ "13.4. Implementor’s notes: DWARF annotations"
                                        ul_ $ li_ [ class_ "toctree-l3" ] $ do
                                            a_ [ class_ "reference internal", href_ "debug-info.html#debugging-information-entities" ] $ "13.4.1. Debugging information entities"
                                            ul_ $ li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "debug-info.html#dw-tag-ghc-src-note" ] $ do
                                                "13.4.1.1."
                                                code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ "DW_TAG_ghc_src_note"
                                    li_ [ class_ "toctree-l2" ] $ a_ [ class_ "reference internal", href_ "debug-info.html#further-reading" ] $ "13.5. Further Reading"
                            li_ [ class_ "toctree-l1" ] $ do
                                a_ [ class_ "reference internal", href_ "utils.html" ] $ "14. Other Haskell utility programs"
                                ul_ $ do
                                    li_ [ class_ "toctree-l2" ] $ a_ [ class_ "reference internal", href_ "utils.html#yacc-for-haskell-happy" ] $ do
                                        "14.1. “Yacc for Haskell”:"
                                        code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ "happy"
                                    li_ [ class_ "toctree-l2" ] $ do
                                        a_ [ class_ "reference internal", href_ "utils.html#writing-haskell-interfaces-to-c-code-hsc2hs" ] $ do
                                            "14.2. Writing Haskell interfaces to C code:"
                                            code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ "hsc2hs"
                                        ul_ $ do
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "utils.html#command-line-syntax" ] $ "14.2.1. command line syntax"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "utils.html#input-syntax" ] $ "14.2.2. Input syntax"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "utils.html#custom-constructs" ] $ "14.2.3. Custom constructs"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "utils.html#cross-compilation" ] $ "14.2.4. Cross-compilation"
                            li_ [ class_ "toctree-l1" ] $ do
                                a_ [ class_ "reference internal", href_ "win32-dlls.html" ] $ "15. Running GHC on Win32 systems"
                                ul_ $ do
                                    li_ [ class_ "toctree-l2" ] $ a_ [ class_ "reference internal", href_ "win32-dlls.html#starting-ghc-on-windows-platforms" ] $ "15.1. Starting GHC on Windows platforms"
                                    li_ [ class_ "toctree-l2" ] $ a_ [ class_ "reference internal", href_ "win32-dlls.html#running-ghci-on-windows" ] $ "15.2. Running GHCi on Windows"
                                    li_ [ class_ "toctree-l2" ] $ a_ [ class_ "reference internal", href_ "win32-dlls.html#interacting-with-the-terminal" ] $ "15.3. Interacting with the terminal"
                                    li_ [ class_ "toctree-l2" ] $ a_ [ class_ "reference internal", href_ "win32-dlls.html#differences-in-library-behaviour" ] $ "15.4. Differences in library behaviour"
                                    li_ [ class_ "toctree-l2" ] $ do
                                        a_ [ class_ "reference internal", href_ "win32-dlls.html#using-ghc-and-other-ghc-compiled-executables-with-cygwin" ] $ "15.5. Using GHC (and other GHC-compiled executables) with Cygwin"
                                        ul_ $ do
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "win32-dlls.html#background" ] $ "15.5.1. Background"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "win32-dlls.html#the-problem" ] $ "15.5.2. The problem"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "win32-dlls.html#things-to-do" ] $ "15.5.3. Things to do"
                                    li_ [ class_ "toctree-l2" ] $ do
                                        a_ [ class_ "reference internal", href_ "win32-dlls.html#building-and-using-win32-dlls" ] $ "15.6. Building and using Win32 DLLs"
                                        ul_ $ do
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "win32-dlls.html#creating-a-dll" ] $ "15.6.1. Creating a DLL"
                                            li_ [ class_ "toctree-l3" ] $ do
                                                a_ [ class_ "reference internal", href_ "win32-dlls.html#making-dlls-to-be-called-from-other-languages" ] $ "15.6.2. Making DLLs to be called from other languages"
                                                ul_ $ do
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "win32-dlls.html#using-from-vba" ] $ "15.6.2.1. Using from VBA"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "win32-dlls.html#using-from-c" ] $ "15.6.2.2. Using from C++"
                            li_ [ class_ "toctree-l1" ] $ do
                                a_ [ class_ "reference internal", href_ "bugs.html" ] $ "16. Known bugs and infelicities"
                                ul_ $ do
                                    li_ [ class_ "toctree-l2" ] $ do
                                        a_ [ class_ "reference internal", href_ "bugs.html#haskell-standards-vs-glasgow-haskell-language-non-compliance" ] $ "16.1. Haskell standards vs. Glasgow Haskell: language non-compliance"
                                        ul_ $ do
                                            li_ [ class_ "toctree-l3" ] $ do
                                                a_ [ class_ "reference internal", href_ "bugs.html#divergence-from-haskell-98-and-haskell-2010" ] $ "16.1.1. Divergence from Haskell 98 and Haskell 2010"
                                                ul_ $ do
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "bugs.html#lexical-syntax" ] $ "16.1.1.1. Lexical syntax"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "bugs.html#context-free-syntax" ] $ "16.1.1.2. Context-free syntax"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "bugs.html#expressions-and-patterns" ] $ "16.1.1.3. Expressions and patterns"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "bugs.html#declarations-and-bindings" ] $ "16.1.1.4. Declarations and bindings"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "bugs.html#typechecking-of-recursive-binding-groups" ] $ "16.1.1.5. Typechecking of recursive binding groups"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "bugs.html#module-system-and-interface-files" ] $ "16.1.1.6. Module system and interface files"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "bugs.html#numbers-basic-types-and-built-in-classes" ] $ "16.1.1.7. Numbers, basic types, and built-in classes"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "bugs.html#in-prelude-support" ] $ do
                                                        "16.1.1.8. In"
                                                        code_ [ class_ "docutils literal" ] $ span_ [ class_ "pre" ] $ "Prelude"
                                                        "support"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "bugs.html#the-foreign-function-interface" ] $ "16.1.1.9. The Foreign Function Interface"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "bugs.html#ghc-s-interpretation-of-undefined-behaviour-in-haskell-98-and-haskell-2010" ] $ "16.1.2. GHC’s interpretation of undefined behaviour in Haskell 98 and Haskell 2010"
                                    li_ [ class_ "toctree-l2" ] $ do
                                        a_ [ class_ "reference internal", href_ "bugs.html#known-bugs-or-infelicities" ] $ "16.2. Known bugs or infelicities"
                                        ul_ $ do
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "bugs.html#bugs-in-ghc" ] $ "16.2.1. Bugs in GHC"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "bugs.html#bugs-in-ghci-the-interactive-ghc" ] $ "16.2.2. Bugs in GHCi (the interactive GHC)"
                            li_ [ class_ "toctree-l1" ] $ do
                                a_ [ class_ "reference internal", href_ "eventlog-formats.html" ] $ "17. Eventlog encodings"
                                ul_ $ li_ [ class_ "toctree-l2" ] $ do
                                    a_ [ class_ "reference internal", href_ "eventlog-formats.html#heap-profiler-event-log-output" ] $ "17.1. Heap profiler event log output"
                                    ul_ $ do
                                        li_ [ class_ "toctree-l3" ] $ do
                                            a_ [ class_ "reference internal", href_ "eventlog-formats.html#metadata-event-types" ] $ "17.1.1. Metadata event types"
                                            ul_ $ do
                                                li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "eventlog-formats.html#beginning-of-sample-stream" ] $ "17.1.1.1. Beginning of sample stream"
                                                li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "eventlog-formats.html#cost-centre-definitions" ] $ "17.1.1.2. Cost centre definitions"
                                        li_ [ class_ "toctree-l3" ] $ do
                                            a_ [ class_ "reference internal", href_ "eventlog-formats.html#sample-event-types" ] $ "17.1.2. Sample event types"
                                            ul_ $ do
                                                li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "eventlog-formats.html#cost-centre-break-down" ] $ "17.1.2.1. Cost-centre break-down"
                                                li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "eventlog-formats.html#string-break-down" ] $ "17.1.2.2. String break-down"
                            li_ [ class_ "toctree-l1" ] $ do
                                a_ [ class_ "reference internal", href_ "editing-guide.html" ] $ "18. Care and feeding of your GHC User’s Guide"
                                ul_ $ do
                                    li_ [ class_ "toctree-l2" ] $ do
                                        a_ [ class_ "reference internal", href_ "editing-guide.html#basics" ] $ "18.1. Basics"
                                        ul_ $ do
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "editing-guide.html#headings" ] $ "18.1.1. Headings"
                                            li_ [ class_ "toctree-l3" ] $ do
                                                a_ [ class_ "reference internal", href_ "editing-guide.html#formatting-code" ] $ "18.1.2. Formatting code"
                                                ul_ $ do
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "editing-guide.html#haskell" ] $ "18.1.2.1. Haskell"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "editing-guide.html#other-languages" ] $ "18.1.2.2. Other languages"
                                            li_ [ class_ "toctree-l3" ] $ do
                                                a_ [ class_ "reference internal", href_ "editing-guide.html#links" ] $ "18.1.3. Links"
                                                ul_ $ do
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "editing-guide.html#within-the-user-s-guide" ] $ "18.1.3.1. Within the User’s Guide"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "editing-guide.html#to-ghc-trac-resources" ] $ "18.1.3.2. To GHC Trac resources"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "editing-guide.html#to-external-resources" ] $ "18.1.3.3. To external resources"
                                                    li_ [ class_ "toctree-l4" ] $ a_ [ class_ "reference internal", href_ "editing-guide.html#to-core-library-haddock-documentation" ] $ "18.1.3.4. To core library Haddock documentation"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "editing-guide.html#index-entries" ] $ "18.1.4. Index entries"
                                    li_ [ class_ "toctree-l2" ] $ a_ [ class_ "reference internal", href_ "editing-guide.html#citations" ] $ "18.2. Citations"
                                    li_ [ class_ "toctree-l2" ] $ a_ [ class_ "reference internal", href_ "editing-guide.html#admonitions" ] $ "18.3. Admonitions"
                                    li_ [ class_ "toctree-l2" ] $ do
                                        a_ [ class_ "reference internal", href_ "editing-guide.html#documenting-command-line-options-and-ghci-commands" ] $ "18.4. Documenting command-line options and GHCi commands"
                                        ul_ $ do
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "editing-guide.html#command-line-options" ] $ "18.4.1. Command-line options"
                                            li_ [ class_ "toctree-l3" ] $ a_ [ class_ "reference internal", href_ "editing-guide.html#ghci-commands" ] $ "18.4.2. GHCi commands"
                                    li_ [ class_ "toctree-l2" ] $ a_ [ class_ "reference internal", href_ "editing-guide.html#style-conventions" ] $ "18.5. Style Conventions"
                                    li_ [ class_ "toctree-l2" ] $ a_ [ class_ "reference internal", href_ "editing-guide.html#ghc-command-line-options-reference" ] $ "18.6. GHC command-line options reference"
                                    li_ [ class_ "toctree-l2" ] $ a_ [ class_ "reference internal", href_ "editing-guide.html#rest-reference-materials" ] $ "18.7. ReST reference materials"
                    div_ [ class_ "section", id_ "indices-and-tables" ] $ do
                        h1_ $ do
                            "Indices and tables"
                            a_ [ class_ "headerlink", href_ "#indices-and-tables", title_ "Permalink to this headline" ] $ "¶"
                        ul_ [ class_ "simple" ] $ do
                            li_ $ a_ [ class_ "reference internal", href_ "genindex.html" ] $ em_ "Index"
                            li_ $ a_ [ class_ "reference internal", href_ "search.html" ] $ em_ "Search Page"
                div_ [ class_ "clearer" ] $ ""
            div_ [ class_ "related" ] $ do
                h3_ "Navigation"
                ul_ $ do
                    li_ [ class_ "right", style_ "margin-right: 10px" ] $ a_ [ href_ "genindex.html", title_ "General Index" ] $ "index"
                    li_ [ class_ "right" ] $ do
                        a_ [ href_ "license.html", title_ "1. The Glasgow Haskell Compiler License" ] $ "next"
                        "|"
                    li_ $ do
                        a_ [ href_ "#" ] $ "GHC 8.2.1 User's Guide"
                        "»"
            div_ [ class_ "footer" ] $ do
                "© Copyright 2015, GHC Team.\n      Created using"
                a_ [ href_ "http://sphinx-doc.org/" ] $ "Sphinx"
                "1.2.3."

