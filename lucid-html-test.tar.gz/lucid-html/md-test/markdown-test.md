# Testing Github Markdown

Let us test some code blocks.

Html
```html
<a>&#xe802;</a>
```

Haskell
```haskell
template :: Html ()
template = do
    input_ [ type_ "checkbox", name_ "vehicle", value_ "Car", checked_ ]
    " Just checked box"
 ```
