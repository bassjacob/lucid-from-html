{-# LANGUAGE OverloadedStrings, ExtendedDefaultRules #-}

import Lucid
import Lucid.Base
import Data.Text
import System.IO (stdout)
import Data.Text.Lazy.IO as L

main :: IO ()
main = L.hPutStr stdout (renderText template1)

ariaHidden_ :: Text -> Attribute
ariaHidden_ = makeAttribute "aria-hidden"

property_ :: Text -> Attribute
property_ = makeAttribute "property"

-- tag is deprecated
language_ :: Text -> Attribute
language_ = makeAttribute "language"

-- tag is obsolete!
align_ :: Text -> Attribute
align_ = makeAttribute "align"

-- Template for file: test-entity.html
template1 :: Html ()
template1 = do
    a_ "\59394"

