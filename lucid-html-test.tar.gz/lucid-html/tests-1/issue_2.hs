{-# LANGUAGE OverloadedStrings, ExtendedDefaultRules #-}

import Lucid
import Lucid.Base
import Data.Text
import System.IO (stdout)
import Data.Text.Lazy.IO as L

main :: IO ()
main = L.hPutStr stdout (renderText template1)

ariaHidden_ :: Text -> Attribute
ariaHidden_ = makeAttribute "aria-hidden"

property_ :: Text -> Attribute
property_ = makeAttribute "property"

-- Template for file: issue_2-div.html
template1 :: Html ()
template1 = do
    div_ [ class_ "select-holder" ] $ do
        toHtmlRaw  "<!-- google translate language select -->"
        toHtmlRaw  "<!-- currency select -->"

