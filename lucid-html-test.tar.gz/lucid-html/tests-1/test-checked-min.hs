-- Template for file: test-checked-min.html
template1 :: Html ()
template1 = do
    input_ [ type_ "checkbox", name_ "vehicle", value_ "Car", checked_ "" ]
    " I have a car"
    br_ []

