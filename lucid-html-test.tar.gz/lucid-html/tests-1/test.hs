{-# LANGUAGE OverloadedStrings, ExtendedDefaultRules #-}

import Lucid
import Lucid.Base
import System.IO (stdout)
import           Data.Text as T
import           Data.Text.Lazy.IO as L
import           Data.Text.Lazy         as LT
import           Data.Text.Lazy.Builder as B
import           Data.Functor.Identity
import           Data.Monoid

ariaHidden_ :: T.Text -> Attribute
ariaHidden_ = makeAttribute "aria-hidden"

property_ :: T.Text -> Attribute
property_ = makeAttribute "property"

prettyText :: Html a -> LT.Text
prettyText svg = B.toLazyText $ LT.foldr go mempty text Nothing (-1)
  where
    text = renderText svg
    go c f Nothing n
      | c == '<' || c == '/' = f (Just c) n
    go c f (Just '<') n
      | c == '?' = "<?" <> f Nothing n
      | c == '!' = "<!" <> f Nothing n
      | c == '/' = "\n"
                    <> (B.fromLazyText $ LT.replicate n "  " )
                    <> "</"
                    <> f Nothing (n-1)
      | otherwise = "\n"
                    <> (B.fromLazyText $ LT.replicate (n+1)   "  " )
                    <> "<"
                    <> B.singleton c
                    <> f Nothing (n+1)
    go '>' f (Just _) n = "/>" <> f Nothing (n-1)
    go c f s n =  s' <> B.singleton c <> f Nothing n
      where  s' = maybe mempty B.singleton s


main :: IO ()
main = L.hPutStr stdout (prettyText template1)

-- Template for file: /home/tim/ghc/share/doc/ghc-8.2.1/html/index.html
template1 :: Html ()
template1 = do
    doctype_
    html_ $ do
        head_ $ title_ "Test `p` taq"
        body_ $ do
            h1_ "`p` tag"
            p_ "Welcome to GHC!"
            p_ $ do
              toHtml "We are an organisation working in the field of Eco-tourism, from past eighteen years and stand tall, as a recognized name in the domain of"
              strong_ "'Wildlife,"
              strong_ "Adventure"
              strong_ "and Trekking Holidays'"
              "and have rendered lasting experiences to travel and wildlife enthusiasts, corporates and adventure dwellers of all ages."
              br_ []
              "Besides conducting"
              strong_ "wildlife camps, adventure camps, trekking and offbeat tours in India"
              ", we have been conducting trips to international destinations, right from"
              strong_ "Arctic to Antarctica"
              "; encompassing African Safaris to"
              strong_ "Kenya, Tanzania, Botswana, Zimbabwe, Namibia and South Africa; Birding Tours to Bhutan, and Treks to Everest Base Camp and Annapurna Base Camp in Nepal."
              br_ []
              "Now that you know what we do, it’s time for you to dive into the bag of memories we have scripted for you, and"

