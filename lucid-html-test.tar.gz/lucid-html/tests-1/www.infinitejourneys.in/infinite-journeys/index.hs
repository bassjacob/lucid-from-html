{-# LANGUAGE OverloadedStrings, ExtendedDefaultRules #-}

import Lucid
import Lucid.Base
import Data.Text
import System.IO (stdout)
import Data.Text.Lazy.IO as L

main :: IO ()
main = L.hPutStr stdout (renderText template1)

ariaHidden_ :: Text -> Attribute
ariaHidden_ = makeAttribute "aria-hidden"

property_ :: Text -> Attribute
property_ = makeAttribute "property"

language_ :: Text -> Attribute
language_ = makeAttribute "language"

align_ :: Text -> Attribute
align_ = makeAttribute "align"

-- Template for file: index.html
template1 :: Html ()
template1 = do
    doctype_
    toHtmlRaw  "<!--[if lt IE 7 ]><html class=\"ie ie6\" lang=\"en\"> <![endif]-->"
    toHtmlRaw  "<!--[if IE 7 ]><html class=\"ie ie7\" lang=\"en\"> <![endif]-->"
    toHtmlRaw  "<!--[if IE 8 ]><html class=\"ie ie8\" lang=\"en\"> <![endif]-->"
    toHtmlRaw  "<!--[if (gte IE 9)|!(IE)]><!-->"
    html_ [ lang_ "en", xmlns_ "http://www.w3.org/1999/xhtml" ] $ do
        toHtmlRaw  "<!--<![endif]-->"
        head_ $ do
            toHtmlRaw  "<!-- Basic Page Needs================================================== -->"
            meta_ [ httpEquiv_ "Content-Type", content_ "text/html; charset=utf-8" ]
            toHtmlRaw  "<!-- OLD -->"
            title_ "Infinite Journeys | Hotels | Flights | Packages | Cruises"
            meta_ [ name_ "keywords", content_ "Infinite Journeys Customised packages, best Hotel rates, Family trips, Wildlife safaris, Himalayan Treks, Kenya Safaris, Ladakh, offbeat tour, leisure holidays, exotic destinations, Cheap Air ticket booking, Visa, Honeymoon holiday planning, " ]
            meta_ [ name_ "description", content_ "Infinite Journeys: Call us on +912066447777 to plan your trip. Offbeat Packages Singapore, Thailand, Europe, Africa, Kerala, Manali, Rajasthan, Kashmir, Sikkim, Ladakh and many others" ]
            toHtmlRaw  "<!-- NEW -->"
            meta_ [ name_ "robots", content_ "index, follow" ]
            link_ [ rel_ "canonical", href_ "http://www.infinitejourneys.in/infinite-journeys/" ]
            meta_ [ property_ "og:title", content_ "Infinite Journeys | Hotels | Flights | Packages | Cruises" ]
            meta_ [ property_ "og:description", content_ "Infinite Journeys: Call us on +912066447777 to plan your trip. Offbeat Packages Singapore, Thailand, Europe, Africa, Kerala, Manali, Rajasthan, Kashmir, Sikkim, Ladakh and many others" ]
            meta_ [ property_ "og:type", content_ "website" ]
            meta_ [ property_ "og:url", content_ "http://www.infinitejourneys.in/infinite-journeys/" ]
            meta_ [ property_ "og:site_name", content_ "Infinite Journeys" ]
            meta_ [ property_ "og:image", content_ "http://www.infinitejourneys.in/templates/default/images/layout/logoInfinite.png" ]
            meta_ [ name_ "author", content_ "" ]
            toHtmlRaw  "<!-- Mobile Specific Metas================================================== -->"
            meta_ [ name_ "viewport", content_ "width=device-width, initial-scale=1, maximum-scale=1" ]
            toHtmlRaw  "<!-- FONTS================================================== -->"
            link_ [ href_ "http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,400,300,600,700,800", rel_ "stylesheet", type_ "text/css" ]
            toHtmlRaw  "<!-- CSS ================================================== -->"
            link_ [ rel_ "stylesheet", href_ "http://www.infinitejourneys.in/templates/default/css/base.css" ]
            toHtmlRaw  "<!--<link rel=\"stylesheet\" href=\"http://www.infinitejourneys.in/templates/default/css/skeleton.css\"/> -->"
            toHtmlRaw  "<!--<link rel=\"stylesheet\" href=\"http://www.infinitejourneys.in/templates/default/css/fancyfields.css\"/>\n<link type=\"text/css\" rel=\"stylesheet\" href=\"http://www.infinitejourneys.in/templates/default/css/jquery.mmenu.css\" />\n<link rel=\"stylesheet\" href=\"http://www.infinitejourneys.in/templates/default/css/jquery.bxslider.css\"/> -->"
            link_ [ rel_ "stylesheet", href_ "http://www.infinitejourneys.in/templates/default/css/prettyPhoto.css", type_ "text/css", media_ "screen", charset_ "utf-8" ]
            toHtmlRaw  "<!-- <link rel=\"stylesheet\" href=\"http://www.infinitejourneys.in/templates/default/css/globalSite.css\"/> \n<link rel=\"stylesheet\" href=\"http://www.infinitejourneys.in/templates/default/css/layoutSite.css\"/> -->"
            link_ [ rel_ "stylesheet", href_ "http://www.infinitejourneys.in/templates/default/css/infiniteGlobal.css" ]
            toHtmlRaw  "<!--for calender-->"
            link_ [ rel_ "stylesheet", media_ "all", type_ "text/css", href_ "http://code.jquery.com/ui/1.10.3/themes/smoothness/jquery-ui.css" ]
            link_ [ rel_ "stylesheet", media_ "all", type_ "text/css", href_ "http://www.infinitejourneys.in/js/admin/foliage-admin/calender/jquery-ui-timepicker-addon.css" ]
            toHtmlRaw  "<!--[if lt IE 9]><script src=\"http://html5shim.googlecode.com/svn/trunk/html5.js\"></script><![endif]-->"
            script_ [ type_ "text/javascript", src_ "http://code.jquery.com/jquery-1.10.2.min.js" ] $ ""
            script_ [ type_ "text/javascript", src_ "http://www.infinitejourneys.in/js/sitePath.js" ] $ ""
            toHtmlRaw  "<!--commaon js files-->"
            script_ [ type_ "text/javascript", src_ "http://www.infinitejourneys.in/js/overthrow.min.js", defer_ "defer" ] $ ""
            script_ [ src_ "http://www.infinitejourneys.in/js/modernizr.custom.js", type_ "text/javascript", defer_ "defer" ] $ ""
            toHtmlRaw  "<!--responsive support-->"
            script_ [ type_ "text/javascript", src_ "http://www.infinitejourneys.in/js/jquery.mmenu.js", defer_ "defer" ] $ ""
            toHtmlRaw  "<!--responsive-menu-->"
            script_ [ type_ "text/javascript", src_ "http://www.infinitejourneys.in/js/jquery.mousewheel.js", defer_ "defer" ] $ ""
            toHtmlRaw  "<!-- the mousewheel plugin -->"
            toHtmlRaw  "<!-- <script src=\"http://www.infinitejourneys.in/js/fancyfields-1.2.min.js\" type=\"text/javascript\" defer=\"defer\"></script> -->"
            script_ [ src_ "http://www.infinitejourneys.in/js/jquery.lazyload.js", type_ "text/javascript", defer_ "defer" ] $ ""
            toHtmlRaw  "<!-- lazyload images js -->"
            script_ [ type_ "text/javascript", src_ "http://www.infinitejourneys.in/js/jquery.bxslider.min.js", defer_ "defer" ] $ ""
            toHtmlRaw  "<!-- bx slider js -->"
            script_ [ type_ "text/javascript", src_ "http://www.infinitejourneys.in/js/jquery.easing.min.js", defer_ "defer" ] $ ""
            script_ [ type_ "text/javascript", src_ "http://www.infinitejourneys.in/js/popupSocial.js", defer_ "defer" ] $ ""
            toHtmlRaw  "<!-- footer social popuip window -->"
            toHtmlRaw  "<!--end commaon js files-->"
            toHtmlRaw  "<!-- Facebook Conversion Code for Foliage Outdoors -->"
            script_ "(function() {\n    var _fbq = window._fbq || (window._fbq = []);\n    if (!_fbq.loaded) {\n    var fbds = document.createElement('script');\n    fbds.async = true;\n    fbds.src = '//connect.facebook.net/en_US/fbds.js';\n    var s = document.getElementsByTagName('script')[0];\n    s.parentNode.insertBefore(fbds, s);\n    _fbq.loaded = true;\n    }\n    })();\n    window._fbq = window._fbq || [];\n    window._fbq.push(['track', '6032443521819', {'value':'0.00','currency':'INR'}]);\n    "
            noscript_ $ img_ [ height_ "1", width_ "1", alt_ "", style_ "display:none", src_ "https://www.facebook.com/tr?ev=6032443521819&cd[value]=0.00&cd[currency]=INR&noscript=1" ]
            link_ [ rel_ "canonical", href_ " http://www.infinitejourneys.in/infinite-journeys/ " ]
            meta_ [ name_ "robots", content_ "index, follow" ]
            meta_ [ property_ "og:type", content_ "website" ]
            meta_ [ property_ "og:url", content_ "http://www.infinitejourneys.in/infinite-journeys/" ]
            meta_ [ property_ "og:site_name", content_ "Infinite Journeys" ]
            meta_ [ property_ "og:image", content_ "http://www.infinitejourneys.in/templates/default/images/layout/logoInfinite.png" ]
            script_ [ src_ "http://www.infinitejourneys.in/js/scrollIt.min.js", type_ "text/javascript", defer_ "defer" ] $ ""
            script_ [ type_ "text/javascript", src_ "http://www.infinitejourneys.in/js/globalTours.js" ] $ ""
            script_ [ type_ "text/javascript", src_ "http://www.infinitejourneys.in/js/smallBannerBxSlider.js", defer_ "defer" ] $ ""
            script_ [ type_ "text/javascript", src_ "http://www.infinitejourneys.in/js/vCarts.js", defer_ "defer" ] $ ""
            script_ [ type_ "text/javascript", src_ "http://www.infinitejourneys.in/js/updatesSlide.js", defer_ "defer" ] $ ""
            script_ [ src_ "http://www.infinitejourneys.in/js/infiniteHomeSearch.js", type_ "text/javascript", defer_ "defer" ] $ ""
            script_ [ src_ "http://www.infinitejourneys.in/js/show-more-less.js", type_ "text/javascript", defer_ "defer" ] $ ""
            script_ [ type_ "text/javascript", src_ "http://www.infinitejourneys.in/js/ajax-countryList.js", defer_ "defer" ] $ ""
            toHtmlRaw  "<!-- ajax-country List -->"
            script_ [ type_ "text/javascript" ] $ "\n    // Script to get blog articles related to search\n    $(document).ready(function(){\n        \n        $(\"li.boxImages\").hover(function () { $(this).children(\".hoverDiv\").fadeToggle(); });\n           \n        $('#recentBlogs').html('<h3 class=\"recntBlogs\">Loading recent articles...</h3>');\n        $.post('http://'+ window.location.host +'/blog/infinitepost/',function(data){\n            setTimeout(function() {\n                $('#recentBlogs').html(data);\n                $(\".updatesSlide\").bxSlider({mode:\"horizontal\",captions:false,pager:true,touchEnabled:true,controls:false,auto:true});\n                $(\"#recentBlogs .bx-pager-item\").last().hide();\n            }, 2000);\n        });\n\n    });\n"
            script_ [ type_ "text/javascript", language_ "javascript" ] $ "\n\n$(document).ready(function(){\n\n\t$('#spinner').fadeOut(200); // will first fade out the loading animation\n\t$('#preloaderIn').delay(500).fadeOut('slow'); // will fade out the white DIV that covers the website.\n\t$('body').delay(500).css({'overflow':'visible'});\n\n\t$('nav#menu').mmenu();\n\t$('.viewByOnlyFoliage, .foliageThemesBox, .boxAge, .boxFromDate, .boxToDate, .boxPriceRange').hide();\n\n  $(\"#year\").html((new Date).getFullYear())\n\n});\n\n\n\n"
            toHtmlRaw  "<!-- Favicons================================================== -->"
            link_ [ rel_ "shortcut icon", href_ "http://www.infinitejourneys.in/templates/default/images/favicon.ico" ]
            link_ [ rel_ "apple-touch-icon", href_ "http://www.infinitejourneys.in/templates/default/images/apple-touch-icon.png" ]
            link_ [ rel_ "apple-touch-icon", sizes_ "72x72", href_ "http://www.infinitejourneys.in/templates/default/images/apple-touch-icon-72x72.png" ]
            link_ [ rel_ "apple-touch-icon", sizes_ "114x114", href_ "http://www.infinitejourneys.in/templates/default/images/apple-touch-icon-114x114.png" ]
            toHtmlRaw  "<!--[if lt IE 7]>\n<style media=\"screen\" type=\"text/css\">\n#container {\n    height:100%;\n}\n</style>\n<![endif]-->"
            style_ "\n.advncSrchLdrImg{\n\tfloat: right;\n    margin-right: -14px;\n    margin-top: -32px;\n\tdisplay:none;\n}\n.ijLoadMoreTours .load_more{\n  \tbackground: none repeat scroll 0 0 #e65322;\n    border: 1px solid #e03901;\n    border-radius: 5px;\n    color: #ffffff;\n    display: block;\n    float: left;\n    font-size: 12px;\n\theight: 35px;\n    line-height: 35px;\n\tpadding: 0;\n    text-align: center;\n    text-transform: uppercase;\n    width: 120px;\n\tmargin-left:42%;\n}\n\n.ijLoadMoreTours .load_more:hover {\n    color: #f87043;\n}\n"
            toHtmlRaw  "<!-- Facebook Pixel Code -->"
            script_ "\n!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?\nn.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;\nn.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;\nt.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,\ndocument,'script','https://connect.facebook.net/en_US/fbevents.js');\n\nfbq('init', '1565756943734145');\nfbq('track', \"PageView\");\n\n// ViewContent\n// Track key page views (ex: product page, landing page or article)\nfbq('track', 'ViewContent');\n\n\n// Search\n// Track searches on your website (ex. product searches)\nfbq('track', 'Search');\n\n\n// AddToCart\n// Track when items are added to a shopping cart (ex. click/landing page on Add to Cart button)\nfbq('track', 'AddToCart');\n\n\n// AddToWishlist\n// Track when items are added to a wishlist (ex. click/landing page on Add to Wishlist button)\nfbq('track', 'AddToWishlist');\n\n\n// InitiateCheckout\n// Track when people enter the checkout flow (ex. click/landing page on checkout button)\nfbq('track', 'InitiateCheckout');\n\n\n// AddPaymentInfo\n// Track when payment information is added in the checkout flow (ex. click/landing page on billing info)\nfbq('track', 'AddPaymentInfo');\n\n\n// Purchase\n// Track purchases or checkout flow completions (ex. landing on \"Thank You\" or confirmation page)\nfbq('track', 'Purchase', {value: '1.00', currency: 'USD'});\n\n\n// Lead\n// Track when a user expresses interest in your offering (ex. form submission, sign up for trial, landing on pricing page)\nfbq('track', 'Lead');\n\n\n// CompleteRegistration\n// Track when a registration form is completed (ex. complete subscription, sign up for a service)\nfbq('track', 'CompleteRegistration');\n\n\n// Other\n// \nfbq('track', 'Other');\n\n\n"
            noscript_ $ img_ [ height_ "1", width_ "1", style_ "display:none", src_ "https://www.facebook.com/tr?id=1565756943734145&ev=PageView&noscript=1" ]
            toHtmlRaw  "<!-- End Facebook Pixel Code -->"
            script_ "\n  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){\n  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),\n  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)\n  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');\n\n  ga('create', 'UA-54361594-1', 'auto');\n  ga('send', 'pageview');\n"
        toHtmlRaw  "<!-- Primary Page Layout================================================== -->"
        body_ [ id_ "ij" ] $ do
            toHtmlRaw  "<!-- Preloader -->"
            div_ [ id_ "preloaderIn" ] $ div_ [ class_ "spinner" ] $ do
                div_ [ class_ "spinner-container container1" ] $ do
                    div_ [ class_ "circle1" ] $ ""
                    div_ [ class_ "circle2" ] $ ""
                    div_ [ class_ "circle3" ] $ ""
                    div_ [ class_ "circle4" ] $ ""
                div_ [ class_ "spinner-container container2" ] $ do
                    div_ [ class_ "circle1" ] $ ""
                    div_ [ class_ "circle2" ] $ ""
                    div_ [ class_ "circle3" ] $ ""
                    div_ [ class_ "circle4" ] $ ""
                div_ [ class_ "spinner-container container3" ] $ do
                    div_ [ class_ "circle1" ] $ ""
                    div_ [ class_ "circle2" ] $ ""
                    div_ [ class_ "circle3" ] $ ""
                    div_ [ class_ "circle4" ] $ ""
            div_ [ class_ "top-container" ] $ do
                div_ [ id_ "page" ] $ do
                    div_ [ id_ "header" ] $ a_ [ href_ "#menu" ] $ ""
                    div_ [ id_ "content" ] $ do
                        style_ [ type_ "text/css" ] $ "\n.topPhoneNo {\n\tposition: absolute;\n\tright: 0px;\n\ttop: 10px;\n\tfont-weight: bold;\n\tfont-size: 12px;\n\tcolor:#666;\n    width: 135px;\n}\n.topPhoneNo span{\n\tcolor:#666;\n\tfont-size:12px;\n}\n.topPhoneNoIcon {\ndisplay: block;\nwidth: 14px;\nheight: 18px;\nfloat: left;\nmargin-right: 2px;\npadding-top: 3px;\n}\n"
                        header_ $ div_ [ class_ "container" ] $ do
                            div_ [ class_ "three columns logo" ] $ do
                                a_ [ href_ "http://www.infinitejourneys.in/infinite-journeys/" ] $ img_ [ src_ "http://www.infinitejourneys.in/templates/default/images/layout/logoInfinite.png", class_ "logoIj", title_ "Infinite Journeys", alt_ "Infinite Journeys Best Travel Agency in Pune" ]
                                a_ [ href_ "http://www.infinitejourneys.in/foliage-outdoors/" ] $ img_ [ src_ "http://www.infinitejourneys.in/templates/default/images/layout/logoFoliage.png", class_ "logoFo", title_ "Foliage Outdoors", alt_ "Foliage Outdoors offering a diverse mix of Wildlife tours, Adventure camps, Trekking and Nature holidays." ]
                            div_ [ class_ "nine columns" ] $ div_ [ id_ "tabs" ] $ do
                                div_ [ class_ "home-btns" ] $ do
                                    div_ [ class_ "call-btn" ] $ do
                                        img_ [ src_ "http://www.infinitejourneys.in/templates/default/images/layout/phoneIcon.png", class_ "topPhoneNoIcon", alt_ "Phone Icon" ]
                                        span_ "+91 - 20 - 66447777"
                                    toHtmlRaw  "<!-- <a href=\"http://online.infinitejourneys.in/\" target=\"_blank\">\n                <div class=\"first-btn\">\n                    <img src=\"http://www.infinitejourneys.in/templates/default/images/layout/airplane.png\" alt=\"Airplane\">\n                    <h2>Flight Booking</h2>\n                </div>\n            </a> -->"
                                    toHtmlRaw  "<!-- <a href=\"http://online.infinitejourneys.in/\" target=\"_blank\">\n                <div class=\"second-btn\">\n                    <img src=\"http://www.infinitejourneys.in/templates/default/images/layout/khat.png\" alt=\"Hotel Booking\">\n                    <h2>Hotel Booking</h2>\n                </div>\n            </a> -->"
                                ul_ [ id_ "tabMenu" ] $ do
                                    li_ [ class_ "regular" ] $ a_ [ href_ "http://www.infinitejourneys.in", title_ "Home" ] $ "Home"
                                    li_ [ class_ "regular dropdown" ] $ do
                                        a_ [ href_ "http://www.infinitejourneys.in/about-us/", title_ "About Us" ] $ " About Us "
                                        ul_ [ class_ "dropdownSub" ] $ do
                                            span_ [ class_ "topArrow" ] $ ""
                                            li_ $ a_ [ href_ "http://www.infinitejourneys.in/about-us/#horizontalTab1", onclick_ "window.location.reload(true);", title_ "Our Story" ] $ "Our Story"
                                            li_ $ a_ [ href_ "http://www.infinitejourneys.in/about-us/#horizontalTab2", onclick_ "window.location.reload(true);", title_ "Our Vision & Values" ] $ "Our Vision & Values"
                                            li_ $ a_ [ href_ "http://www.infinitejourneys.in/about-us/#horizontalTab3", onclick_ "window.location.reload(true);", title_ "Why Us?" ] $ "Why Us?"
                                            li_ $ a_ [ href_ "http://www.infinitejourneys.in/about-us/#horizontalTab4", onclick_ "window.location.reload(true);", title_ "Our People" ] $ "Our People"
                                    li_ [ class_ "regular dropdown" ] $ do
                                        a_ [ href_ "javacript:void(0);", title_ "Our Services" ] $ " Our Services"
                                        ul_ [ class_ "dropdownSub" ] $ do
                                            span_ [ class_ "topArrow" ] $ ""
                                            li_ $ a_ [ href_ "http://www.infinitejourneys.in/infinite-journeys/", title_ "Infinite Journeys" ] $ "Infinite Journeys"
                                            li_ $ a_ [ href_ "http://www.infinitejourneys.in/foliage-outdoors/", title_ "Foliage Outdoors" ] $ "Foliage Outdoors"
                                            li_ $ a_ [ href_ "http://www.infinitejourneys.in/school-tours/", title_ "School Tours" ] $ "School Tours"
                                            li_ $ a_ [ href_ "http://www.infinitejourneys.in/corporate-tours/", title_ "Corporate Services" ] $ "Corporate Services"
                                            li_ $ a_ [ href_ "http://www.infinitejourneys.in/travel-consultancy/", title_ "Travel Consultancy" ] $ "Travel Consultancy"
                                            li_ $ a_ [ href_ "http://www.infinitejourneys.in/india-travel-partner/", title_ "India Travel Partner (DMC)" ] $ "India Travel Partner (DMC)"
                                    li_ [ class_ "regular" ] $ a_ [ href_ "http://www.infinitejourneys.in/gallery/", title_ "Gallery" ] $ "Gallery"
                                    li_ [ class_ "regular" ] $ a_ [ href_ "http://www.infinitejourneys.in/testimonials/", title_ "Testimonials" ] $ " Testimonials"
                                    li_ [ class_ "regular dropdown" ] $ do
                                        a_ [ href_ "javacript:void(0);", title_ "Announcement" ] $ "Blog & Updates"
                                        ul_ [ class_ "dropdownSub" ] $ do
                                            span_ [ class_ "topArrow" ] $ ""
                                            li_ $ a_ [ href_ "http://www.infinitejourneys.in/blog", title_ "Blog & Updates" ] $ "Blog & Updates"
                                            li_ $ a_ [ href_ "http://www.infinitejourneys.in/fo/sms-alerts", title_ "Live SMS Updates" ] $ "Live SMS Updates"
                                    li_ [ class_ "regular removePd" ] $ a_ [ href_ "http://www.infinitejourneys.in/contact-us/", title_ "Contact Us" ] $ "Contact Us"
                                    div_ [ class_ "clear" ] $ ""
                        section_ [ id_ "banner" ] $ ul_ [ class_ "bannerSlide" ] $ do
                            li_ $ img_ [ src_ "http://www.infinitejourneys.in/uploads/banners/infinite/1920x620/IMG_3496_AG_TZ.jpg" ]
                            li_ $ img_ [ src_ "http://www.infinitejourneys.in/uploads/banners/infinite/1920x620/IMG_8611b_antartica_RR_banner.jpg" ]
                            li_ $ img_ [ src_ "http://www.infinitejourneys.in/uploads/banners/infinite/1920x620/Poon_HIll_banner.jpg" ]
                            li_ $ img_ [ src_ "http://www.infinitejourneys.in/uploads/banners/infinite/1920x620/_DSC0134_a.jpg" ]
                            li_ $ img_ [ src_ "http://www.infinitejourneys.in/uploads/banners/infinite/1920x620/infiniteBanner1uglO.jpg" ]
                            li_ $ img_ [ src_ "http://www.infinitejourneys.in/uploads/banners/infinite/1920x620/Capetown_South_Africa.jpg" ]
                        style_ "\n.recntBlogs{\n    margin-top: 80px;\n    font-size: 20px !important;\n    text-align: center;\n}\n.moreAboutCompanies {\nfont-size: 14px;\nline-height: 21px;\nmargin: 0 0 14px;\n}\n.moreAboutSectionTours {\nfont-size: 14px;\nline-height: 21px;\nmargin: 0 0 14px;\n}\n.morecontent span {\ndisplay: none;\nfont-size:14px;\n}\n.seeAllTxtIJ{\n    color:#f96130 !important;\n    font-size:14px;\n}\n"
                        section_ [ id_ "details" ] $ div_ [ class_ "container" ] $ do
                            div_ [ id_ "clientsDropDown" ] $ do
                                div_ [ id_ "clientsOpen" ] $ a_ [ href_ "javascript:void:(0);" ] $ p_ ""
                                div_ [ id_ "clientsDashboard", class_ "foreGround boxShadow demo1" ] $ form_ $ do
                                    div_ [ class_ "rowElem radioSection" ] $ do
                                        div_ [ class_ "coll1", title_ "Infinite Journeys" ] $ do
                                            input_ [ type_ "radio", name_ "question", value_ "1", class_ "folgeBasicSrch", id_ "customClick", checked_ ]
                                            label_ [ for_ "customClick" ] $ "Infinite"
                                            p_ "Plan Your Holiday"
                                        div_ [ class_ "coll2", title_ "Foliage Outdoors" ] $ do
                                            input_ [ type_ "radio", name_ "question", value_ "2", class_ "folgeBasicSrch", id_ "conductedClick" ]
                                            label_ [ for_ "conductedClick" ] $ "Foliage"
                                            p_ "Join Our Trips"
                                        div_ [ class_ "clear" ] $ ""
                                    div_ [ class_ "selectSectionBox", style_ "position:relative;" ] $ do
                                        div_ [ class_ "rowElem selectSection", id_ "viewByOnlyFoliage" ] $ do
                                            label_ [ for_ "selectViewByName" ] $ "View By"
                                            select_ [ name_ "select2", class_ "selectViewByName", id_ "selectViewByName" ] $ do
                                                option_ [ value_ "" ] $ "-Select-"
                                                option_ [ value_ "all" ] $ "All"
                                                option_ [ value_ "month-wise" ] $ "Month-wise"
                                        div_ [ class_ "showBigLoadersImg", style_ "left:20%;position:absolute;top:40%" ] $ ""
                                        div_ [ class_ "getResultsViewBy" ] $ do
                                            div_ [ class_ "rowElem selectSection foliageThemesBox", title_ "Themes" ] $ do
                                                label_ [ for_ "selectThemeTxtFO" ] $ "Themes"
                                                select_ [ name_ "select2", id_ "selectThemeTxtFO" ] $ do
                                                    option_ [ value_ "" ] $ "-Select Theme-"
                                                    option_ [ value_ " Kids Camp (8-10 yrs)" ] $ " Kids Camp (8-10 yrs)"
                                                    option_ [ value_ "International Tours " ] $ "International Tours "
                                                    option_ [ value_ "Kids Camp (10-12 yrs)" ] $ "Kids Camp (10-12 yrs)"
                                                    option_ [ value_ "MNS School" ] $ "MNS School"
                                                    option_ [ value_ "Open Age : Backpacking Tours" ] $ "Open Age : Backpacking Tours"
                                                    option_ [ value_ "Open Age : Special Tours" ] $ "Open Age : Special Tours"
                                                    option_ [ value_ "Open Age : Treks & Leisure Treks" ] $ "Open Age : Treks & Leisure Treks"
                                                    option_ [ value_ "Open Age : Wildlife Tours" ] $ "Open Age : Wildlife Tours"
                                                    option_ [ value_ "Students : Adventure Camp & Treks" ] $ "Students : Adventure Camp & Treks"
                                                    option_ [ value_ "Students : Wildlife Camps" ] $ "Students : Wildlife Camps"
                                                    option_ [ value_ "Upcoming Tours" ] $ "Upcoming Tours"
                                                    option_ [ value_ "Youth Camps (14 to 22 years)" ] $ "Youth Camps (14 to 22 years)"
                                            div_ [ class_ "rowElem selectSection infiniteThemesBox", title_ "Themes" ] $ do
                                                label_ [ for_ "selectThemeTxtIJ" ] $ "Themes"
                                                select_ [ name_ "select2", id_ "selectThemeTxtIJ" ] $ do
                                                    option_ [ value_ "" ] $ "-Select Theme-"
                                                    option_ [ value_ "Classic" ] $ "Classic"
                                                    option_ [ value_ "Family" ] $ "Family"
                                                    option_ [ value_ "Honeymoon" ] $ "Honeymoon"
                                                    option_ [ value_ "Off-the-track" ] $ "Off-the-track"
                                                    option_ [ value_ "Special Interest" ] $ "Special Interest"
                                            div_ [ class_ "rowElem selectSection showRegionCountry", title_ "Region" ] $ do
                                                label_ [ for_ "selectContinentTxt" ] $ "Region "
                                                select_ [ name_ "select2", id_ "selectContinentTxt", class_ "regionNameVal" ] $ do
                                                    option_ [ value_ "##" ] $ "-Select Region-"
                                                    option_ [ value_ "AF##Africa" ] $ "Africa"
                                                    option_ [ value_ "AN##Antarctica" ] $ "Antarctica"
                                                    option_ [ value_ "AS##Asia", selected_ "selected" ] $ "Asia"
                                                    option_ [ value_ "OC##Australia and New Zealand" ] $ "Australia and New Zealand"
                                                    option_ [ value_ "EU##Europe" ] $ "Europe"
                                                    option_ [ value_ "NA##North America" ] $ "North America"
                                                    option_ [ value_ "SA##South America" ] $ "South America"
                                            div_ [ class_ "rowElem selectSection showRegionCountry", title_ "Country" ] $ do
                                                label_ [ for_ "selectCountryTxt" ] $ "Country"
                                                select_ [ name_ "select2", id_ "selectCountryTxt", class_ "countryNameVal" ] $ do
                                                    option_ [ value_ "##" ] $ "-Select Country-"
                                                    option_ [ value_ "26##Bhutan" ] $ "Bhutan"
                                                    option_ [ value_ "39##Cambodia" ] $ "Cambodia"
                                                    option_ [ value_ "101##Hong Kong" ] $ "Hong Kong"
                                                    option_ [ value_ "104##India", selected_ "selected" ] $ "India"
                                                    option_ [ value_ "105##Indonesia" ] $ "Indonesia"
                                                    option_ [ value_ "262##Japan" ] $ "Japan"
                                                    option_ [ value_ "136##Malaysia" ] $ "Malaysia"
                                                    option_ [ value_ "137##Maldives" ] $ "Maldives"
                                                    option_ [ value_ "157##Nepal" ] $ "Nepal"
                                                    option_ [ value_ "168##Oman" ] $ "Oman"
                                                    option_ [ value_ "176##Philippines" ] $ "Philippines"
                                                    option_ [ value_ "201##Singapore" ] $ "Singapore"
                                                    option_ [ value_ "211##Sri Lanka" ] $ "Sri Lanka"
                                                    option_ [ value_ "222##Thailand" ] $ "Thailand"
                                                    option_ [ value_ "229##Turkey" ] $ "Turkey"
                                                    option_ [ value_ "235##United Arab Emirates" ] $ "United Arab Emirates"
                                                    option_ [ value_ "244##Vietnam" ] $ "Vietnam"
                                            div_ [ class_ "rowElem selectSection", id_ "foliageAgeGroupBox", title_ "Age Group" ] $ do
                                                label_ [ for_ "selectAgeGroupTxt" ] $ "Age Group"
                                                select_ [ name_ "select2", id_ "selectAgeGroupTxt", class_ "stateNameVal" ] $ do
                                                    option_ [ value_ "" ] $ "-Select Age Group-"
                                                    option_ [ value_ "Kids (8 to 10 yrs)" ] $ "Kids (8 to 10 yrs)"
                                                    option_ [ value_ "Students (10 to 16 yrs)" ] $ "Students (10 to 16 yrs)"
                                                    option_ [ value_ "For All Ages" ] $ "For All Ages"
                                                    option_ [ value_ "Kids (10 to 12 yrs)" ] $ "Kids (10 to 12 yrs)"
                                                    option_ [ value_ "Students (14 to 22 yrs)" ] $ "Students (14 to 22 yrs)"
                                        div_ [ class_ "clear" ] $ ""
                                    div_ [ class_ "rowElem serachBtnElem" ] $ do
                                        img_ [ src_ "http://www.infinitejourneys.in/templates/default/images/admin/img/loaders/5.gif", style_ "display:none;", id_ "folgeSrchImgLdr" ]
                                        input_ [ type_ "button", value_ "Show Trips", class_ "searchBtn", id_ "searchInfiniteRec" ]
                                    div_ [ class_ "clear" ] $ ""
                            div_ [ class_ "seven columns offset-by-five packeage" ] $ ""
                        section_ [ id_ "bodyContainer" ] $ div_ [ class_ "container" ] $ do
                            div_ [ class_ "eight columns" ] $ do
                                h2_ "About Infinite Journeys"
                                div_ [ class_ "moreAboutCompaniesIj" ] $ do
                                    p_ "Infinite Journeys is the parent company that encompasses some of the leading travel brands like Foliage Outdoors, Kundalika Rafting, Explore Wild India and Pune Car Rentals. Over the years the company has consolidated its image as the most preferred travel design and consultancy with its niche being offbeat destinations."
                                    p_ "At Infinite Journeys, there is something for everyone; be it the annual family vacation, adventure getaway with your group of friends, the exotic international trip or your honeymoon."
                                    p_ "Over the years, Infinite Journeys have earned the tags like travel designers, travel partners, offbeat experts and customized travel planners. "
                            div_ [ class_ "four columns", id_ "recentBlogs" ] $ ""
                            div_ [ class_ "twelve columns divider" ] $ ""
                            div_ [ class_ "three columns" ] $ do
                                h3_ [ class_ "homeStyle" ] $ "Top Picks India"
                                div_ [ class_ "moreAboutSectionTours" ] $ p_ "Explore the magic called India with some of these must-visit destinations."
                            div_ [ class_ "nine columns" ] $ div_ [ class_ "card vCardOne" ] $ do
                                div_ [ class_ "threeBtns" ] $ a_ [ class_ "seeAll", href_ "http://www.infinitejourneys.in/ij/see-all?id=1&category=Top Picks India" ] $ "See All"
                                ul_ [ class_ "vCardSlide" ] $ do
                                    li_ [ class_ "boxImages" ] $ a_ [ href_ "http://www.infinitejourneys.in/tour/himachal-delights-34", title_ "Himachal Delights" ] $ do
                                        div_ [ class_ "shadowBox" ] $ img_ [ src_ "http://www.infinitejourneys.in/uploads/gallery/infinite/220x190/hp41_1405151765.JPG", align_ "absmiddle", alt_ "hp41_1405151765.JPG" ]
                                        div_ [ class_ "hideContent" ] $ do
                                            div_ [ class_ "countriName" ] $ do
                                                p_ "Himachal Delights"
                                                toHtmlRaw  "<!-- <p>Himachal Delights</p> -->"
                                                h6_ [ class_ "font" ] $ "9 Days/8 Nights"
                                            div_ [ class_ "countriAdven" ] $ toHtmlRaw  "<!-- <p>9 Days/8 Nights</p> -->"
                                            div_ [ class_ "countriAdven" ] $ do
                                                p_ [ class_ "familyClass" ] $ "Family, Off-the-track, Special Interest"
                                                toHtmlRaw  "<!--   <p class=\"familyClass\">Family,...</p> -->"
                                        div_ [ class_ "hoverDiv" ] $ do
                                            div_ [ class_ "botHoverDiv" ] $ a_ [ href_ "http://www.infinitejourneys.in/tour/himachal-delights-34", title_ "Himachal Delights" ] $ do
                                                p_ "Thanedar, Sojha, Manali, Chandigarh "
                                                toHtmlRaw  "<!--                                               Destinations :  Thanedar, Sojha, Manali, Chan +\n                                         -->"
                                            div_ [ class_ "clear" ] $ ""
                                    li_ [ class_ "boxImages" ] $ a_ [ href_ "http://www.infinitejourneys.in/tour/comprehensive-kerala", title_ "Comprehensive Kerala" ] $ do
                                        div_ [ class_ "shadowBox" ] $ img_ [ src_ "http://www.infinitejourneys.in/uploads/gallery/infinite/220x190/kerala_1404367614.jpg", align_ "absmiddle", alt_ "kerala_1404367614.jpg" ]
                                        div_ [ class_ "hideContent" ] $ do
                                            div_ [ class_ "countriName" ] $ do
                                                p_ "Comprehensive Kerala"
                                                toHtmlRaw  "<!-- <p>Comprehensive Kerala</p> -->"
                                                h6_ [ class_ "font" ] $ "11 Days/10 Nights"
                                            div_ [ class_ "countriAdven" ] $ toHtmlRaw  "<!-- <p>11 Days/10 Nights</p> -->"
                                            div_ [ class_ "countriAdven" ] $ do
                                                p_ [ class_ "familyClass" ] $ "Classic, Family"
                                                toHtmlRaw  "<!--   <p class=\"familyClass\">Classic, Family</p> -->"
                                        div_ [ class_ "hoverDiv" ] $ do
                                            div_ [ class_ "botHoverDiv" ] $ a_ [ href_ "http://www.infinitejourneys.in/tour/comprehensive-kerala", title_ "Comprehensive Kerala" ] $ do
                                                p_ "Cochin, Munnar, Periyar, Alleppey or Kumarakom, Thiruvananthapuram "
                                                toHtmlRaw  "<!--                                               Destinations :  Cochin, Munnar, Periyar, Alle +\n                                         -->"
                                            div_ [ class_ "clear" ] $ ""
                                    li_ [ class_ "boxImages" ] $ a_ [ href_ "http://www.infinitejourneys.in/tour/the-golden-triangle-32", title_ "The Golden Triangle" ] $ do
                                        div_ [ class_ "shadowBox" ] $ img_ [ src_ "http://www.infinitejourneys.in/uploads/gallery/infinite/220x190/DSC00982__Custom__1404307429.JPG", align_ "absmiddle", alt_ "DSC00982__Custom__1404307429.JPG" ]
                                        div_ [ class_ "hideContent" ] $ do
                                            div_ [ class_ "countriName" ] $ do
                                                p_ "The Golden Triangle"
                                                toHtmlRaw  "<!-- <p>The Golden Triangle</p> -->"
                                                h6_ [ class_ "font" ] $ "6 Days/5 Nights"
                                            div_ [ class_ "countriAdven" ] $ toHtmlRaw  "<!-- <p>6 Days/5 Nights</p> -->"
                                            div_ [ class_ "countriAdven" ] $ do
                                                p_ [ class_ "familyClass" ] $ "Classic, Family"
                                                toHtmlRaw  "<!--   <p class=\"familyClass\">Classic, Family</p> -->"
                                        div_ [ class_ "hoverDiv" ] $ do
                                            div_ [ class_ "botHoverDiv" ] $ a_ [ href_ "http://www.infinitejourneys.in/tour/the-golden-triangle-32", title_ "The Golden Triangle" ] $ do
                                                p_ "Delhi, Agra, Fatehpur Sikri, Jaipur "
                                                toHtmlRaw  "<!--                                               Destinations :  Delhi, Agra, Fatehpur Sikri,  +\n                                         -->"
                                            div_ [ class_ "clear" ] $ ""
                                    li_ [ class_ "boxImages" ] $ a_ [ href_ "http://www.infinitejourneys.in/tour/enthralling-rajasthan", title_ "Enthralling Rajasthan" ] $ do
                                        div_ [ class_ "shadowBox" ] $ img_ [ src_ "http://www.infinitejourneys.in/uploads/gallery/infinite/220x190/IMG_3743__Custom__1404303835.JPG", align_ "absmiddle", alt_ "IMG_3743__Custom__1404303835.JPG" ]
                                        div_ [ class_ "hideContent" ] $ do
                                            div_ [ class_ "countriName" ] $ do
                                                p_ "Enthralling Rajasthan"
                                                toHtmlRaw  "<!-- <p>Enthralling Rajasthan</p> -->"
                                                h6_ [ class_ "font" ] $ "8 Days/7 Nights"
                                            div_ [ class_ "countriAdven" ] $ toHtmlRaw  "<!-- <p>8 Days/7 Nights</p> -->"
                                            div_ [ class_ "countriAdven" ] $ do
                                                p_ [ class_ "familyClass" ] $ "Classic, Family"
                                                toHtmlRaw  "<!--   <p class=\"familyClass\">Classic, Family</p> -->"
                                        div_ [ class_ "hoverDiv" ] $ do
                                            div_ [ class_ "botHoverDiv" ] $ a_ [ href_ "http://www.infinitejourneys.in/tour/enthralling-rajasthan", title_ "Enthralling Rajasthan" ] $ do
                                                p_ $ do
                                                    "Jodhpur , Jaisalmer"
                                                    strong_ ", "
                                                    "Ranakpur , Kumbhalgarh , Udaipur"
                                                toHtmlRaw  "<!--                                               Destinations :  Jodhpur , Jaisalmer ,&nbsp; R +\n                                         -->"
                                            div_ [ class_ "clear" ] $ ""
                                    li_ [ class_ "boxImages" ] $ a_ [ href_ "http://www.infinitejourneys.in/tour/best-of-central-india", title_ "Best of Central India" ] $ do
                                        div_ [ class_ "shadowBox" ] $ img_ [ src_ "http://www.infinitejourneys.in/uploads/gallery/infinite/220x190/Khajuraho-Temple-Madhy-pradesh_1404286674.jpg", align_ "absmiddle", alt_ "Khajuraho-Temple-Madhy-pradesh_1404286674.jpg" ]
                                        div_ [ class_ "hideContent" ] $ do
                                            div_ [ class_ "countriName" ] $ do
                                                p_ "Best of Central India"
                                                toHtmlRaw  "<!-- <p>Best of Central India</p> -->"
                                                h6_ [ class_ "font" ] $ "10 Days/9 Nights"
                                            div_ [ class_ "countriAdven" ] $ toHtmlRaw  "<!-- <p>10 Days/9 Nights</p> -->"
                                            div_ [ class_ "countriAdven" ] $ do
                                                p_ [ class_ "familyClass" ] $ "Classic, Family, Off-the-track, Special Interest"
                                                toHtmlRaw  "<!--   <p class=\"familyClass\">Classic,...</p> -->"
                                        div_ [ class_ "hoverDiv" ] $ do
                                            div_ [ class_ "botHoverDiv" ] $ a_ [ href_ "http://www.infinitejourneys.in/tour/best-of-central-india", title_ "Best of Central India" ] $ do
                                                p_ "Pachmarhi, Jabalpur, Amarkantak, Bandhavgarh, Khajuraho "
                                                toHtmlRaw  "<!--                                               Destinations :  Pachmarhi, Jabalpur, Amarkant +\n                                         -->"
                                            div_ [ class_ "clear" ] $ ""
                                    li_ [ class_ "boxImages" ] $ a_ [ href_ "http://www.infinitejourneys.in/tour/ladakh-ii", title_ "Ladakh II" ] $ do
                                        div_ [ class_ "shadowBox" ] $ img_ [ src_ "http://www.infinitejourneys.in/uploads/gallery/infinite/220x190/Khardung_1402122995.jpg", align_ "absmiddle", alt_ "Khardung_1402122995.jpg" ]
                                        div_ [ class_ "hideContent" ] $ do
                                            div_ [ class_ "countriName" ] $ do
                                                p_ "Ladakh II"
                                                toHtmlRaw  "<!-- <p>Ladakh II</p> -->"
                                                h6_ [ class_ "font" ] $ "6 Days/5 Nights"
                                            div_ [ class_ "countriAdven" ] $ toHtmlRaw  "<!-- <p>6 Days/5 Nights</p> -->"
                                            div_ [ class_ "countriAdven" ] $ do
                                                p_ [ class_ "familyClass" ] $ "Off-the-track, Special Interest"
                                                toHtmlRaw  "<!--   <p class=\"familyClass\">Off-the-track...</p> -->"
                                        div_ [ class_ "hoverDiv" ] $ do
                                            div_ [ class_ "botHoverDiv" ] $ a_ [ href_ "http://www.infinitejourneys.in/tour/ladakh-ii", title_ "Ladakh II" ] $ toHtmlRaw  "<!--                                               Destinations : \n                                         -->"
                                            div_ [ class_ "clear" ] $ ""
                                    li_ [ class_ "boxImages" ] $ a_ [ href_ "http://www.infinitejourneys.in/tour/spectacular-kashmir", title_ "Spectacular Kashmir" ] $ do
                                        div_ [ class_ "shadowBox" ] $ img_ [ src_ "http://www.infinitejourneys.in/uploads/gallery/infinite/220x190/IMG_6502_1402034013.JPG", align_ "absmiddle", alt_ "IMG_6502_1402034013.JPG" ]
                                        div_ [ class_ "hideContent" ] $ do
                                            div_ [ class_ "countriName" ] $ do
                                                p_ "Spectacular Kashmir"
                                                toHtmlRaw  "<!-- <p>Spectacular Kashmir</p> -->"
                                                h6_ [ class_ "font" ] $ "8 Days/7 Nights"
                                            div_ [ class_ "countriAdven" ] $ toHtmlRaw  "<!-- <p>8 Days/7 Nights</p> -->"
                                            div_ [ class_ "countriAdven" ] $ do
                                                p_ [ class_ "familyClass" ] $ "Classic, Family"
                                                toHtmlRaw  "<!--   <p class=\"familyClass\">Classic, Family</p> -->"
                                        div_ [ class_ "hoverDiv" ] $ do
                                            div_ [ class_ "botHoverDiv" ] $ a_ [ href_ "http://www.infinitejourneys.in/tour/spectacular-kashmir", title_ "Spectacular Kashmir" ] $ do
                                                p_ "Sonmarg, Pahalgam, Gulmarg, Srinagar"
                                                toHtmlRaw  "<!--                                               Destinations :  Sonmarg,&nbsp;Pahalgam, Gulma +\n                                         -->"
                                            div_ [ class_ "clear" ] $ ""
                                    div_ [ class_ "clear" ] $ ""
                            div_ [ class_ "twelve columns dividerSingle" ] $ ""
                            div_ [ class_ "three columns" ] $ do
                                h3_ [ class_ "homeStyle" ] $ "Top Picks International"
                                div_ [ class_ "moreAboutSectionTours" ] $ p_ "Infinite Journeys offers an exotic range of international destinations. Take your pick."
                            div_ [ class_ "nine columns" ] $ div_ [ class_ "card vCardOne" ] $ do
                                div_ [ class_ "threeBtns" ] $ a_ [ class_ "seeAll", href_ "http://www.infinitejourneys.in/ij/see-all?id=2&category=Top Picks International" ] $ "See All"
                                ul_ [ class_ "vCardSlide" ] $ do
                                    li_ [ class_ "boxImages" ] $ a_ [ href_ "http://www.infinitejourneys.in/tour/wild-kenya", title_ "Wild Kenya" ] $ do
                                        div_ [ class_ "shadowBox" ] $ img_ [ src_ "http://www.infinitejourneys.in/uploads/gallery/infinite/220x190/IMG_2729b-Lioness_1435925501.jpg", align_ "absmiddle", alt_ "IMG_2729b-Lioness_1435925501.jpg" ]
                                        div_ [ class_ "hideContent" ] $ do
                                            div_ [ class_ "countriName" ] $ do
                                                p_ "Wild Kenya"
                                                toHtmlRaw  "<!-- <p>Wild Kenya</p> -->"
                                                h6_ [ class_ "font" ] $ "9 Days/8 Nights"
                                            div_ [ class_ "countriAdven" ] $ toHtmlRaw  "<!-- <p>9 Days/8 Nights</p> -->"
                                            div_ [ class_ "countriAdven" ] $ do
                                                p_ [ class_ "familyClass" ] $ "Family, Honeymoon"
                                                toHtmlRaw  "<!--   <p class=\"familyClass\">Family,...</p> -->"
                                        div_ [ class_ "hoverDiv" ] $ do
                                            div_ [ class_ "botHoverDiv" ] $ a_ [ href_ "http://www.infinitejourneys.in/tour/wild-kenya", title_ "Wild Kenya" ] $ do
                                                p_ "Nairobi, Samburu, Sweetwaters, Lake Nakuru, Masai Mara"
                                                toHtmlRaw  "<!--                                               Destinations :  Nairobi, Samburu, Sweetwaters +\n                                         -->"
                                            div_ [ class_ "clear" ] $ ""
                                    li_ [ class_ "boxImages" ] $ a_ [ href_ "http://www.infinitejourneys.in/tour/best-of-france", title_ "Best Of France" ] $ do
                                        div_ [ class_ "shadowBox" ] $ img_ [ src_ "http://www.infinitejourneys.in/uploads/gallery/infinite/220x190/PrImg_3767_1435909780.jpg", align_ "absmiddle", alt_ "PrImg_3767_1435909780.jpg" ]
                                        div_ [ class_ "hideContent" ] $ do
                                            div_ [ class_ "countriName" ] $ do
                                                p_ "Best Of France"
                                                toHtmlRaw  "<!-- <p>Best Of France</p> -->"
                                                h6_ [ class_ "font" ] $ "10 Days/9 Nights"
                                            div_ [ class_ "countriAdven" ] $ toHtmlRaw  "<!-- <p>10 Days/9 Nights</p> -->"
                                            div_ [ class_ "countriAdven" ] $ do
                                                p_ [ class_ "familyClass" ] $ "Family, Honeymoon"
                                                toHtmlRaw  "<!--   <p class=\"familyClass\">Family,...</p> -->"
                                        div_ [ class_ "hoverDiv" ] $ do
                                            div_ [ class_ "botHoverDiv" ] $ a_ [ href_ "http://www.infinitejourneys.in/tour/best-of-france", title_ "Best Of France" ] $ do
                                                p_ "Paris, Versailles, Disneyland, Bordeux, Nice, Eze-Monte Carlo, Provence"
                                                toHtmlRaw  "<!--                                               Destinations :  Paris, Versailles, Disneyland +\n                                         -->"
                                            div_ [ class_ "clear" ] $ ""
                                    li_ [ class_ "boxImages" ] $ a_ [ href_ "http://www.infinitejourneys.in/tour/malaysian-escapade", title_ "Malaysian Escapade" ] $ do
                                        div_ [ class_ "shadowBox" ] $ img_ [ src_ "http://www.infinitejourneys.in/uploads/gallery/infinite/220x190/KL_night_view__Custom__1405082474.jpg", align_ "absmiddle", alt_ "KL_night_view__Custom__1405082474.jpg" ]
                                        div_ [ class_ "hideContent" ] $ do
                                            div_ [ class_ "countriName" ] $ do
                                                p_ "Malaysian Escapade"
                                                toHtmlRaw  "<!-- <p>Malaysian Escapade</p> -->"
                                                h6_ [ class_ "font" ] $ "8 Days/7 Nights"
                                            div_ [ class_ "countriAdven" ] $ toHtmlRaw  "<!-- <p>8 Days/7 Nights</p> -->"
                                            div_ [ class_ "countriAdven" ] $ do
                                                p_ [ class_ "familyClass" ] $ "Classic, Family"
                                                toHtmlRaw  "<!--   <p class=\"familyClass\">Classic, Family</p> -->"
                                        div_ [ class_ "hoverDiv" ] $ do
                                            div_ [ class_ "botHoverDiv" ] $ a_ [ href_ "http://www.infinitejourneys.in/tour/malaysian-escapade", title_ "Malaysian Escapade" ] $ do
                                                p_ "Langkawi , Kuala Lumpur , Negara National Park , Genting Highlands "
                                                toHtmlRaw  "<!--                                               Destinations :  Langkawi , Kuala Lumpur , Neg +\n                                         -->"
                                            div_ [ class_ "clear" ] $ ""
                                    li_ [ class_ "boxImages" ] $ a_ [ href_ "http://www.infinitejourneys.in/tour/overland-magnificent-bhutan", title_ "Overland Magnificent Bhutan" ] $ do
                                        div_ [ class_ "shadowBox" ] $ img_ [ src_ "http://www.infinitejourneys.in/uploads/gallery/infinite/220x190/art-Bhutan-Tourism-420x0_1404991730.jpg", align_ "absmiddle", alt_ "art-Bhutan-Tourism-420x0_1404991730.jpg" ]
                                        div_ [ class_ "hideContent" ] $ do
                                            div_ [ class_ "countriName" ] $ do
                                                p_ "Overland Magnificent Bhutan"
                                                toHtmlRaw  "<!-- <p>Overland Magnificent Bhutan</p> -->"
                                                h6_ [ class_ "font" ] $ "12 Days/11 Nights"
                                            div_ [ class_ "countriAdven" ] $ toHtmlRaw  "<!-- <p>12 Days/11 Nights</p> -->"
                                            div_ [ class_ "countriAdven" ] $ do
                                                p_ [ class_ "familyClass" ] $ "Family"
                                                toHtmlRaw  "<!--   <p class=\"familyClass\">Family</p> -->"
                                        div_ [ class_ "hoverDiv" ] $ do
                                            div_ [ class_ "botHoverDiv" ] $ a_ [ href_ "http://www.infinitejourneys.in/tour/overland-magnificent-bhutan", title_ "Overland Magnificent Bhutan" ] $ do
                                                p_ "Bagdogra, Phuentsholing, Paro, Thimpu, Punakha, Gangtey, Bumthang, Trongsa, Mongar, Trashigang, Samdrup Jongkhar, Guwahati "
                                                toHtmlRaw  "<!--                                               Destinations :  Bagdogra,&nbsp;Phuentsholing, +\n                                         -->"
                                            div_ [ class_ "clear" ] $ ""
                                    li_ [ class_ "boxImages" ] $ a_ [ href_ "http://www.infinitejourneys.in/tour/overland-bhutan", title_ "Overland Bhutan" ] $ do
                                        div_ [ class_ "shadowBox" ] $ img_ [ src_ "http://www.infinitejourneys.in/uploads/gallery/infinite/220x190/IMG_8021b_1406194503.jpg", align_ "absmiddle", alt_ "IMG_8021b_1406194503.jpg" ]
                                        div_ [ class_ "hideContent" ] $ do
                                            div_ [ class_ "countriName" ] $ do
                                                p_ "Overland Bhutan"
                                                toHtmlRaw  "<!-- <p>Overland Bhutan</p> -->"
                                                h6_ [ class_ "font" ] $ "7 Days/6 Nights"
                                            div_ [ class_ "countriAdven" ] $ toHtmlRaw  "<!-- <p>7 Days/6 Nights</p> -->"
                                            div_ [ class_ "countriAdven" ] $ do
                                                p_ [ class_ "familyClass" ] $ "Family"
                                                toHtmlRaw  "<!--   <p class=\"familyClass\">Family</p> -->"
                                        div_ [ class_ "hoverDiv" ] $ do
                                            div_ [ class_ "botHoverDiv" ] $ a_ [ href_ "http://www.infinitejourneys.in/tour/overland-bhutan", title_ "Overland Bhutan" ] $ do
                                                p_ "Bagdogra ,  Phuentsholing , Thimphu ,  Paro"
                                                toHtmlRaw  "<!--                                               Destinations :  Bagdogra , &nbsp;Phuentsholin +\n                                         -->"
                                            div_ [ class_ "clear" ] $ ""
                                    li_ [ class_ "boxImages" ] $ a_ [ href_ "http://www.infinitejourneys.in/tour/magnificent-bhutan", title_ "Magnificent Bhutan" ] $ do
                                        div_ [ class_ "shadowBox" ] $ img_ [ src_ "http://www.infinitejourneys.in/uploads/gallery/infinite/220x190/Bhutan00_1404911200.jpg", align_ "absmiddle", alt_ "Bhutan00_1404911200.jpg" ]
                                        div_ [ class_ "hideContent" ] $ do
                                            div_ [ class_ "countriName" ] $ do
                                                p_ "Magnificent Bhutan"
                                                toHtmlRaw  "<!-- <p>Magnificent Bhutan</p> -->"
                                                h6_ [ class_ "font" ] $ "11 Days/10 Nights"
                                            div_ [ class_ "countriAdven" ] $ toHtmlRaw  "<!-- <p>11 Days/10 Nights</p> -->"
                                            div_ [ class_ "countriAdven" ] $ do
                                                p_ [ class_ "familyClass" ] $ "Family"
                                                toHtmlRaw  "<!--   <p class=\"familyClass\">Family</p> -->"
                                        div_ [ class_ "hoverDiv" ] $ do
                                            div_ [ class_ "botHoverDiv" ] $ a_ [ href_ "http://www.infinitejourneys.in/tour/magnificent-bhutan", title_ "Magnificent Bhutan" ] $ do
                                                p_ "Paro , Thimphu , Punakha , Gangtey , Bumthang , Trongsa , Wandi/Punakha "
                                                toHtmlRaw  "<!--                                               Destinations :  Paro , Thimphu , Punakha , Ga +\n                                         -->"
                                            div_ [ class_ "clear" ] $ ""
                                    li_ [ class_ "boxImages" ] $ a_ [ href_ "http://www.infinitejourneys.in/tour/best-of-kenya", title_ "Best of Kenya" ] $ do
                                        div_ [ class_ "shadowBox" ] $ img_ [ src_ "http://www.infinitejourneys.in/uploads/gallery/infinite/220x190/migration_1404904165.jpg", align_ "absmiddle", alt_ "migration_1404904165.jpg" ]
                                        div_ [ class_ "hideContent" ] $ do
                                            div_ [ class_ "countriName" ] $ do
                                                p_ "Best of Kenya"
                                                toHtmlRaw  "<!-- <p>Best of Kenya</p> -->"
                                                h6_ [ class_ "font" ] $ "8 Days/7 Nights"
                                            div_ [ class_ "countriAdven" ] $ toHtmlRaw  "<!-- <p>8 Days/7 Nights</p> -->"
                                            div_ [ class_ "countriAdven" ] $ do
                                                p_ [ class_ "familyClass" ] $ "Off-the-track, Special Interest"
                                                toHtmlRaw  "<!--   <p class=\"familyClass\">Off-the-track...</p> -->"
                                        div_ [ class_ "hoverDiv" ] $ do
                                            div_ [ class_ "botHoverDiv" ] $ a_ [ href_ "http://www.infinitejourneys.in/tour/best-of-kenya", title_ "Best of Kenya" ] $ do
                                                p_ "Lake Nakuru, Masai Mara, Nairobi, Samburu"
                                                toHtmlRaw  "<!--                                               Destinations :  Lake Nakuru, Masai Mara, Nair +\n                                         -->"
                                            div_ [ class_ "clear" ] $ ""
                                    div_ [ class_ "clear" ] $ ""
                            div_ [ class_ "twelve columns dividerSingle" ] $ ""
                            div_ [ class_ "three columns" ] $ do
                                h3_ [ class_ "homeStyle" ] $ "Infinite Journeys Exclusives"
                                div_ [ class_ "moreAboutSectionTours" ] $ p_ "Check out our exclusive ititneraries designed for the avid traveller."
                            div_ [ class_ "nine columns" ] $ div_ [ class_ "card vCardOne" ] $ do
                                div_ [ class_ "threeBtns" ] $ a_ [ class_ "seeAll", href_ "http://www.infinitejourneys.in/ij/see-all?id=3&category=Infinite Journeys Exclusives" ] $ "See All"
                                ul_ [ class_ "vCardSlide" ] $ do
                                    li_ [ class_ "boxImages" ] $ a_ [ href_ "http://www.infinitejourneys.in/tour/kumaon-delight-35", title_ "Kumaon Delight" ] $ do
                                        div_ [ class_ "shadowBox" ] $ img_ [ src_ "http://www.infinitejourneys.in/uploads/gallery/infinite/220x190/binsar_10_1435582126.jpg", align_ "absmiddle", alt_ "binsar_10_1435582126.jpg" ]
                                        div_ [ class_ "hideContent" ] $ do
                                            div_ [ class_ "countriName" ] $ do
                                                p_ "Kumaon Delight"
                                                toHtmlRaw  "<!-- <p>Kumaon Delight</p> -->"
                                                h6_ [ class_ "font" ] $ "8 Days/7 Nights"
                                            div_ [ class_ "countriAdven" ] $ toHtmlRaw  "<!-- <p>8 Days/7 Nights</p> -->"
                                            div_ [ class_ "countriAdven" ] $ do
                                                p_ [ class_ "familyClass" ] $ "Classic, Family, Honeymoon, Off-the-track"
                                                toHtmlRaw  "<!--   <p class=\"familyClass\">Classic,...</p> -->"
                                        div_ [ class_ "hoverDiv" ] $ do
                                            div_ [ class_ "botHoverDiv" ] $ a_ [ href_ "http://www.infinitejourneys.in/tour/kumaon-delight-35", title_ "Kumaon Delight" ] $ do
                                                p_ "Delhi - Ramnagar - Dhikala - Ranikhet - Binsar - Jageshwar - Gethia."
                                                toHtmlRaw  "<!--                                               Destinations :  Delhi -&nbsp;Ramnagar - Dhika +\n                                         -->"
                                            div_ [ class_ "clear" ] $ ""
                                    li_ [ class_ "boxImages" ] $ a_ [ href_ "http://www.infinitejourneys.in/tour/himachal-off-the-beaten-track", title_ "Himachal - Off The Beaten Track" ] $ do
                                        div_ [ class_ "shadowBox" ] $ img_ [ src_ "http://www.infinitejourneys.in/uploads/gallery/infinite/220x190/Himachal_861_1405325441.jpg", align_ "absmiddle", alt_ "Himachal_861_1405325441.jpg" ]
                                        div_ [ class_ "hideContent" ] $ do
                                            div_ [ class_ "countriName" ] $ do
                                                p_ "Himachal - Off The Beaten Track"
                                                toHtmlRaw  "<!-- <p>Himachal - Off The Beaten Track</p> -->"
                                                h6_ [ class_ "font" ] $ "10 Days/9 Nights"
                                            div_ [ class_ "countriAdven" ] $ toHtmlRaw  "<!-- <p>10 Days/9 Nights</p> -->"
                                            div_ [ class_ "countriAdven" ] $ do
                                                p_ [ class_ "familyClass" ] $ "Family, Off-the-track, Special Interest"
                                                toHtmlRaw  "<!--   <p class=\"familyClass\">Family,...</p> -->"
                                        div_ [ class_ "hoverDiv" ] $ do
                                            div_ [ class_ "botHoverDiv" ] $ a_ [ href_ "http://www.infinitejourneys.in/tour/himachal-off-the-beaten-track", title_ "Himachal - Off The Beaten Track" ] $ do
                                                p_ "Thanedar / Narkanda, Sangla, Kalpa, Kaza, Manali "
                                                toHtmlRaw  "<!--                                               Destinations :  Thanedar / Narkanda, Sangla,  +\n                                         -->"
                                            div_ [ class_ "clear" ] $ ""
                                    li_ [ class_ "boxImages" ] $ a_ [ href_ "http://www.infinitejourneys.in/tour/himachal-tribal-circuit", title_ "Himachal Tribal Circuit" ] $ do
                                        div_ [ class_ "shadowBox" ] $ img_ [ src_ "http://www.infinitejourneys.in/uploads/gallery/infinite/220x190/hotel_lawn_hp45_1405323394.JPG", align_ "absmiddle", alt_ "hotel_lawn_hp45_1405323394.JPG" ]
                                        div_ [ class_ "hideContent" ] $ do
                                            div_ [ class_ "countriName" ] $ do
                                                p_ "Himachal Tribal Circuit"
                                                toHtmlRaw  "<!-- <p>Himachal Tribal Circuit</p> -->"
                                                h6_ [ class_ "font" ] $ "9 Days/8 Nights"
                                            div_ [ class_ "countriAdven" ] $ toHtmlRaw  "<!-- <p>9 Days/8 Nights</p> -->"
                                            div_ [ class_ "countriAdven" ] $ do
                                                p_ [ class_ "familyClass" ] $ "Family, Off-the-track, Special Interest"
                                                toHtmlRaw  "<!--   <p class=\"familyClass\">Family,...</p> -->"
                                        div_ [ class_ "hoverDiv" ] $ do
                                            div_ [ class_ "botHoverDiv" ] $ a_ [ href_ "http://www.infinitejourneys.in/tour/himachal-tribal-circuit", title_ "Himachal Tribal Circuit" ] $ do
                                                p_ "Thanedar / Narkanda, Sangla, Kaza, Kalpa "
                                                toHtmlRaw  "<!--                                               Destinations :  Thanedar / Narkanda, Sangla,  +\n                                         -->"
                                            div_ [ class_ "clear" ] $ ""
                                    li_ [ class_ "boxImages" ] $ a_ [ href_ "http://www.infinitejourneys.in/tour/offbeat-himachal-34", title_ "Offbeat Himachal" ] $ do
                                        div_ [ class_ "shadowBox" ] $ img_ [ src_ "http://www.infinitejourneys.in/uploads/gallery/infinite/220x190/View_from_Sojha_hp42_1405166058.JPG", align_ "absmiddle", alt_ "View_from_Sojha_hp42_1405166058.JPG" ]
                                        div_ [ class_ "hideContent" ] $ do
                                            div_ [ class_ "countriName" ] $ do
                                                p_ "Offbeat Himachal"
                                                toHtmlRaw  "<!-- <p>Offbeat Himachal</p> -->"
                                                h6_ [ class_ "font" ] $ "9 Days/8 Nights"
                                            div_ [ class_ "countriAdven" ] $ toHtmlRaw  "<!-- <p>9 Days/8 Nights</p> -->"
                                            div_ [ class_ "countriAdven" ] $ do
                                                p_ [ class_ "familyClass" ] $ "Family, Off-the-track, Special Interest"
                                                toHtmlRaw  "<!--   <p class=\"familyClass\">Family,...</p> -->"
                                        div_ [ class_ "hoverDiv" ] $ do
                                            div_ [ class_ "botHoverDiv" ] $ a_ [ href_ "http://www.infinitejourneys.in/tour/offbeat-himachal-34", title_ "Offbeat Himachal" ] $ do
                                                p_ "Thanedar, Sangla, Sojha, Chandigarh"
                                                toHtmlRaw  "<!--                                               Destinations :  Thanedar, Sangla, Sojha, Chan +\n                                         -->"
                                            div_ [ class_ "clear" ] $ ""
                                    li_ [ class_ "boxImages" ] $ a_ [ href_ "http://www.infinitejourneys.in/tour/himachal-delights-34", title_ "Himachal Delights" ] $ do
                                        div_ [ class_ "shadowBox" ] $ img_ [ src_ "http://www.infinitejourneys.in/uploads/gallery/infinite/220x190/hp41_1405151765.JPG", align_ "absmiddle", alt_ "hp41_1405151765.JPG" ]
                                        div_ [ class_ "hideContent" ] $ do
                                            div_ [ class_ "countriName" ] $ do
                                                p_ "Himachal Delights"
                                                toHtmlRaw  "<!-- <p>Himachal Delights</p> -->"
                                                h6_ [ class_ "font" ] $ "9 Days/8 Nights"
                                            div_ [ class_ "countriAdven" ] $ toHtmlRaw  "<!-- <p>9 Days/8 Nights</p> -->"
                                            div_ [ class_ "countriAdven" ] $ do
                                                p_ [ class_ "familyClass" ] $ "Family, Off-the-track, Special Interest"
                                                toHtmlRaw  "<!--   <p class=\"familyClass\">Family,...</p> -->"
                                        div_ [ class_ "hoverDiv" ] $ do
                                            div_ [ class_ "botHoverDiv" ] $ a_ [ href_ "http://www.infinitejourneys.in/tour/himachal-delights-34", title_ "Himachal Delights" ] $ do
                                                p_ "Thanedar, Sojha, Manali, Chandigarh "
                                                toHtmlRaw  "<!--                                               Destinations :  Thanedar, Sojha, Manali, Chan +\n                                         -->"
                                            div_ [ class_ "clear" ] $ ""
                                    li_ [ class_ "boxImages" ] $ a_ [ href_ "http://www.infinitejourneys.in/tour/himalayan-odyssey", title_ "Himalayan Odyssey" ] $ do
                                        div_ [ class_ "shadowBox" ] $ img_ [ src_ "http://www.infinitejourneys.in/uploads/gallery/infinite/220x190/Dhaulagiri_from_Poon_Hill_1404990391.jpg", align_ "absmiddle", alt_ "Dhaulagiri_from_Poon_Hill_1404990391.jpg" ]
                                        div_ [ class_ "hideContent" ] $ do
                                            div_ [ class_ "countriName" ] $ do
                                                p_ "Himalayan Odyssey"
                                                toHtmlRaw  "<!-- <p>Himalayan Odyssey</p> -->"
                                                h6_ [ class_ "font" ] $ "9 Days/8 Nights"
                                            div_ [ class_ "countriAdven" ] $ toHtmlRaw  "<!-- <p>9 Days/8 Nights</p> -->"
                                            div_ [ class_ "countriAdven" ] $ do
                                                p_ [ class_ "familyClass" ] $ "Off-the-track, Special Interest"
                                                toHtmlRaw  "<!--   <p class=\"familyClass\">Off-the-track...</p> -->"
                                        div_ [ class_ "hoverDiv" ] $ do
                                            div_ [ class_ "botHoverDiv" ] $ a_ [ href_ "http://www.infinitejourneys.in/tour/himalayan-odyssey", title_ "Himalayan Odyssey" ] $ do
                                                p_ "Kathmandu, Pokhara, Trek Route - Nayapul, Thikedhunga, Ghorepani, Poon Hill, Tadapani, Ghandrunk"
                                                toHtmlRaw  "<!--                                               Destinations :  Kathmandu, Pokhara, Trek Rout +\n                                         -->"
                                            div_ [ class_ "clear" ] $ ""
                                    li_ [ class_ "boxImages" ] $ a_ [ href_ "http://www.infinitejourneys.in/tour/best-of-kenya", title_ "Best of Kenya" ] $ do
                                        div_ [ class_ "shadowBox" ] $ img_ [ src_ "http://www.infinitejourneys.in/uploads/gallery/infinite/220x190/migration_1404904165.jpg", align_ "absmiddle", alt_ "migration_1404904165.jpg" ]
                                        div_ [ class_ "hideContent" ] $ do
                                            div_ [ class_ "countriName" ] $ do
                                                p_ "Best of Kenya"
                                                toHtmlRaw  "<!-- <p>Best of Kenya</p> -->"
                                                h6_ [ class_ "font" ] $ "8 Days/7 Nights"
                                            div_ [ class_ "countriAdven" ] $ toHtmlRaw  "<!-- <p>8 Days/7 Nights</p> -->"
                                            div_ [ class_ "countriAdven" ] $ do
                                                p_ [ class_ "familyClass" ] $ "Off-the-track, Special Interest"
                                                toHtmlRaw  "<!--   <p class=\"familyClass\">Off-the-track...</p> -->"
                                        div_ [ class_ "hoverDiv" ] $ do
                                            div_ [ class_ "botHoverDiv" ] $ a_ [ href_ "http://www.infinitejourneys.in/tour/best-of-kenya", title_ "Best of Kenya" ] $ do
                                                p_ "Lake Nakuru, Masai Mara, Nairobi, Samburu"
                                                toHtmlRaw  "<!--                                               Destinations :  Lake Nakuru, Masai Mara, Nair +\n                                         -->"
                                            div_ [ class_ "clear" ] $ ""
                                    li_ [ class_ "boxImages" ] $ a_ [ href_ "http://www.infinitejourneys.in/tour/offbeat-ladakh", title_ "Offbeat Ladakh" ] $ do
                                        div_ [ class_ "shadowBox" ] $ img_ [ src_ "http://www.infinitejourneys.in/uploads/gallery/infinite/220x190/ladakh_1404481413.jpg", align_ "absmiddle", alt_ "ladakh_1404481413.jpg" ]
                                        div_ [ class_ "hideContent" ] $ do
                                            div_ [ class_ "countriName" ] $ do
                                                p_ "Offbeat Ladakh"
                                                toHtmlRaw  "<!-- <p>Offbeat Ladakh</p> -->"
                                                h6_ [ class_ "font" ] $ "9 Days/8 Nights"
                                            div_ [ class_ "countriAdven" ] $ toHtmlRaw  "<!-- <p>9 Days/8 Nights</p> -->"
                                            div_ [ class_ "countriAdven" ] $ do
                                                p_ [ class_ "familyClass" ] $ "Off-the-track, Special Interest"
                                                toHtmlRaw  "<!--   <p class=\"familyClass\">Off-the-track...</p> -->"
                                        div_ [ class_ "hoverDiv" ] $ do
                                            div_ [ class_ "botHoverDiv" ] $ a_ [ href_ "http://www.infinitejourneys.in/tour/offbeat-ladakh", title_ "Offbeat Ladakh" ] $ do
                                                p_ "Leh, Hemis, Saspol, Nubra, Tiksey "
                                                toHtmlRaw  "<!--                                               Destinations :  Leh, Hemis, Saspol, Nubra, Ti +\n                                         -->"
                                            div_ [ class_ "clear" ] $ ""
                                    li_ [ class_ "boxImages" ] $ a_ [ href_ "http://www.infinitejourneys.in/tour/satpura-retreat-31", title_ "Satpura Retreat" ] $ do
                                        div_ [ class_ "shadowBox" ] $ img_ [ src_ "http://www.infinitejourneys.in/uploads/gallery/infinite/220x190/MPT1_225__Large__1420609011.jpg", align_ "absmiddle", alt_ "MPT1_225__Large__1420609011.jpg" ]
                                        div_ [ class_ "hideContent" ] $ do
                                            div_ [ class_ "countriName" ] $ do
                                                p_ "Satpura Retreat"
                                                toHtmlRaw  "<!-- <p>Satpura Retreat</p> -->"
                                                h6_ [ class_ "font" ] $ "6 Days/5 Nights"
                                            div_ [ class_ "countriAdven" ] $ toHtmlRaw  "<!-- <p>6 Days/5 Nights</p> -->"
                                            div_ [ class_ "countriAdven" ] $ do
                                                p_ [ class_ "familyClass" ] $ "Family, Off-the-track, Special Interest"
                                                toHtmlRaw  "<!--   <p class=\"familyClass\">Family,...</p> -->"
                                        div_ [ class_ "hoverDiv" ] $ do
                                            div_ [ class_ "botHoverDiv" ] $ a_ [ href_ "http://www.infinitejourneys.in/tour/satpura-retreat-31", title_ "Satpura Retreat" ] $ do
                                                p_ "Pachmarhi, Satpura National Park "
                                                toHtmlRaw  "<!--                                               Destinations :  Pachmarhi, Satpura National P +\n                                         -->"
                                            div_ [ class_ "clear" ] $ ""
                                    div_ [ class_ "clear" ] $ ""
                            div_ [ class_ "twelve columns divider" ] $ ""
                        footer_ $ do
                            section_ [ class_ "footTop" ] $ div_ [ class_ "container" ] $ do
                                div_ [ class_ "two columns coll" ] $ do
                                    ul_ $ do
                                        h5_ "Foliage Outdoors"
                                        li_ $ a_ [ href_ "http://www.infinitejourneys.in/fo/theme/-kids-camp-8-10-yrs?id=NjQ=", title_ " Kids Camp (8-10 yrs)" ] $ " Kids Camp (8-10 yrs)"
                                        li_ $ a_ [ href_ "http://www.infinitejourneys.in/fo/theme/international-tours-?id=NTY=", title_ "International Tours " ] $ "International Tours "
                                        li_ $ a_ [ href_ "http://www.infinitejourneys.in/fo/theme/kids-camp-10-12-yrs?id=NTE=", title_ "Kids Camp (10-12 yrs)" ] $ "Kids Camp (10-12 yrs)"
                                        li_ $ a_ [ href_ "http://www.infinitejourneys.in/fo/theme/mns-school?id=NTQ=", title_ "MNS School" ] $ "MNS School"
                                        li_ $ a_ [ href_ "http://www.infinitejourneys.in/fo/theme/open-age-backpacking-tours?id=NjU=", title_ "Open Age : Backpacking Tours" ] $ "Open Age : Backpacking Tours"
                                        li_ $ a_ [ href_ "http://www.infinitejourneys.in/fo/theme/open-age-special-tours?id=NTI=", title_ "Open Age : Special Tours" ] $ "Open Age : Special Tours"
                                        li_ $ a_ [ href_ "http://www.infinitejourneys.in/fo/theme/open-age-treks-leisure-treks?id=NjA=", title_ "Open Age : Treks & Leisure Treks" ] $ "Open Age : Treks & Leisure Treks"
                                        li_ $ a_ [ href_ "http://www.infinitejourneys.in/fo/theme/open-age--wildlife-tours?id=NTM=", title_ "Open Age : Wildlife Tours" ] $ "Open Age : Wildlife Tours"
                                        li_ $ a_ [ href_ "http://www.infinitejourneys.in/fo/theme/students--adventure-camp--treks?id=MTc=", title_ "Students : Adventure Camp & Treks" ] $ "Students : Adventure Camp & Treks"
                                        li_ $ a_ [ href_ "http://www.infinitejourneys.in/fo/theme/students--wildlife-camps?id=MTY=", title_ "Students : Wildlife Camps" ] $ "Students : Wildlife Camps"
                                        li_ $ a_ [ href_ "http://www.infinitejourneys.in/fo/theme/upcoming-tours?id=NTg=", title_ "Upcoming Tours" ] $ "Upcoming Tours"
                                        li_ $ a_ [ href_ "http://www.infinitejourneys.in/fo/theme/youth-camps-14-to-22-years?id=NTk=", title_ "Youth Camps (14 to 22 years)" ] $ "Youth Camps (14 to 22 years)"
                                        toHtmlRaw  "<!-- <li><a href=\"http://www.infinitejourneys.in/fo/see-all?id=1&category=upcoming_tours\" title=\"Upcoming Tours\">Upcoming Tours</a></li>\n                <li><a href=\"http://www.infinitejourneys.in/fo/see-all?id=2&category=top_picks_country&country=India\" title=\"Top Picks India\">Top Picks India</a></li>\n                <li><a href=\"http://www.infinitejourneys.in/fo/see-all?id=3&category=foliage_outdoors_exclusive\" title=\"Foliage Outdoors Exclusive\">Foliage Outdoors Exclusive</a></li> -->"
                                        toHtmlRaw  "<!-- <li><h6><a href=\"javascript:void(0);\" class=\"payUpolicy\" title=\"Terms and Conditions\">Terms and Conditions</a></h6></li> -->"
                                    div_ [ class_ "vDivider" ] $ ""
                                div_ [ class_ "two columns coll" ] $ do
                                    ul_ $ do
                                        h5_ "Infinite Journeys"
                                        li_ $ a_ [ href_ "http://www.infinitejourneys.in/ij/theme/classic?id=MzE=", title_ "Classic" ] $ "Classic"
                                        li_ $ a_ [ href_ "http://www.infinitejourneys.in/ij/theme/family?id=MjY=", title_ "Family" ] $ "Family"
                                        li_ $ a_ [ href_ "http://www.infinitejourneys.in/ij/theme/honeymoon?id=Mjc=", title_ "Honeymoon" ] $ "Honeymoon"
                                        li_ $ a_ [ href_ "http://www.infinitejourneys.in/ij/theme/off-the-track?id=Mjk=", title_ "Off-the-track" ] $ "Off-the-track"
                                        li_ $ a_ [ href_ "http://www.infinitejourneys.in/ij/theme/special-interest?id=MzI=", title_ "Special Interest" ] $ "Special Interest"
                                        li_ $ a_ [ href_ "http://www.infinitejourneys.in/ij/see-all?id=1&category=top_picks_country&country=India", title_ "Top Picks India" ] $ "Top Picks India"
                                        li_ $ a_ [ href_ "http://www.infinitejourneys.in/ij/see-all?id=2&category=top_picks_international", title_ "Top Picks International" ] $ "Top Picks International"
                                        li_ $ a_ [ href_ "http://www.infinitejourneys.in/ij/see-all?id=3&category=infinite_journeys_exclusives", title_ "Infinite Journeys Exclusives" ] $ "Infinite Journeys Exclusives"
                                        li_ $ h6_ $ a_ [ href_ "http://www.infinitejourneys.in/europe-tour-packages/", title_ "Europe Tour Packages" ] $ "Europe Tour Packages"
                                    div_ [ class_ "vDivider" ] $ ""
                                div_ [ class_ "three columns contactColl coll" ] $ do
                                    h5_ "Contact"
                                    p_ [ title_ "Phone: +91 - 20 - 66447777" ] $ do
                                        span_ "Phone:"
                                        strong_ "+91 - 20 - 66447777"
                                    p_ [ title_ "Email: web@infinitejourneys.in" ] $ do
                                        span_ "Email:"
                                        a_ [ href_ "mailto:web@infinitejourneys.in", style_ "text-decoration: none;" ] $ strong_ "web@infinitejourneys.in"
                                    p_ [ title_ "Address: 103, Mahadkar Chambers, Karve Road, Near Kothrud McDonalds, Kothrud, Pune 411038.." ] $ do
                                        span_ "Address:"
                                        strong_ "Main Office"
                                        strong_ $ p_ "103, Mahadkar Chambers, Karve Road, Near Kothrud McDonalds, Kothrud, Pune 411038.."
                                    br_ []
                                    p_ $ do
                                        span_ "Address:"
                                        strong_ "Aundh Branch"
                                    p_ $ strong_ "Plot Number : A-1 (AB) Second Floor, Abhimanshree Society, Above Hotel Abhiman, Near B U Bhandari Showroom, Opp St Joseph  School NCL - Pashan Road, Aundh, Pune 411008."
                                div_ [ class_ "one columns coll" ] $ div_ [ class_ "vDivider" ] $ ""
                                div_ [ class_ " four columns coll logocoll" ] $ do
                                    h5_ "Member of"
                                    img_ [ class_ "logo1", src_ "http://www.infinitejourneys.in/templates/default/images/illustration/tafi.png", alt_ "TAFI" ]
                                    img_ [ class_ "logo2", src_ "http://www.infinitejourneys.in/templates/default/images/illustration/iaai.png", alt_ "IAAI" ]
                                    img_ [ class_ "logo3", src_ "http://www.infinitejourneys.in/templates/default/images/illustration/etaa.png", alt_ "ETAA" ]
                                    img_ [ class_ "logo4", src_ "http://www.infinitejourneys.in/templates/default/images/illustration/taap.png", alt_ "TAAP" ]
                                    img_ [ class_ "logo5", src_ "http://www.infinitejourneys.in/templates/default/images/illustration/adtoi.png", alt_ "ADTOI" ]
                                    img_ [ class_ "logo6", src_ "http://www.infinitejourneys.in/templates/default/images/illustration/atom.png", alt_ "ATOM" ]
                                    img_ [ class_ "logo7", src_ "http://www.infinitejourneys.in/templates/default/images/illustration/advIndia.png", alt_ "Adventure Tour Operators Association of India" ]
                                    h4_ "recognised by"
                                    img_ [ class_ "logo8", src_ "http://www.infinitejourneys.in/templates/default/images/illustration/govInd.png", alt_ "Ministry of Tourism Government of India" ]
                                    img_ [ class_ "logo9", src_ "http://www.infinitejourneys.in/templates/default/images/illustration/imfo.png", alt_ "Recognizes by India Mountaineering Foundation" ]
                            section_ [ class_ "footBot" ] $ div_ [ class_ "container" ] $ do
                                div_ [ class_ "five columns" ] $ do
                                    toHtmlRaw  "<!-- <ul class=\"social\">\n            \t<a href=\"https://www.facebook.com/InfiniteJourneysIndia\" target=\"_blank\" title=\"Facebook\"><li class=\"fb\"></li></a>\n                <a href=\"https://twitter.com/foliageoutdoors\" title=\"Twitter\"><li class=\"tw\"></li></a>\n                <a href=\"javascript:void(0);\" title=\"Google Plus\"><li class=\"gPlus\"></li></a>\n                <a href=\"https://www.youtube.com/user/foliageoutdoors\" title=\"You Tube\"><li class=\"yTube\"></li></a>\n            </ul> -->"
                                    ul_ [ class_ "social" ] $ do
                                        a_ [ href_ "javascript:void(0);", title_ "Facebook", class_ "socialPopUp", id_ "socialFb" ] $ li_ [ class_ "fb" ] $ ""
                                        toHtmlRaw  "<!-- <a href=\"javascript:void(0);\" title=\"Twitter\" class=\"socialPopUp\" id=\"socialTw\"><li class=\"tw\"></li></a> -->"
                                        a_ [ href_ "https://twitter.com/foliageoutdoors", target_ "_blank", title_ "Twitter" ] $ li_ [ class_ "tw" ] $ ""
                                        toHtmlRaw  "<!-- <a href=\"javascript:void(0);\" title=\"Google Plus\" class=\"socialPopUp\" id=\"socialGplus\"><li class=\"gPlus\"></li></a> -->"
                                        a_ [ href_ "https://plus.google.com/+foliageoutdoors/about", target_ "_blank", title_ "Google Plus" ] $ li_ [ class_ "gPlus" ] $ ""
                                        a_ [ href_ "https://www.youtube.com/user/foliageoutdoors", target_ "_blank", title_ "You Tube" ] $ li_ [ class_ "yTube" ] $ ""
                                        a_ [ href_ "javascript:void(0);", title_ "Instagram", class_ "socialPopUp", id_ "socialInsta" ] $ li_ [ class_ "instagram" ] $ ""
                                div_ [ class_ "three columns" ] $ ""
                                div_ [ class_ "twelve columns footCopy" ] $ do
                                    p_ [ class_ "pullLeft" ] $ do
                                        "Copyright © "
                                        span_ [ id_ "year" ] $ ""
                                        a_ [ href_ "http://www.infinitejourneys.in/infinite-journeys/" ] $ span_ [ class_ "orange", title_ "Infinite Journeys" ] $ "Infinite Journeys."
                                        " &\n            "
                                        a_ [ href_ "http://www.infinitejourneys.in/foliage-outdoors/" ] $ span_ [ class_ "green", title_ "Foliage Outdoors" ] $ "Foliage Outdoors."
                                        " All Rights Reserved.\n            "
                                    p_ [ class_ "pullRight" ] $ do
                                        "Powered By : "
                                        a_ [ href_ "http://www.gobiggi.com/", target_ "_blank", class_ "orange", title_ "Gobiggi LLC." ] $ "Gobiggi LLC."
                        nav_ [ id_ "menu" ] $ ul_ $ do
                            li_ $ a_ [ href_ "http://www.infinitejourneys.in" ] $ "Home"
                            toHtmlRaw  "<!--<li class=\"Selected\">-->"
                            li_ $ do
                                a_ [ href_ "http://www.infinitejourneys.in/about-us/" ] $ "About Us"
                                ul_ $ do
                                    li_ $ a_ [ href_ "http://www.infinitejourneys.in/about-us/#horizontalTab1" ] $ "Our Story"
                                    li_ $ a_ [ href_ "http://www.infinitejourneys.in/about-us/#horizontalTab2" ] $ "Our Vision & Values"
                                    li_ $ a_ [ href_ "http://www.infinitejourneys.in/about-us/#horizontalTab3" ] $ "Why Us?"
                                    li_ $ a_ [ href_ "http://www.infinitejourneys.in/about-us/#horizontalTab4" ] $ "Our People"
                            li_ $ do
                                a_ [ href_ "javacript:void(0);" ] $ " Our Services"
                                ul_ $ do
                                    li_ $ a_ [ href_ "http://www.infinitejourneys.in/infinite-journeys/" ] $ "Infinite Journeys"
                                    li_ $ a_ [ href_ "http://www.infinitejourneys.in/foliage-outdoors/" ] $ "Foliage Outdoors"
                                    li_ $ a_ [ href_ "http://www.infinitejourneys.in/school-tours/" ] $ "School Tours"
                                    li_ $ a_ [ href_ "http://www.infinitejourneys.in/corporate-tours/" ] $ "Corporate Tours"
                            li_ $ a_ [ href_ "http://www.infinitejourneys.in/gallery/" ] $ "Gallery"
                            li_ $ a_ [ href_ "http://www.infinitejourneys.in/testimonials/" ] $ " Testimonials"
                            li_ $ do
                                a_ [ href_ "http://infinitejourneys.in/blog/" ] $ "Announcements"
                                toHtmlRaw  "<!-- <ul>\n                            <li><a href=\"javacript:void(0);\">Blogs</a></li>\n                            <li><a href=\"javacript:void(0);\">Forums</a></li>\n\t\t\t\t\t\t</ul> -->"
                            li_ $ a_ [ href_ "http://www.infinitejourneys.in/fo/sms-alerts" ] $ "Live SMS Updates"
                            li_ $ a_ [ href_ "http://www.infinitejourneys.in/contact-us/" ] $ "Contact Us"
                a_ [ href_ "javascript:void(0);", class_ "scrollup" ] $ " Scroll "
            div_ [ class_ "bar" ] $ ""
            style_ [ type_ "text/css" ] $ "\n    .rulesContent p{\n        padding: 10px;\n    }\n"
            div_ [ id_ "payUpolicy", class_ "simplePopup" ] $ div_ [ class_ "rulesContent" ] $ do
                h4_ "TERMS OF USE"
                p_ "The website www.infinitejourneys.in is owned by Infinite Journeys Pvt. Ltd..\n            All bookings here are made with Rnfinite Journeys Pvt. Ltd and the booking terms mentioned herein\n            below constitutes the entire agreement between the customer and Company. By making a booking\n            with us and/or depositing payments with us for tour and travel services you confirm having carefully\n            read, understood and accepted the below mentioned ‘Terms of Services’."
                h5_ $ strong_ "1. BOOKINGS"
                p_ "Visitors on our website are kindly requested to fill the Enquiry Form with all necessary fields\n            mentioned there and submit the same to be sent to our office. Upon receipt of the booking request or\n            travel enquiry a travel expert from our office will get in touch with you with the best available\n            information and offers for the desired tour package or travel services. In the event the travel\n            requirements are not clear in the booking form submitted by you to us, our team may contact you via\n            email or phone no. provided by you in the booking form. No booking is considered as ‘confirmed’\n            unless a tour confirmation letter is sent by us to the customer after receiving the initial advance\n            payments in our account."
                h5_ $ strong_ "2. PAYMENTS"
                h6_ [ style_ "margin-top: 20px;" ] $ strong_ "I). Deposit"
                p_ "Our tours are subject to availability. To make reservation for a tour with us, the customer requires\n        depositing advance payments as may be conveyed by our travel consultant during the course of\n        correspondence. No booking is treated ‘confirmed’ unless a confirmation letter is received by the\n        traveller from our office after depositing the advance payments for the trip."
                h6_ $ strong_ "II). Balance Payments"
                p_ "It is the sole responsibility of the customer to make the balance payments at least 90 days prior to\n        the start of the tour or as may be agreed / conveyed by our travel consultant during the course of\n        correspondence. In the event of non-receipt of balance payment by the cut-off date, the Company\n        will retain the right to treat the tour bookings as cancelled and the advance payment may be\n        forfeited."
                h6_ $ strong_ "III). How to pay for your travel bookings"
                p_ "To reserve tour package or travel services with us upon demand from our office our customers may\n        deposit the payments in our Yes Bank Ltd. account under intimation to our office. The bank account\n        information may be received from our office via email or phone. Our customers may also avail the\n        benefits of paying by their credit cards (Visa or MasterCard) using our ‘Secure Online Payment\n        Gateway’. For more information on security of your private information please read our ‘Privacy\n        Policy’."
                h6_ $ strong_ "A) Swift Bank Payments"
                p_ "Our customers may send the payments to us using our SWIFT bank account information. This is the\n        responsibility of the sender to provide us with a copy of the telegraphic transfer report (Bank\n        document) for necessary check and follow ups with our local bank in India. While paying the\n        deposits via SWIFT for the tour bookings kindly ensure that you have filled all correct information in\n        the payment form and have also paid the intermediary bank fee which is normally US$35 approx for\n        each payment. We will only credit in your tour account the amount which we receive in our bank and\n        we take no responsibility of intermediary bank fee/charges."
                h6_ $ strong_ "B) NEFT/RTGS"
                p_ "The customers may also pay through NEFT/RTGS for the bookings made with us. Please forward us\n        a copy of the NEFT/RTGS payment advice made by you. Upon receipt of the payments in the bank,\n        our travel consultant will confirm the same to you via phone or email."
                h6_ $ strong_ "C) Cheque / Bankers Cheque"
                p_ "The customer residing in India may deposit a local cheque / draft in our bank account (please ask for\n        the bank details from our office). A copy of deposit slip duly stamped by the bank may kindly be sent\n        to our office for our records. The receipt of the payment slip will not be considered as ‘receipt’ of the\n        payment. The payment will be considered as ‘received’ only once the same has arrived and settled\n        in our bank account. The booking confirmation process will effect accordingly therefore the\n        customers are advised to deposit the cheque payments well in advance to avoid inconvenience."
                h6_ $ strong_ "D) Cash payments"
                p_ "Our customers residing in India can also deposit advance payments in ‘cash’ in our bank account. A\n        copy of the payment deposit slip may kindly be sent to our office for their follow up and records. Our\n        office issues a ‘Cash Receipt’ against all cash payments received by us and it is the responsibility\n        and right of the customer to ask for a ‘customer copy’ of such receipt after the payment is settled in\n        our account."
                h6_ $ strong_ "E) Credit Card Payments"
                p_ "Our worldwide customers can avail the benefits of our ‘100% secure’ online credit card payment\n        gateway (Visa and MasterCard) managed by Pay u. We accept payments in US$, GBP, Euro, YEN,\n        INR and other renowned international currencies. It is advisable and requested to our customers\n        residing outside India to make the payments in US$, GBP, Euro, YEN or their local currency (if listed\n        in our payment gateway). Please note that the online payments attract online bank fee/charges of\n        3% (it may vary case to case) and the same is payable by the credit card holder in addition to the\n        tour payments while making the transaction. For certain credit card payments, on the instruction of\n        the bank to ensure genuine card entry our office may ask the credit card holder to fill and sign the\n        ‘Credit Card Payment Authorisation Form’ and send the same to our office along with the identity\n        proof (passport copies etc) and/or front copy of the credit card. It is mandatory for the customer to\n        provide us with such details / document if demanded by our office. Credit card security code\n        (CVV/CV2 no. mentioned on the ‘back’ of the card) is case sensitive and not to be shared by the\n        card holder or filled in the authorisation form or written in email etc."
                h6_ $ strong_ "F) Invoice and Taxes"
                p_ "A service invoice is issued for all tour bookings which are usually inclusive of all applicable taxes\n        except the Govt of India Service Tax. It is not only the liability of the Company to charge Service Tax\n        to the customer but also the responsibility of the customer to pay the same without fail. All our\n        quotes and offers are ‘exclusive’ of GST until specified in the quote unless."
                h6_ $ strong_ "G) Money Exchange rates"
                p_ "The customers may refer to the Reserve Bank of India website www.rbi.org.in to check the current\n        exchange rate of major foreign currencies to INDIAN Rupees"
                h6_ $ strong_ "H) Late Bookings"
                p_ "We may need full or higher percentage of amount for ‘Late Bookings’. Kindly ask our travel\n        consultant at the time of making bookings with us. The payments received for such bookings are\n        ‘non-refundable’."
                h5_ $ strong_ "3. TRAVELLER’S INFORMATION"
                p_ [ style_ "margin-top: 20px;" ] $ "To make reservation and also for our file records our travel consultant retains the right to ask you for providing him/her with the copy of passport, personal details such as name, date of birth, gender, address, phone no., email etc., the customer is kindly requested to provide the same if and when asked."
                h5_ $ strong_ "4. WHAT IS INCLUDED IN PRICE"
                p_ [ style_ "margin-top: 20px;" ] $ "Most ‘tour packages’ offered by Round the World Vacations are inclusive of accommodation in\n        hotel/guest house/resorts, transportation in a private car (for private trips) or in a coach/bus (for\n        group tours), breakfast, services of local tour guides (where available) for visiting historic sites and\n        basic entertainments for the trip. The same may vary on case to case basis and is conveyed to the\n        customer by our travel consultants during the course of correspondence."
                h6_ $ strong_ "I) Accommodation"
                p_ "Our ‘independent tours’ includes accommodation in handpicked hotels selected by us based on the\n        market report and/or recommendation of our past travellers. Based on the demand of the customer\n        and type of requirements or budget mentioned by them, our travel consultants ensure to provide a\n        comfortable and clean hotel for stay (for independent trip) during the trip. Also for our guaranteed\n        departure ‘India group tours’ we have a select list of handpicked hotels and guest houses which may\n        also be changed if situation demands. In the event of non-availability of hotel/s listed by us in our\n        offer, our team retains the right to reserve another similar standard hotel for the travellers. All our\n        hotels are subject to availability. We request the travellers to check on the internet about the\n        standard of the hotels offered by us, before making the deposit for the trip."
                h6_ $ strong_ "II) Vehicles and drivers"
                p_ "We provide comfortable vehicle (bus/coach/car/jeep) in good condition with customer friendly\n        English speaking drivers (basic knowledge of English). Some of our tourist drivers are highly\n        recommended by the travellers and they are serving to international itinerants for many years now."
                h6_ $ strong_ "III) Tour Guides/Escorts"
                p_ "Most trips are inclusive of assisted airport/railway station transfers. For sightseeing trips, we use only\n        Govt of India licensed ‘Tourist Guides/Escorts’. Most of our tour packages are inclusive of services\n        of local English speaking tour guides at historic sites. Other than English we also have tourist guides\n        who are expert in more international languages such as German, Spanish, Italian, Russian,\n        Japanese, Turkish, Farsi, Chinese etc."
                h6_ $ strong_ "IV) Meals"
                p_ "Most trips are inclusive of hotel breakfasts. Some trips also include special lunches and theme\n        dinners etc. in the hotel of stay or outside in a city restaurants. Some of the tours are even inclusive\n        of all meals (jungle lodges and camps mainly) which is mentioned in the list of inclusions and/or will\n        be conveyed during the course of correspondence."
                h6_ $ strong_ "V) Others"
                p_ "Many of our tour packages also includes basic entertainments and activities such as traditional\n        rickshaw rides, decorated Elephant ride, Camel ride, Boat tickets, cultural events etc. Please check\n        with our travel consultant about this while making reservation with us. A list of some important ‘not to\n        be missed’ visits /rides etc can be viewed in ‘Unique Travel Experience’ section and can be included\n        in the trip on demand, at an additional cost."
                h5_ $ strong_ "5. NOT INCLUDED"
                p_ [ style_ "margin-top: 20px;" ] $ "Usually our tour packages does not include international air ticket price, domestic flight tickets, travel insurance, visa (please check updates on India’s new VOA - Visa on Arrival policy), tips, camera/video camera fee at monuments and museums etc, personal expenses such as drinks/laundry/telephone/mini bar bills etc and the same are payable by the travellers in addition to the package price. Our services also does not include any additional expense incurred due to any\n        unforeseen circumstances or situation such as riots, strikes, political closure, natural hazard, technical failure, flight or train cancelation and delay etc or any other reason/situation beyond our control."
                h5_ $ strong_ "6. FLUID PRICING"
                p_ [ style_ "margin-top: 20px;" ] $ "As per the common practice of the trade Round The World Vacations operates tours on fluid price\n        basis. The offers are subject to the limitations imposed by hotels, airlines and other service providers and the same may change without prior notice in case of hike in the air ticket price, tax structure, major fluctuation in currency exchange rate or any other reason. Round the World Vacations retains the right to change its price and offers without prior notice, if the case occurs. It may also cause different price charged to different clients travelling in the same group/period. It is totally at the\n        discretion of the Company to decide upon the same."
                h5_ $ strong_ "7. TRAVEL DOCUMENTS"
                p_ [ style_ "margin-top: 20px;" ] $ "Once you have booked and paid for the tour our operation team will issue and provide you with a\n        copy of travel documents for your trip. You are kindly requested to check the details mentioned in the travel documents and in case of any error found the same may please be reported to the our concerned travel consultant for further corrections. The original travel documents shall be sent to the traveller at the port of his/her arrival in India. The travel document kit also carries a Feedback Form with an envelope which may please be filled by the traveller and sent to our senior management for their reference and our office records."
                h5_ $ strong_ "8. HOTEL CHECK IN/OUT POLICY"
                p_ [ style_ "margin-top: 20px;" ] $ "In India most hotels now offer 12.00 hrs check out and 14.00 hrs check in system. All our trips are\n        based on the same policy of the hotels and the travellers are requested to adhere with the same.\n        Any early check-in or late check-out is absolutely at the discretion of the hotel management and\n        based on the availability of rooms at the specific day and time. We neither guarantee nor do we\n        accept the liability of providing early check-in or late check-out without additional charges. Our travel\n        consultant may only request the hotel to extend this gesture to the customer and as stated the same\n        will be the decision of the hotel only. For any early check-in or late check-out facility the travellers\n        may kindly write to our office."
                h5_ $ strong_ "9. AMENDMENT OR EXTENSION IN TRIP/STAY"
                p_ [ style_ "margin-top: 20px;" ] $ "If there is any amendment requested by the customer after finalizing the trip/travel bookings with our\n        office, the same may be subject to availability. For any amendment the customers are requested to\n        immediately contact our head office and share the details of amendments with respective travel\n        consultant in writing. Our team will try its best to make the desired amendments in the trip, but we\n        neither guarantee nor do we take the liability of confirmation / availability of the travel arrangements\n        as per the new date or schedule announced by the customer. Any additional expense incurred due\n        to the amendment shall be payable only by the customer."
                h5_ $ strong_ "10. CHANGE IN THE PRICE OF THE TRIP"
                p_ [ style_ "margin-top: 20px;" ] $ "All our tours are subject to availability and our price/deals are subject to change without prior notice. We retain the right to cancel/amend or withdraw any price/deal/offer without assigning prior notice.\n        Our ‘India Group Tours’ are based on minimum participants on each trip. In the event of non\n        fulfilment of minimum participants for the group, we shall guarantee the trip with minimum possible\n        supplement cost which will be announced to the traveller before the commencement of the trip."
                h5_ $ strong_ "11. EXCLUSION FROM THE TOUR"
                p_ [ style_ "margin-top: 20px;" ] $ "At any given time if the client engage himself/herself/themselves in illegal or undesirable behaviour,\n        do not comply with the reasonable instructions and policy of our trip and services or if he/she/they\n        jeopardise the safety of other clients, guides, drivers etc. they may be excluded from the trip\n        immediately at our discretion and will be entitled for possible refund of the unutilised services,\n        subject to the policy and decision of airline, hotels etc. The refund will not be immediate but will be\n        done as per the policy of the Company through reliable banking channels only."
                h5_ $ strong_ "12. UNUTILIZED SERVICES"
                p_ [ style_ "margin-top: 20px;" ] $ "Round the World Vacations, its staff, management, partners or representative do not bear the\n        responsibility or liability of making refund for any unutilised service/s. It is to be noted seriously that\n        after the start of the trip no refund is possible for whatsoever reason. In the event of agreement by\n        any airline, hotel etc for refund against any unutilised part of the service or item etc Round the World\n        Vacations shall take up the matter on the behalf of the customer and shall only offer its assistance to\n        the customer in receiving the same from the other party. Such refunds shall be sent only to the bank\n        account of the customer within 2-3 weeks after receiving the same from service provider/s."
                h5_ $ strong_ "13. SPECIAL SCHEMES, DISCOUNTS AND OFFERS"
                p_ [ style_ "margin-top: 20px;" ] $ "None of the two (or more) schemes/ offers / deals (including loyalty discount, last minute discount,\n        early bird discount etc) can be clubbed with each other or any other offer. All such schemes and\n        offers introduced by us are only promotional offers and the terms of the scheme/s can be changed\n        anytime thereafter without assigning any notice. We also retain the right to withdraw or modify the\n        offers/scheme anytime without notice. It is totally at our discretion to confirm or reject your booking\n        under such schemes. These offers and schemes are not applicable for travel during New year or\n        Christmas period, peak tourist season dates, festival dates, luxury train bookings etc. No discount or\n        offer will be applicable for the trips already booked with us under a normal price. The discounts does\n        not apply to air fares, train bookings, luxury train travels, permits, visa, travel insurance,\n        monument/museum tickets, extra meals and/or pre/post tour arrangements. It applies to the\n        bonafide customer only and not to other traveller on the same trip (unless they also hold the discount\n        ticket). While making the query with us, you clearly need to mention the details of our special offer\n        under which you wish to book the trip. Services and bookings for all schemes and offers are subject\n        to availability only."
                h4_ "CANCELLATION AND REFUND"
                p_ "All cancellations must be intimated to our head office on phone followed by a written confirmation via\n        email or fax. Telephonic cancellation will not be accepted as ‘cancelation request’. Cancellations for the\n        independent/individual tour services should be made with a notice of not less than 7-30 days (According\n        to Situation). The cancellation in case of group booking should be made at least 30 days prior to the date\n        of commencement of the trip. For Christmas, New Year, Diwali, Pushkar Fair and other important festivals\n        the normal cancelation policy does not apply and payments for against bookings during such busy period\n        are considered as non-refundable. Please check with our travel consultants at the time of booking for\n        such cancelation policy for special event tours."
                h5_ "Please view the information on cancelation policy and cancellation fee as below:"
                h5_ "In the event of less than 8 travellers:"
                p_ "I) If the booking is cancelled 10 days prior to the start of the trip Loss of deposit will be full."
                p_ "II)  If the booking is cancelled 20 days prior to the start of the trip 50% Loss of deposit"
                p_ "III) If the booking is cancelled 30 days prior to the start of the trip 70% Amount will refund"
                p_ "IV) If the booking is cancelled within 0 days prior to the start of the trip 100% Amount will refund"
                h5_ "In the event of more than 8 travellers:"
                p_ "I) If the booking is cancelled 10 days prior to the start of the trip Loss of deposit will be full. "
                p_ "II) If the booking is cancelled 20 days prior to the start of the trip 50% Loss of deposit"
                p_ "III) If the booking is cancelled 30 days prior to the start of the trip 70% Amount will refund"
                p_ "IV) If the booking is cancelled within 0 days prior to the start of the trip 100% Amount will refund"
                h5_ "Please Note:"
                p_ "I) Amount will be refunded through Electronic Transfer or by the card (Debit/Credit)."
                p_ "II) Refund of amount will initiate after deducting the applicable cancellation Charges and service charge\n        and both will be settled within 7 to 30 days of the day of cancellation request approved by Round The\n        World Vacation."
                p_ "III) Booking which is under no Cancellation/ No Refund, guest/client travelling or person/entity booked will\n        have to pay the service charge to Round The World Vacations."
                h4_ "PRIVACY POLICY"
                p_ $ do
                    "For us privacy for our valued customer is very important. We strongly believe that the personal\n        information of our customers should not be shared with the third party without the prior consent or\n        request from the customer. Privacy is the right of an individual and at nfinite Journeys Pvt. Ltd he\n        information of the customer such as contact no., email, addresses etc is used only for the internal\n        purpose and not for sale. "
                    br_ []
                    "\n        Your contact information is stored in our database and is only used to contact you during the course\n        of your travel with us for sharing the status of your travel bookings with us and then after for\n        announcement of our latest deals and news etc. We at Round the World Holidays condemn the\n        unauthorised reach and misuse and/or discloser of the personal information of the customer and we\n        have strict guidelines and high security features to prevent the same. "
                    br_ []
                    " \n        Any changes in our ‘Privacy Policy’ will be posted here on the website. Should the customer require\n        any further information on our ‘Privacy Policy’ please send us an email at\n        "
                    a_ [ href_ "mailto:info@foliageoutdoors.com" ] $ "info@foliageoutdoors.com"
                    " with ‘Privacy Policy’ written in the subject field. We will ensure reply to the reasonable queries at our earliest possible time."
                h5_ "DATA SECURITY INFORMATION"
                p_ "We have extensive firewall and high end security system to monitor the traffic and financial\n        transaction on our website/s. Any suspicious email, traffic on website and/or financial transaction will\n        be investigated to ensure there is no breach of policy and security. Our customer care executive or\n        other staff may contact you to verify the transaction made by you. The secure connection between\n        your browser and our system for financial transactions uses 128 bit Secure Sockets Layer (SSL)\n        encryption. This is a well-respected technology developed by Netscape, Microsoft and RSA Inc that\n        is supported by most browsers."
                h5_ "SECURE ONLINE PAYMENTS"
                p_ "The visitor on our website please take a note that your name, email address and other personal\n        information submitted on our website may be stored with us and may also appear on the website.\n        Like other platforms our server log files also receives general information such as IP address of the\n        visitor, cookie etc. For the financial transactions by credit card nfinite Journeys Pvt. Ltd uses a 3rd\n        party secure payment gateway provided by “Pay u” and the credit card details are ‘not stored’ with\n        Round the World Holidays, instead the information is securely stored and encrypted with\n        Visa/MasterCard. The ‘online credit card payment gateway’ provided by us for our customers is fully\n        PCI-DSS compliant and to transfer information between Round the World Holidays and credit card\n        bank we use a 128bit SSL certificate powered by Dialect . It simply means that when the customer\n        makes the transaction using our online payment gateway on our website, these details are being\n        securely stored within Dialect’s fully secure vaults to ensure your information cannot be used by\n        malicious 3rd parties. Round the World Holidays and/or its employees cannot view the credit card’s"
                h5_ "CHILDREN"
                p_ "We do not suggest and allow person/s below 18 year of age to become a member of our website\n        and other websites/social sites etc. By entering to our websites and using our services you confirm\n        and warrant that you are 18 or older."
                h5_ "NO GUARANTEES"
                p_ $ do
                    "Round the World Holidays India Pvt. Ltd. will make all possible efforts to meet with the policies\n        mentioned herein on the website, but we are not in a position to guarantee these standards as there\n        may be factors beyond our control. As a consequence, we disclaim any warranties or\n        representations relating to maintenance or nondisclosure of Data. "
                    br_ []
                    br_ []
                    "\n        Our ‘Privacy Policy’ does not cover or apply to the other entities that are not under our control or\n        owned by us and/or person/s that are not our employees within our control."
            script_ [ type_ "text/javascript", src_ "http://www.infinitejourneys.in/js/jquery.simplePopup.js" ] $ ""
            link_ [ rel_ "stylesheet", type_ "text/css", href_ "http://www.infinitejourneys.in/templates/default/css/popupstyle.css" ]
            script_ [ type_ "text/javascript" ] $ "\n$(document).ready(function(){\n   $('.payUpolicy').click(function(){\n     $('#payUpolicy').simplePopup({\n        centerPopup: true,\n     });\n   });\n});\n"
            style_ [ type_ "text/css" ] $ "\n    .popNewBx{\n        float: none;\n        width: 100%;\n        display: block;\n        text-align: center;\n        vertical-align: middle;\n        position: relative;\n        margin-top: 10%;\n        height: 100%;\n    }\n    .popNewInj{\n        border-right: 1px solid #ccc;\n        width: inherit;\n        padding: 0 15px;\n        margin: 0 15px 0 0;\n    }\n    .fb-icon a {\n        color:#E35E12;\n        font-size: 15px;\n        font-weight: 600;\n        margin: 13px 20px;\n        display: inline-block;\n    }\n    .fb-icon a i{\n        /*background-color: #E35E12;*/\n        /*background-position: 40px 41px;*/\n        /*background: url('http://www.infinitejourneys.in/templates/default/images/layout/socialNetwok.png');*/\n        /*color: #ffffff;*/\n        border-radius: 100%;\n        padding: 10px 13px;\n        font-size: 17px;\n        margin-right: 5px;\n    }\n\n    .fa-instagram{\n     width: 40px;\n    height: 40px;\n    background: #999;\n    float: left;\n    margin: 0 10px 0 0;\n    background: url('http://www.infinitejourneys.in/templates/default/images/layout/socialNetwok.png') 0 0;\n    }\n    .fa-instagram:before {\n    content: none!important;\n    }\n    .fa-facebook:before {\n    content: none!important;\n    }\n    .pop-up-fb{\n            width: 40px;\n    height: 40px;\n    background: #999;\n    float: left;\n    margin: 0 10px 0 0;\n    background: url('http://www.infinitejourneys.in/templates/default/images/layout/socialNetwok.png') 0 0;\n    background-position: 0 0px;\n    padding: 0px 0px!important;\n    margin-top: -10px;\n    }\n    .pop-up-insta{\n        width: 40px!important;\n     height: 40px!important;\n     background-position: 40px 0!important;\n     background: url('http://www.infinitejourneys.in/templates/default/images/layout/socialNetwok.png')!important 0 0;\n     margin: 0 10px 0 0;\n    padding: 0px 0px!important;\n        margin-top: -10px;\n    }\n\n"
            link_ [ rel_ "stylesheet", href_ "http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.min.css" ]
            div_ [ class_ "overlay-bgSocial" ] $ do
                div_ [ class_ "popUpLoaderText", style_ "text-align:center;padding:25%;color:#A0A0A0;" ] $ img_ [ src_ "http://www.infinitejourneys.in/templates/default/images/foliage-loader.gif", alt_ "Loader" ]
                div_ [ class_ "overlayPopupSocial", style_ "padding-bottom:0px;" ] $ do
                    div_ [ class_ "formBox demo1 formTextarea" ] $ do
                        div_ [ id_ "socialBoxBoxDiv" ] $ do
                            div_ [ class_ "fbPopBx popNewBx", style_ "float: left;width: 100%;" ] $ do
                                a_ [ href_ "https://www.facebook.com/InfiniteJourneysIndia" ] $ img_ [ src_ "http://www.infinitejourneys.in/templates/default/images/layout/Infinite_journeys_logo_new.png", class_ "popNewInj fbijLnk", alt_ "Infinite Journeys Logo" ]
                                a_ [ href_ "https://www.facebook.com/Foliagers", target_ "_blank" ] $ img_ [ src_ "http://www.infinitejourneys.in/templates/default/images/layout/foliage_outdoors_logo_new.png", class_ "fbfoLnk ", alt_ "Foliage Outdoors Logo" ]
                                div_ [ class_ "fb-icon", style_ "margin-top: 15px;" ] $ do
                                    a_ [ href_ "https://www.facebook.com/InfiniteJourneysIndia", target_ "_blank", class_ "fbijLnk" ] $ do
                                        i_ [ class_ "fa  pop-up-fb", ariaHidden_ "true" ] $ ""
                                        span_ [ style_ "padding-top:10px;font-size:15px;color:#006599" ] $ " CLICK HERE"
                                    a_ [ href_ "https://www.facebook.com/Foliagers", target_ "_blank", class_ "fbfoLnk" ] $ do
                                        i_ [ class_ "fa  pop-up-fb", ariaHidden_ "true" ] $ ""
                                        span_ [ style_ "padding-top:10px;font-size:15px;color:#006599" ] $ " CLICK HERE"
                            div_ [ class_ "twPopBx popNewBx", style_ "float: left;width: 100%;" ] $ do
                                a_ [ href_ "javascript:void(0);" ] $ img_ [ src_ "http://www.infinitejourneys.in/templates/default/images/layout/Infinite_journeys_logo_new.png", class_ "popNewInj", alt_ "Infinite Journeys Logo" ]
                                a_ [ href_ "https://twitter.com/foliageoutdoors" ] $ img_ [ src_ "http://www.infinitejourneys.in/templates/default/images/layout/foliage_outdoors_logo_new.png", alt_ "Foliage Outdoors Logo" ]
                            div_ [ class_ "gplusPopBx popNewBx" ] $ do
                                a_ [ href_ "javascript:void(0);", style_ "display: inline-block;" ] $ img_ [ src_ "http://www.infinitejourneys.in/templates/default/images/layout/Infinite_journeys_logo_new.png", class_ "popNewInj", alt_ "Infinite Journeys Logo" ]
                                a_ [ href_ "https://plus.google.com/+foliageoutdoors/about", target_ "_blank", style_ "display: inline-block;" ] $ img_ [ src_ "http://www.infinitejourneys.in/templates/default/images/layout/foliage_outdoors_logo_new.png", alt_ "Foliage Outdoors Logo" ]
                            div_ [ class_ "instaPopBx popNewBx", style_ "float: left;width: 100%;" ] $ do
                                a_ [ href_ "https://www.instagram.com/infinite.journeys", target_ "_blank" ] $ img_ [ src_ "http://www.infinitejourneys.in/templates/default/images/layout/Infinite_journeys_logo_new.png", class_ "popNewInj instIjLnk", alt_ "Infinite Journeys Logo" ]
                                a_ [ href_ "https://www.instagram.com/foliageoutdoors", target_ "_blank" ] $ img_ [ src_ "http://www.infinitejourneys.in/templates/default/images/layout/foliage_outdoors_logo_new.png", class_ "instFoLnk", alt_ "Foliage Outdoors Logo" ]
                                div_ [ class_ "fb-icon", style_ "margin-top: 15px;" ] $ do
                                    a_ [ href_ "https://www.instagram.com/infinite.journeys", target_ "_blank", class_ "instIjLnk" ] $ do
                                        i_ [ class_ "fa fa-instagram pop-up-insta", ariaHidden_ "true" ] $ ""
                                        span_ [ style_ "font-size:15px;color:#333" ] $ " CLICK HERE"
                                    a_ [ href_ "https://www.instagram.com/foliageoutdoors", target_ "_blank", class_ "instFoLnk" ] $ do
                                        i_ [ class_ "fa fa-instagram pop-up-insta", ariaHidden_ "true" ] $ ""
                                        span_ [ style_ "font-size:15px;color:#333" ] $ "CLICK HERE"
                        button_ [ class_ "close-btn" ] $ "x"
                    div_ [ class_ "clear" ] $ ""
            script_ [ type_ "text/javascript" ] $ "\n\n    //Facebook\n    $('.fbijLnk').click(function() {\n        window.open(\"https://www.facebook.com/InfiniteJourneysIndia\", \"_blank\");\n    });\n\n    $('.fbfoLnk').click(function() {\n        window.open(\"https://www.facebook.com/Foliagers\", \"_blank\");\n    });\n\n    //Instagram\n    $('.instIjLnk').click(function() {\n        window.open(\"https://www.instagram.com/infinite.journeys\", \"_blank\");\n    });\n\n    $('.instFoLnk').click(function() {\n        window.open(\"https://www.instagram.com/foliageoutdoors\", \"_blank\");\n    });\n\n\n"
            toHtmlRaw  "<!-- Google Code for Remarketing Tag -->"
            toHtmlRaw  "<!-- Remarketing tags may not be associated with personally identifiable information or placed on pages related to sensitive categories. See more information and instructions on how to setup the tag on: http://google.com/ads/remarketingsetup -->"
            script_ [ type_ "text/javascript" ] $ "\n/* <![CDATA[ */\nvar google_conversion_id = 874842349;\nvar google_custom_params = window.google_tag_params;\nvar google_remarketing_only = true;\n/* ]]> */\n"
            script_ [ type_ "text/javascript", src_ "//www.googleadservices.com/pagead/conversion.js" ] $ ""
            noscript_ $ div_ [ style_ "display:inline;" ] $ img_ [ height_ "1", width_ "1", style_ "border-style:none;", alt_ "", src_ "//googleads.g.doubleclick.net/pagead/viewthroughconversion/874842349/?value=0&guid=ON&script=0" ]
            script_ "\nvar timeInt = setInterval(function(){\nif(jQuery('#successContactUsMsg').is(':visible'))\n{\n(new Image()).src=\"//www.googleadservices.com/pagead/conversion/1023196461/?label=8BJ-CKCo6GQQrfry5wM&guid=ON&script=0\";\nclearInterval(timeInt);\n}\n},1000)\n"
            script_ [ type_ "text/javascript" ] $ "\n\n<!--Start of Tawk.to Script-->\nvar $_Tawk_AccountKey='53e315938a6482154c000603',$_Tawk_API={},$_Tawk_LoadStart=new Date();(function(){var s1=document.createElement(\"script\"),s0=document.getElementsByTagName(\"script\")[0];s1.async=true;s1.src='https://embed.tawk.to/53e315938a6482154c000603/default';s1.charset='UTF-8';s1.setAttribute('crossorigin','*');s0.parentNode.insertBefore(s1,s0);})();\n\n"
            toHtmlRaw  "<!-- Review plugin js -->"
            script_ [ type_ "text/javascript", src_ "https://s3.amazonaws.com/assets.gobiggi.com/review/review.js", data_ "review-link" "infinite-journeys-and-foliage-outdoors", data_ "review-theme" "badge-style-04", data_ "attr-id" "2582" ] $ ""
            toHtmlRaw  "<!-- Review plugin js ends here -->"

