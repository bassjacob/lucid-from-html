{-# LANGUAGE OverloadedStrings, ExtendedDefaultRules #-}

import Lucid
import Lucid.Base
import Data.Text
import System.IO (stdout)
import Data.Text.Lazy.IO as L

main :: IO ()
main = L.hPutStr stdout (renderText template1)

ariaHidden_ :: Text -> Attribute
ariaHidden_ = makeAttribute "aria-hidden"

property_ :: Text -> Attribute
property_ = makeAttribute "property"

language_ :: Text -> Attribute
language_ = makeAttribute "language"

align_ :: Text -> Attribute
align_ = makeAttribute "align"

-- Template for file: the-golden-triangle-32.html
template1 :: Html ()
template1 = do
    doctype_
    toHtmlRaw  "<!--[if lt IE 7 ]><html class=\"ie ie6\" lang=\"en\"> <![endif]-->"
    toHtmlRaw  "<!--[if IE 7 ]><html class=\"ie ie7\" lang=\"en\"> <![endif]-->"
    toHtmlRaw  "<!--[if IE 8 ]><html class=\"ie ie8\" lang=\"en\"> <![endif]-->"
    toHtmlRaw  "<!--[if (gte IE 9)|!(IE)]><!-->"
    html_ [ lang_ "en", xmlns_ "http://www.w3.org/1999/xhtml" ] $ do
        toHtmlRaw  "<!--<![endif]-->"
        head_ $ do
            toHtmlRaw  "<!-- Basic Page Needs================================================== -->"
            meta_ [ httpEquiv_ "Content-Type", content_ "text/html; charset=utf-8" ]
            toHtmlRaw  "<!-- OLD -->"
            title_ "Infinite Journeys | Hotels | Flights | Packages | Cruises"
            meta_ [ name_ "keywords", content_ "Infinite Journeys Customised packages, best Hotel rates, Family trips, Wildlife safaris, Himalayan Treks, Kenya Safaris, Ladakh, offbeat tour, leisure holidays, exotic destinations, Cheap Air ticket booking, Visa, Honeymoon holiday planning, " ]
            meta_ [ name_ "description", content_ "Infinite Journeys: Call us on +912066447777 to plan your trip. Offbeat Packages Singapore, Thailand, Europe, Africa, Kerala, Manali, Rajasthan, Kashmir, Sikkim, Ladakh and many others" ]
            toHtmlRaw  "<!-- NEW -->"
            meta_ [ name_ "robots", content_ "index, follow" ]
            link_ [ rel_ "canonical", href_ "http://www.infinitejourneys.in/tour/the-golden-triangle-32" ]
            meta_ [ property_ "og:title", content_ "Infinite Journeys | Hotels | Flights | Packages | Cruises" ]
            meta_ [ property_ "og:description", content_ "Infinite Journeys: Call us on +912066447777 to plan your trip. Offbeat Packages Singapore, Thailand, Europe, Africa, Kerala, Manali, Rajasthan, Kashmir, Sikkim, Ladakh and many others" ]
            meta_ [ property_ "og:type", content_ "website" ]
            meta_ [ property_ "og:url", content_ "http://www.infinitejourneys.in/tour/the-golden-triangle-32" ]
            meta_ [ property_ "og:site_name", content_ "Infinite Journeys" ]
            meta_ [ property_ "og:image", content_ "http://www.infinitejourneys.in/templates/default/images/layout/logoInfinite.png" ]
            meta_ [ name_ "author", content_ "" ]
            toHtmlRaw  "<!-- Mobile Specific Metas================================================== -->"
            meta_ [ name_ "viewport", content_ "width=device-width, initial-scale=1, maximum-scale=1" ]
            toHtmlRaw  "<!-- FONTS================================================== -->"
            link_ [ href_ "http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,400,300,600,700,800", rel_ "stylesheet", type_ "text/css" ]
            toHtmlRaw  "<!-- CSS ================================================== -->"
            link_ [ rel_ "stylesheet", href_ "http://www.infinitejourneys.in/templates/default/css/base.css" ]
            toHtmlRaw  "<!--<link rel=\"stylesheet\" href=\"http://www.infinitejourneys.in/templates/default/css/skeleton.css\"/> -->"
            toHtmlRaw  "<!--<link rel=\"stylesheet\" href=\"http://www.infinitejourneys.in/templates/default/css/fancyfields.css\"/>\n<link type=\"text/css\" rel=\"stylesheet\" href=\"http://www.infinitejourneys.in/templates/default/css/jquery.mmenu.css\" />\n<link rel=\"stylesheet\" href=\"http://www.infinitejourneys.in/templates/default/css/jquery.bxslider.css\"/> -->"
            link_ [ rel_ "stylesheet", href_ "http://www.infinitejourneys.in/templates/default/css/prettyPhoto.css", type_ "text/css", media_ "screen", charset_ "utf-8" ]
            toHtmlRaw  "<!-- <link rel=\"stylesheet\" href=\"http://www.infinitejourneys.in/templates/default/css/globalSite.css\"/> \n<link rel=\"stylesheet\" href=\"http://www.infinitejourneys.in/templates/default/css/layoutSite.css\"/> -->"
            link_ [ rel_ "stylesheet", href_ "http://www.infinitejourneys.in/templates/default/css/infiniteGlobal.css" ]
            toHtmlRaw  "<!--for calender-->"
            link_ [ rel_ "stylesheet", media_ "all", type_ "text/css", href_ "http://code.jquery.com/ui/1.10.3/themes/smoothness/jquery-ui.css" ]
            link_ [ rel_ "stylesheet", media_ "all", type_ "text/css", href_ "http://www.infinitejourneys.in/js/admin/foliage-admin/calender/jquery-ui-timepicker-addon.css" ]
            toHtmlRaw  "<!--[if lt IE 9]><script src=\"http://html5shim.googlecode.com/svn/trunk/html5.js\"></script><![endif]-->"
            script_ [ type_ "text/javascript", src_ "http://code.jquery.com/jquery-1.10.2.min.js" ] $ ""
            script_ [ type_ "text/javascript", src_ "http://www.infinitejourneys.in/js/sitePath.js" ] $ ""
            toHtmlRaw  "<!--commaon js files-->"
            script_ [ type_ "text/javascript", src_ "http://www.infinitejourneys.in/js/overthrow.min.js", defer_ "defer" ] $ ""
            script_ [ src_ "http://www.infinitejourneys.in/js/modernizr.custom.js", type_ "text/javascript", defer_ "defer" ] $ ""
            toHtmlRaw  "<!--responsive support-->"
            script_ [ type_ "text/javascript", src_ "http://www.infinitejourneys.in/js/jquery.mmenu.js", defer_ "defer" ] $ ""
            toHtmlRaw  "<!--responsive-menu-->"
            script_ [ type_ "text/javascript", src_ "http://www.infinitejourneys.in/js/jquery.mousewheel.js", defer_ "defer" ] $ ""
            toHtmlRaw  "<!-- the mousewheel plugin -->"
            toHtmlRaw  "<!-- <script src=\"http://www.infinitejourneys.in/js/fancyfields-1.2.min.js\" type=\"text/javascript\" defer=\"defer\"></script> -->"
            script_ [ src_ "http://www.infinitejourneys.in/js/jquery.lazyload.js", type_ "text/javascript", defer_ "defer" ] $ ""
            toHtmlRaw  "<!-- lazyload images js -->"
            script_ [ type_ "text/javascript", src_ "http://www.infinitejourneys.in/js/jquery.bxslider.min.js", defer_ "defer" ] $ ""
            toHtmlRaw  "<!-- bx slider js -->"
            script_ [ type_ "text/javascript", src_ "http://www.infinitejourneys.in/js/jquery.easing.min.js", defer_ "defer" ] $ ""
            script_ [ type_ "text/javascript", src_ "http://www.infinitejourneys.in/js/popupSocial.js", defer_ "defer" ] $ ""
            toHtmlRaw  "<!-- footer social popuip window -->"
            toHtmlRaw  "<!--end commaon js files-->"
            toHtmlRaw  "<!-- Facebook Conversion Code for Foliage Outdoors -->"
            script_ "(function() {\n    var _fbq = window._fbq || (window._fbq = []);\n    if (!_fbq.loaded) {\n    var fbds = document.createElement('script');\n    fbds.async = true;\n    fbds.src = '//connect.facebook.net/en_US/fbds.js';\n    var s = document.getElementsByTagName('script')[0];\n    s.parentNode.insertBefore(fbds, s);\n    _fbq.loaded = true;\n    }\n    })();\n    window._fbq = window._fbq || [];\n    window._fbq.push(['track', '6032443521819', {'value':'0.00','currency':'INR'}]);\n    "
            noscript_ $ img_ [ height_ "1", width_ "1", alt_ "", style_ "display:none", src_ "https://www.facebook.com/tr?ev=6032443521819&cd[value]=0.00&cd[currency]=INR&noscript=1" ]
            script_ [ src_ "http://www.infinitejourneys.in/js/jquery.prettyPhoto.js", type_ "text/javascript", charset_ "utf-8", defer_ "defer" ] $ ""
            script_ [ type_ "text/javascript", src_ "http://code.jquery.com/ui/1.10.3/jquery-ui.min.js", defer_ "defer" ] $ ""
            script_ [ src_ "http://www.infinitejourneys.in/js/scrollIt.min.js", type_ "text/javascript", defer_ "defer" ] $ ""
            script_ [ src_ "http://www.infinitejourneys.in/js/jquery.accordion.js", type_ "text/javascript", defer_ "defer" ] $ ""
            script_ [ type_ "text/javascript", src_ "http://www.infinitejourneys.in/js/globalTours.js", defer_ "defer" ] $ ""
            script_ [ type_ "text/javascript", src_ "http://www.infinitejourneys.in/js/smallBannerBxSlider.js", defer_ "defer" ] $ ""
            script_ [ type_ "text/javascript", src_ "http://www.infinitejourneys.in/js/stickyNavContainer.js", defer_ "defer" ] $ ""
            script_ [ type_ "text/javascript", src_ "http://www.infinitejourneys.in/js/scroll.js", defer_ "defer" ] $ ""
            script_ [ type_ "text/javascript", src_ "http://www.infinitejourneys.in/js/phGallerySlide.js", defer_ "defer" ] $ ""
            script_ [ type_ "text/javascript", src_ "http://www.infinitejourneys.in/js/popUpGallery.js", defer_ "defer" ] $ ""
            script_ [ type_ "text/javascript", src_ "http://www.infinitejourneys.in/js/awsAccordion.js", defer_ "defer" ] $ ""
            script_ [ type_ "text/javascript", src_ "http://www.infinitejourneys.in/js/popupCommon.js", defer_ "defer" ] $ ""
            script_ [ type_ "text/javascript", src_ "http://www.infinitejourneys.in/js/advance-search.js", defer_ "defer" ] $ ""
            script_ [ type_ "text/javascript", src_ "http://www.infinitejourneys.in/js/ajax-countryList.js", defer_ "defer" ] $ ""
            toHtmlRaw  "<!-- ajax-country List -->"
            script_ [ type_ "text/javascript", language_ "javascript" ] $ "\n\n$(document).ready(function(){\n\n\t$('#spinner').fadeOut(200); // will first fade out the loading animation\n\t$('#preloaderIn').delay(500).fadeOut('slow'); // will fade out the white DIV that covers the website.\n\t$('body').delay(500).css({'overflow':'visible'});\n\n\t$('nav#menu').mmenu();\n\t$('.viewByOnlyFoliage, .foliageThemesBox, .boxAge, .boxFromDate, .boxToDate, .boxPriceRange').hide();\n\n  $(\"#year\").html((new Date).getFullYear())\n\n});\n\n\n\n"
            toHtmlRaw  "<!-- Favicons================================================== -->"
            link_ [ rel_ "shortcut icon", href_ "http://www.infinitejourneys.in/templates/default/images/favicon.ico" ]
            link_ [ rel_ "apple-touch-icon", href_ "http://www.infinitejourneys.in/templates/default/images/apple-touch-icon.png" ]
            link_ [ rel_ "apple-touch-icon", sizes_ "72x72", href_ "http://www.infinitejourneys.in/templates/default/images/apple-touch-icon-72x72.png" ]
            link_ [ rel_ "apple-touch-icon", sizes_ "114x114", href_ "http://www.infinitejourneys.in/templates/default/images/apple-touch-icon-114x114.png" ]
            toHtmlRaw  "<!--[if lt IE 7]>\n<style media=\"screen\" type=\"text/css\">\n#container {\n    height:100%;\n}\n</style>\n<![endif]-->"
            style_ "\n.advncSrchLdrImg{\n\tfloat: right;\n    margin-right: -14px;\n    margin-top: -32px;\n\tdisplay:none;\n}\n.ijLoadMoreTours .load_more{\n  \tbackground: none repeat scroll 0 0 #e65322;\n    border: 1px solid #e03901;\n    border-radius: 5px;\n    color: #ffffff;\n    display: block;\n    float: left;\n    font-size: 12px;\n\theight: 35px;\n    line-height: 35px;\n\tpadding: 0;\n    text-align: center;\n    text-transform: uppercase;\n    width: 120px;\n\tmargin-left:42%;\n}\n\n.ijLoadMoreTours .load_more:hover {\n    color: #f87043;\n}\n"
            toHtmlRaw  "<!-- Facebook Pixel Code -->"
            script_ "\n!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?\nn.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;\nn.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;\nt.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,\ndocument,'script','https://connect.facebook.net/en_US/fbevents.js');\n\nfbq('init', '1565756943734145');\nfbq('track', \"PageView\");\n\n// ViewContent\n// Track key page views (ex: product page, landing page or article)\nfbq('track', 'ViewContent');\n\n\n// Search\n// Track searches on your website (ex. product searches)\nfbq('track', 'Search');\n\n\n// AddToCart\n// Track when items are added to a shopping cart (ex. click/landing page on Add to Cart button)\nfbq('track', 'AddToCart');\n\n\n// AddToWishlist\n// Track when items are added to a wishlist (ex. click/landing page on Add to Wishlist button)\nfbq('track', 'AddToWishlist');\n\n\n// InitiateCheckout\n// Track when people enter the checkout flow (ex. click/landing page on checkout button)\nfbq('track', 'InitiateCheckout');\n\n\n// AddPaymentInfo\n// Track when payment information is added in the checkout flow (ex. click/landing page on billing info)\nfbq('track', 'AddPaymentInfo');\n\n\n// Purchase\n// Track purchases or checkout flow completions (ex. landing on \"Thank You\" or confirmation page)\nfbq('track', 'Purchase', {value: '1.00', currency: 'USD'});\n\n\n// Lead\n// Track when a user expresses interest in your offering (ex. form submission, sign up for trial, landing on pricing page)\nfbq('track', 'Lead');\n\n\n// CompleteRegistration\n// Track when a registration form is completed (ex. complete subscription, sign up for a service)\nfbq('track', 'CompleteRegistration');\n\n\n// Other\n// \nfbq('track', 'Other');\n\n\n"
            noscript_ $ img_ [ height_ "1", width_ "1", style_ "display:none", src_ "https://www.facebook.com/tr?id=1565756943734145&ev=PageView&noscript=1" ]
            toHtmlRaw  "<!-- End Facebook Pixel Code -->"
            script_ "\n  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){\n  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),\n  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)\n  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');\n\n  ga('create', 'UA-54361594-1', 'auto');\n  ga('send', 'pageview');\n"
        toHtmlRaw  "<!-- Primary Page Layout================================================== -->"
        body_ [ id_ "ij" ] $ do
            toHtmlRaw  "<!-- Preloader -->"
            div_ [ id_ "preloaderIn" ] $ div_ [ class_ "spinner" ] $ do
                div_ [ class_ "spinner-container container1" ] $ do
                    div_ [ class_ "circle1" ] $ ""
                    div_ [ class_ "circle2" ] $ ""
                    div_ [ class_ "circle3" ] $ ""
                    div_ [ class_ "circle4" ] $ ""
                div_ [ class_ "spinner-container container2" ] $ do
                    div_ [ class_ "circle1" ] $ ""
                    div_ [ class_ "circle2" ] $ ""
                    div_ [ class_ "circle3" ] $ ""
                    div_ [ class_ "circle4" ] $ ""
                div_ [ class_ "spinner-container container3" ] $ do
                    div_ [ class_ "circle1" ] $ ""
                    div_ [ class_ "circle2" ] $ ""
                    div_ [ class_ "circle3" ] $ ""
                    div_ [ class_ "circle4" ] $ ""
            div_ [ class_ "top-container" ] $ do
                div_ [ id_ "page" ] $ do
                    div_ [ id_ "header" ] $ a_ [ href_ "#menu" ] $ ""
                    div_ [ id_ "content" ] $ do
                        style_ [ type_ "text/css" ] $ "\n.topPhoneNo {\n\tposition: absolute;\n\tright: 0px;\n\ttop: 10px;\n\tfont-weight: bold;\n\tfont-size: 12px;\n\tcolor:#666;\n    width: 135px;\n}\n.topPhoneNo span{\n\tcolor:#666;\n\tfont-size:12px;\n}\n.topPhoneNoIcon {\ndisplay: block;\nwidth: 14px;\nheight: 18px;\nfloat: left;\nmargin-right: 2px;\npadding-top: 3px;\n}\n"
                        header_ $ div_ [ class_ "container" ] $ do
                            div_ [ class_ "three columns logo" ] $ do
                                a_ [ href_ "http://www.infinitejourneys.in/infinite-journeys/" ] $ img_ [ src_ "http://www.infinitejourneys.in/templates/default/images/layout/logoInfinite.png", class_ "logoIj", title_ "Infinite Journeys", alt_ "Infinite Journeys Best Travel Agency in Pune" ]
                                a_ [ href_ "http://www.infinitejourneys.in/foliage-outdoors/" ] $ img_ [ src_ "http://www.infinitejourneys.in/templates/default/images/layout/logoFoliage.png", class_ "logoFo", title_ "Foliage Outdoors", alt_ "Foliage Outdoors offering a diverse mix of Wildlife tours, Adventure camps, Trekking and Nature holidays." ]
                            div_ [ class_ "nine columns" ] $ div_ [ id_ "tabs" ] $ do
                                div_ [ class_ "home-btns" ] $ do
                                    div_ [ class_ "call-btn" ] $ do
                                        img_ [ src_ "http://www.infinitejourneys.in/templates/default/images/layout/phoneIcon.png", class_ "topPhoneNoIcon", alt_ "Phone Icon" ]
                                        span_ "+91 - 20 - 66447777"
                                    toHtmlRaw  "<!-- <a href=\"http://online.infinitejourneys.in/\" target=\"_blank\">\n                <div class=\"first-btn\">\n                    <img src=\"http://www.infinitejourneys.in/templates/default/images/layout/airplane.png\" alt=\"Airplane\">\n                    <h2>Flight Booking</h2>\n                </div>\n            </a> -->"
                                    toHtmlRaw  "<!-- <a href=\"http://online.infinitejourneys.in/\" target=\"_blank\">\n                <div class=\"second-btn\">\n                    <img src=\"http://www.infinitejourneys.in/templates/default/images/layout/khat.png\" alt=\"Hotel Booking\">\n                    <h2>Hotel Booking</h2>\n                </div>\n            </a> -->"
                                ul_ [ id_ "tabMenu" ] $ do
                                    li_ [ class_ "regular" ] $ a_ [ href_ "http://www.infinitejourneys.in", title_ "Home" ] $ "Home"
                                    li_ [ class_ "regular dropdown" ] $ do
                                        a_ [ href_ "http://www.infinitejourneys.in/about-us/", title_ "About Us" ] $ " About Us "
                                        ul_ [ class_ "dropdownSub" ] $ do
                                            span_ [ class_ "topArrow" ] $ ""
                                            li_ $ a_ [ href_ "http://www.infinitejourneys.in/about-us/#horizontalTab1", onclick_ "window.location.reload(true);", title_ "Our Story" ] $ "Our Story"
                                            li_ $ a_ [ href_ "http://www.infinitejourneys.in/about-us/#horizontalTab2", onclick_ "window.location.reload(true);", title_ "Our Vision & Values" ] $ "Our Vision & Values"
                                            li_ $ a_ [ href_ "http://www.infinitejourneys.in/about-us/#horizontalTab3", onclick_ "window.location.reload(true);", title_ "Why Us?" ] $ "Why Us?"
                                            li_ $ a_ [ href_ "http://www.infinitejourneys.in/about-us/#horizontalTab4", onclick_ "window.location.reload(true);", title_ "Our People" ] $ "Our People"
                                    li_ [ class_ "regular dropdown" ] $ do
                                        a_ [ href_ "javacript:void(0);", title_ "Our Services" ] $ " Our Services"
                                        ul_ [ class_ "dropdownSub" ] $ do
                                            span_ [ class_ "topArrow" ] $ ""
                                            li_ $ a_ [ href_ "http://www.infinitejourneys.in/infinite-journeys/", title_ "Infinite Journeys" ] $ "Infinite Journeys"
                                            li_ $ a_ [ href_ "http://www.infinitejourneys.in/foliage-outdoors/", title_ "Foliage Outdoors" ] $ "Foliage Outdoors"
                                            li_ $ a_ [ href_ "http://www.infinitejourneys.in/school-tours/", title_ "School Tours" ] $ "School Tours"
                                            li_ $ a_ [ href_ "http://www.infinitejourneys.in/corporate-tours/", title_ "Corporate Services" ] $ "Corporate Services"
                                            li_ $ a_ [ href_ "http://www.infinitejourneys.in/travel-consultancy/", title_ "Travel Consultancy" ] $ "Travel Consultancy"
                                            li_ $ a_ [ href_ "http://www.infinitejourneys.in/india-travel-partner/", title_ "India Travel Partner (DMC)" ] $ "India Travel Partner (DMC)"
                                    li_ [ class_ "regular" ] $ a_ [ href_ "http://www.infinitejourneys.in/gallery/", title_ "Gallery" ] $ "Gallery"
                                    li_ [ class_ "regular" ] $ a_ [ href_ "http://www.infinitejourneys.in/testimonials/", title_ "Testimonials" ] $ " Testimonials"
                                    li_ [ class_ "regular dropdown" ] $ do
                                        a_ [ href_ "javacript:void(0);", title_ "Announcement" ] $ "Blog & Updates"
                                        ul_ [ class_ "dropdownSub" ] $ do
                                            span_ [ class_ "topArrow" ] $ ""
                                            li_ $ a_ [ href_ "http://www.infinitejourneys.in/blog", title_ "Blog & Updates" ] $ "Blog & Updates"
                                            li_ $ a_ [ href_ "http://www.infinitejourneys.in/fo/sms-alerts", title_ "Live SMS Updates" ] $ "Live SMS Updates"
                                    li_ [ class_ "regular removePd" ] $ a_ [ href_ "http://www.infinitejourneys.in/contact-us/", title_ "Contact Us" ] $ "Contact Us"
                                    div_ [ class_ "clear" ] $ ""
                        section_ [ id_ "banner" ] $ ul_ [ class_ "bannerSlide" ] $ do
                            li_ $ img_ [ src_ "http://www.infinitejourneys.in/uploads/banners/infinite/1920x620/IMG_3496_AG_TZ.jpg" ]
                            li_ $ img_ [ src_ "http://www.infinitejourneys.in/uploads/banners/infinite/1920x620/IMG_8611b_antartica_RR_banner.jpg" ]
                            li_ $ img_ [ src_ "http://www.infinitejourneys.in/uploads/banners/infinite/1920x620/Poon_HIll_banner.jpg" ]
                            li_ $ img_ [ src_ "http://www.infinitejourneys.in/uploads/banners/infinite/1920x620/_DSC0134_a.jpg" ]
                            li_ $ img_ [ src_ "http://www.infinitejourneys.in/uploads/banners/infinite/1920x620/infiniteBanner1uglO.jpg" ]
                            li_ $ img_ [ src_ "http://www.infinitejourneys.in/uploads/banners/infinite/1920x620/Capetown_South_Africa.jpg" ]
                        section_ [ class_ "bodyContainerInner" ] $ div_ [ class_ "container" ] $ do
                            div_ [ class_ "nine columns rposition containerHold" ] $ do
                                ul_ [ id_ "crumbs" ] $ do
                                    li_ $ a_ [ href_ "http://www.infinitejourneys.in" ] $ " home "
                                    li_ $ a_ [ href_ "http://www.infinitejourneys.in/ij/" ] $ " Infinite Journeys "
                                    li_ " The Golden Triangle "
                                div_ [ class_ "clear" ] $ ""
                                div_ [ class_ "nine columns alpha omega divider" ] $ ""
                                div_ [ class_ "clear" ] $ ""
                                h2_ " The Golden Triangle "
                                a_ [ href_ "javascript:void(0);", class_ "tour packageThemes" ] $ " Classic, Family "
                                div_ [ class_ "clear" ] $ ""
                                div_ [ class_ "scroller", style_ "margin-bottom:38px;" ] $ do
                                    div_ [ class_ "navContainer spaceij" ] $ ul_ $ do
                                        li_ $ a_ [ class_ "active", data_ "scroll-nav" "0" ] $ " Overview "
                                        li_ $ a_ [ data_ "scroll-nav" "2", class_ "" ] $ " Itinerary "
                                        li_ $ a_ [ data_ "scroll-nav" "3", class_ "" ] $ " Gallery "
                                        li_ $ a_ [ data_ "scroll-nav" "4", class_ "" ] $ " Travel Tips "
                                        li_ $ a_ [ data_ "scroll-nav" "5", class_ "" ] $ " Maps "
                                    div_ [ data_ "scroll-index" "0" ] $ div_ [ class_ "indexOne" ] $ do
                                        h5_ " Overview "
                                        p_ $ do
                                            p_ "Tour Name : Golden Triangle"
                                            p_ "Suggested For/as : Classic,Family"
                                            p_ "Region : Asia"
                                            p_ "Country : India"
                                            p_ "State : Rajasthan"
                                            p_ "Destinations : Delhi, Agra, Fatehpur Sikri, Jaipur "
                                            p_ "Duration : 5 Nights / 6 Days"
                                        a_ [ href_ "http://www.infinitejourneys.in/ij/theme/related-tours?theme=Classic, Family", class_ "squareBtn pullLeft", title_ "Find Related Itineraries" ] $ " \n            Find Similar Trips "
                                        a_ [ href_ "javascript:void(0);", class_ "squareBtn pullLeft brownBtn showPopup", title_ "Enquire" ] $ " Enquire "
                                        a_ [ href_ "http://www.infinitejourneys.in/customize-your-holidays", class_ "squareBtn pullLeft brownBtn showPopup", title_ "Customize" ] $ " Customize "
                                        input_ [ type_ "hidden", value_ "infinite", class_ "enquireCategory" ]
                                        input_ [ type_ "hidden", value_ "www.infinitejourneys.in/tour/the-golden-triangle-32", class_ "enquireItemUrl" ]
                                        input_ [ type_ "hidden", value_ "The Golden Triangle", class_ "enquireItemTitle" ]
                                    div_ [ class_ "clear" ] $ ""
                                    div_ [ class_ "dividerSingle" ] $ ""
                                    div_ [ class_ "clear" ] $ ""
                                    div_ [ data_ "scroll-index" "2", class_ "indexThree pullLeft" ] $ do
                                        h5_ " Itinerary "
                                        div_ [ class_ "daysBox" ] $ do
                                            div_ [ class_ "days pullLeft" ] $ p_ " Day 1 "
                                            div_ [ class_ "daysDescription pullLeft" ] $ do
                                                toHtmlRaw  "<!-- <img class=\"pullLeft\" src=\"http://www.infinitejourneys.in/templates/default/images/illustration/ItineraryDays.jpg\">  -->"
                                                strong_ [ class_ "pullLeft", style_ "margin-bottom: 8px;" ] $ " Delhi "
                                                p_ [ style_ "margin:0px;" ] $ do
                                                    " Arrival at Delhi. Proceed for Delhi local sightseeing."
                                                    br_ []
                                                    "\r\nHumayun's Tomb – The elegant red sandstone structure has been archeologically restored is one of the most beautiful landmarks of Delhi. Qutub Minar - A soaring tower of early Muslim vintage, Qutub Minar is a major landmark of Delhi. Rajghat - A homage to “Father of the Nation”, Mahatma Gandhi. It is set in a garden with fountains and a variety of exotic trees. Bahai Temple – Temple resembles a Lotus and hence is aptly called as Lotus Temple. India Gate - Constructed as a memorial to commemorate the 70,000 India soldiers who laid down their lives in World War I, India Gate is located on Rajpath. Red Fort - Made in red sandstone, Red Fort is witness to all the historically important events right from the times of Mughals till date. Each night a Sound and Light show takes place in the Red Fort. Overnight at Delhi. "
                                            div_ [ class_ "clear" ] $ ""
                                        div_ [ class_ "daysBox" ] $ do
                                            div_ [ class_ "days pullLeft" ] $ p_ " Day 2 "
                                            div_ [ class_ "daysDescription pullLeft" ] $ do
                                                toHtmlRaw  "<!-- <img class=\"pullLeft\" src=\"http://www.infinitejourneys.in/templates/default/images/illustration/ItineraryDays.jpg\">  -->"
                                                strong_ [ class_ "pullLeft", style_ "margin-bottom: 8px;" ] $ " Delhi - Agra "
                                                p_ [ style_ "margin:0px;" ] $ do
                                                    " Proceed to Agra (195 km). Visit the famous Akshardham Temple enroute. The Akshardham temple complex has been built on the banks of the serene River Yamuna and lies over a sprawling 100 acres of lush manicured lawns adorned with water fountains. Proceed to Agra for overnight stay. "
                                                    br_ []
                                            div_ [ class_ "clear" ] $ ""
                                        div_ [ class_ "daysBox" ] $ do
                                            div_ [ class_ "days pullLeft" ] $ p_ " Day 3 "
                                            div_ [ class_ "daysDescription pullLeft" ] $ do
                                                toHtmlRaw  "<!-- <img class=\"pullLeft\" src=\"http://www.infinitejourneys.in/templates/default/images/illustration/ItineraryDays.jpg\">  -->"
                                                strong_ [ class_ "pullLeft", style_ "margin-bottom: 8px;" ] $ " Agra "
                                                p_ [ style_ "margin:0px;" ] $ do
                                                    " Visit to Taj Mahal, Agra Fort, Sikandara,  Itmad Ud Daulah."
                                                    br_ []
                                                    "\r\n Taj Mahal - The ultimate symbol of love situated on the banks of River Yamuna (closed on Friday). Agra Fort - Agra Fort, commissioned by Mughal Emperor Akbar continued to have additions till the period of Shah Jahan. Shah Jahan was held captive here by his son Aurangazeb. "
                                                    br_ []
                                                    "\r\nSikandara - The mausoleum of Emperor Akbar at Sikandara combines the best of Hindu and Muslim architectures. Completed in 1613 A.D. by his son Jahangir, it is one of the well-preserved monuments. Itmad Ud Daulah - Itmad-ud-Daulah, the tomb of Mirza Ghyas Beg, was built by his daughter and queen of Emperor Jehangir, Noor Jahan. Overnight at Agra. "
                                                    br_ []
                                            div_ [ class_ "clear" ] $ ""
                                        div_ [ class_ "daysBox" ] $ do
                                            div_ [ class_ "days pullLeft" ] $ p_ " Day 4 "
                                            div_ [ class_ "daysDescription pullLeft" ] $ do
                                                toHtmlRaw  "<!-- <img class=\"pullLeft\" src=\"http://www.infinitejourneys.in/templates/default/images/illustration/ItineraryDays.jpg\">  -->"
                                                strong_ [ class_ "pullLeft", style_ "margin-bottom: 8px;" ] $ " Agra - Fatehpur Sikri - Jaipur "
                                                p_ [ style_ "margin:0px;" ] $ do
                                                    " Fatehpur Sikri (36 km from Agra) built in red sandstone, was built by Mughal Emperor Akbar. Akbar constructed his capital city here and named it Fatehpur Sikri. "
                                                    br_ []
                                                    "\r\nJaipur (196 km from Fatehpur Sikri) - Arrival at Jaipur. Half day site seeing at Hawa Mahal, City Palace, Jantar Mantar and Laxmi Narayan Temple (Birla Temple). Jantar Mantar is a collection of early 18th century structures designed to measure the movements of the stars, sun and planets, while Hawa Mahal is a giant facade on the outer wall of the palace, created by the Maharaja to allow the ladies to discreetly watch the on-goings in the busy city below. Overnight at Jaipur. "
                                            div_ [ class_ "clear" ] $ ""
                                        div_ [ class_ "daysBox" ] $ do
                                            div_ [ class_ "days pullLeft" ] $ p_ " Day 5 "
                                            div_ [ class_ "daysDescription pullLeft" ] $ do
                                                toHtmlRaw  "<!-- <img class=\"pullLeft\" src=\"http://www.infinitejourneys.in/templates/default/images/illustration/ItineraryDays.jpg\">  -->"
                                                strong_ [ class_ "pullLeft", style_ "margin-bottom: 8px;" ] $ " Jaipur "
                                                p_ [ style_ "margin:0px;" ] $ " Visit to Amber Fort and Jaigad. Evening at Chokhi Dhani Ethnic Village. Amber Fort, 11 km from Jaipur, completed over a period of about two centuries is a classic fusion of Mughal and Hindu architecture, built in red sandstone and white marble. Jaigarh is one of the most spectacular forts of Jaipur. Jaigarh Fort is situated on a hilltop which has giant mounted cannon known as Jaivan, which is believed to be the largest cannon in the world. Chokhi Dhani is an Ethnic Village known for the experience of the typical Rajasthani environment where you can enjoy Rajasthani Folk Dance and food. Overnight at Jaipur. "
                                            div_ [ class_ "clear" ] $ ""
                                        div_ [ class_ "daysBox" ] $ do
                                            div_ [ class_ "days pullLeft" ] $ p_ " Day 6 "
                                            div_ [ class_ "daysDescription pullLeft" ] $ do
                                                toHtmlRaw  "<!-- <img class=\"pullLeft\" src=\"http://www.infinitejourneys.in/templates/default/images/illustration/ItineraryDays.jpg\">  -->"
                                                strong_ [ class_ "pullLeft", style_ "margin-bottom: 8px;" ] $ " Jaipur Departure "
                                                p_ [ style_ "margin:0px;" ] $ do
                                                    " Departure from Jaipur for your return journey. "
                                                    br_ []
                                            div_ [ class_ "clear" ] $ ""
                                    div_ [ class_ "clear" ] $ ""
                                    div_ [ class_ "dividerSingle" ] $ ""
                                    div_ [ data_ "scroll-index" "3", class_ "phGallery inFour gallery clearfix" ] $ do
                                        h5_ "Gallery"
                                        ul_ [ id_ "gallery", class_ "clearfix galleryBgColr" ] $ li_ $ do
                                            a_ [ class_ "group1", rel_ "prettyPhoto[gallery2]", href_ "http://www.infinitejourneys.in/uploads/gallery/infinite/originals/_DSC0133a__Custom__1420271772.jpg" ] $ img_ [ class_ "example-image", src_ "http://www.infinitejourneys.in/uploads/gallery/infinite/140x72/_DSC0133a__Custom__1420271772.jpg", width_ "140", height_ "72" ]
                                            a_ [ class_ "group1", rel_ "prettyPhoto[gallery2]", href_ "http://www.infinitejourneys.in/uploads/gallery/infinite/originals/_DSC0231__Custom__1420271774.JPG" ] $ img_ [ class_ "example-image", src_ "http://www.infinitejourneys.in/uploads/gallery/infinite/140x72/_DSC0231__Custom__1420271774.JPG", width_ "140", height_ "72" ]
                                            a_ [ class_ "group1", rel_ "prettyPhoto[gallery2]", href_ "http://www.infinitejourneys.in/uploads/gallery/infinite/originals/_DSC0247__Custom__1420271775.JPG" ] $ img_ [ class_ "example-image", src_ "http://www.infinitejourneys.in/uploads/gallery/infinite/140x72/_DSC0247__Custom__1420271775.JPG", width_ "140", height_ "72" ]
                                            a_ [ class_ "group1", rel_ "prettyPhoto[gallery2]", href_ "http://www.infinitejourneys.in/uploads/gallery/infinite/originals/Amber_fort__1_by_Pooja_Velhal__Custom__1420271775.jpg" ] $ img_ [ class_ "example-image", src_ "http://www.infinitejourneys.in/uploads/gallery/infinite/140x72/Amber_fort__1_by_Pooja_Velhal__Custom__1420271775.jpg", width_ "140", height_ "72" ]
                                            a_ [ class_ "group1", rel_ "prettyPhoto[gallery2]", href_ "http://www.infinitejourneys.in/uploads/gallery/infinite/originals/Amber_fort__2_by_Pooja_Velhal__Custom__1420271775.jpg" ] $ img_ [ class_ "example-image", src_ "http://www.infinitejourneys.in/uploads/gallery/infinite/140x72/Amber_fort__2_by_Pooja_Velhal__Custom__1420271775.jpg", width_ "140", height_ "72" ]
                                            a_ [ class_ "group1", rel_ "prettyPhoto[gallery2]", href_ "http://www.infinitejourneys.in/uploads/gallery/infinite/originals/Amber_fort_interior_by_Pooja_Velhal__Custom__1420271777.jpg" ] $ img_ [ class_ "example-image", src_ "http://www.infinitejourneys.in/uploads/gallery/infinite/140x72/Amber_fort_interior_by_Pooja_Velhal__Custom__1420271777.jpg", width_ "140", height_ "72" ]
                                            a_ [ class_ "group1", rel_ "prettyPhoto[gallery2]", href_ "http://www.infinitejourneys.in/uploads/gallery/infinite/originals/IMG_6481_b__Custom__1420271778.jpg" ] $ img_ [ class_ "example-image", src_ "http://www.infinitejourneys.in/uploads/gallery/infinite/140x72/IMG_6481_b__Custom__1420271778.jpg", width_ "140", height_ "72" ]
                                            a_ [ class_ "group1", rel_ "prettyPhoto[gallery2]", href_ "http://www.infinitejourneys.in/uploads/gallery/infinite/originals/IMG_6500_b__Custom__1420271780.jpg" ] $ img_ [ class_ "example-image", src_ "http://www.infinitejourneys.in/uploads/gallery/infinite/140x72/IMG_6500_b__Custom__1420271780.jpg", width_ "140", height_ "72" ]
                                            a_ [ class_ "group1", rel_ "prettyPhoto[gallery2]", href_ "http://www.infinitejourneys.in/uploads/gallery/infinite/originals/IMG_6553__Custom__1420271781.JPG" ] $ img_ [ class_ "example-image", src_ "http://www.infinitejourneys.in/uploads/gallery/infinite/140x72/IMG_6553__Custom__1420271781.JPG", width_ "140", height_ "72" ]
                                            a_ [ class_ "group1", rel_ "prettyPhoto[gallery2]", href_ "http://www.infinitejourneys.in/uploads/gallery/infinite/originals/IMG_6563__Custom__1420271783.JPG" ] $ img_ [ class_ "example-image", src_ "http://www.infinitejourneys.in/uploads/gallery/infinite/140x72/IMG_6563__Custom__1420271783.JPG", width_ "140", height_ "72" ]
                                            a_ [ class_ "group1", rel_ "prettyPhoto[gallery2]", href_ "http://www.infinitejourneys.in/uploads/gallery/infinite/originals/IMG_6567_a__Custom__1420271784.jpg" ] $ img_ [ class_ "example-image", src_ "http://www.infinitejourneys.in/uploads/gallery/infinite/140x72/IMG_6567_a__Custom__1420271784.jpg", width_ "140", height_ "72" ]
                                            a_ [ class_ "group1", rel_ "prettyPhoto[gallery2]", href_ "http://www.infinitejourneys.in/uploads/gallery/infinite/originals/IMG_6629_Banner_1420271786.jpg" ] $ img_ [ class_ "example-image", src_ "http://www.infinitejourneys.in/uploads/gallery/infinite/140x72/IMG_6629_Banner_1420271786.jpg", width_ "140", height_ "72" ]
                                            a_ [ class_ "group1", rel_ "prettyPhoto[gallery2]", href_ "http://www.infinitejourneys.in/uploads/gallery/infinite/originals/IMG_6634__Custom__1420271788.JPG" ] $ img_ [ class_ "example-image", src_ "http://www.infinitejourneys.in/uploads/gallery/infinite/140x72/IMG_6634__Custom__1420271788.JPG", width_ "140", height_ "72" ]
                                            a_ [ class_ "group1", rel_ "prettyPhoto[gallery2]", href_ "http://www.infinitejourneys.in/uploads/gallery/infinite/originals/IMG_6679__Custom__1420271789.JPG" ] $ img_ [ class_ "example-image", src_ "http://www.infinitejourneys.in/uploads/gallery/infinite/140x72/IMG_6679__Custom__1420271789.JPG", width_ "140", height_ "72" ]
                                            a_ [ class_ "group1", rel_ "prettyPhoto[gallery2]", href_ "http://www.infinitejourneys.in/uploads/gallery/infinite/originals/IMG_6698__Custom__1420271790.JPG" ] $ img_ [ class_ "example-image", src_ "http://www.infinitejourneys.in/uploads/gallery/infinite/140x72/IMG_6698__Custom__1420271790.JPG", width_ "140", height_ "72" ]
                                            a_ [ class_ "group1", rel_ "prettyPhoto[gallery2]", href_ "http://www.infinitejourneys.in/uploads/gallery/infinite/originals/IMG_6747_2__Custom__1420271792.JPG" ] $ img_ [ class_ "example-image", src_ "http://www.infinitejourneys.in/uploads/gallery/infinite/140x72/IMG_6747_2__Custom__1420271792.JPG", width_ "140", height_ "72" ]
                                            a_ [ class_ "group1", rel_ "prettyPhoto[gallery2]", href_ "http://www.infinitejourneys.in/uploads/gallery/infinite/originals/IMG_6851__Custom__1420271794.JPG" ] $ img_ [ class_ "example-image", src_ "http://www.infinitejourneys.in/uploads/gallery/infinite/140x72/IMG_6851__Custom__1420271794.JPG", width_ "140", height_ "72" ]
                                            a_ [ class_ "group1", rel_ "prettyPhoto[gallery2]", href_ "http://www.infinitejourneys.in/uploads/gallery/infinite/originals/IMG_6859__Custom__1420271795.JPG" ] $ img_ [ class_ "example-image", src_ "http://www.infinitejourneys.in/uploads/gallery/infinite/140x72/IMG_6859__Custom__1420271795.JPG", width_ "140", height_ "72" ]
                                            a_ [ class_ "group1", rel_ "prettyPhoto[gallery2]", href_ "http://www.infinitejourneys.in/uploads/gallery/infinite/originals/IMG_6861__Custom__1420271796.JPG" ] $ img_ [ class_ "example-image", src_ "http://www.infinitejourneys.in/uploads/gallery/infinite/140x72/IMG_6861__Custom__1420271796.JPG", width_ "140", height_ "72" ]
                                            a_ [ class_ "group1", rel_ "prettyPhoto[gallery2]", href_ "http://www.infinitejourneys.in/uploads/gallery/infinite/originals/IMG_6863__Custom__1420271798.JPG" ] $ img_ [ class_ "example-image", src_ "http://www.infinitejourneys.in/uploads/gallery/infinite/140x72/IMG_6863__Custom__1420271798.JPG", width_ "140", height_ "72" ]
                                            a_ [ class_ "group1", rel_ "prettyPhoto[gallery2]", href_ "http://www.infinitejourneys.in/uploads/gallery/infinite/originals/IMG_6909_a__Custom__1420271799.jpg" ] $ img_ [ class_ "example-image", src_ "http://www.infinitejourneys.in/uploads/gallery/infinite/140x72/IMG_6909_a__Custom__1420271799.jpg", width_ "140", height_ "72" ]
                                            a_ [ class_ "group1", rel_ "prettyPhoto[gallery2]", href_ "http://www.infinitejourneys.in/uploads/gallery/infinite/originals/IMG_6925__Custom__1420271800.JPG" ] $ img_ [ class_ "example-image", src_ "http://www.infinitejourneys.in/uploads/gallery/infinite/140x72/IMG_6925__Custom__1420271800.JPG", width_ "140", height_ "72" ]
                                            a_ [ class_ "group1", rel_ "prettyPhoto[gallery2]", href_ "http://www.infinitejourneys.in/uploads/gallery/infinite/originals/IMG_7004__Custom__1420271801.JPG" ] $ img_ [ class_ "example-image", src_ "http://www.infinitejourneys.in/uploads/gallery/infinite/140x72/IMG_7004__Custom__1420271801.JPG", width_ "140", height_ "72" ]
                                            a_ [ class_ "group1", rel_ "prettyPhoto[gallery2]", href_ "http://www.infinitejourneys.in/uploads/gallery/infinite/originals/IMG_7019__Custom__1420271803.JPG" ] $ img_ [ class_ "example-image", src_ "http://www.infinitejourneys.in/uploads/gallery/infinite/140x72/IMG_7019__Custom__1420271803.JPG", width_ "140", height_ "72" ]
                                            a_ [ class_ "group1", rel_ "prettyPhoto[gallery2]", href_ "http://www.infinitejourneys.in/uploads/gallery/infinite/originals/jantar_mantar_jaipur_2281_jpg_600x__Custom__1420271804.jpg" ] $ img_ [ class_ "example-image", src_ "http://www.infinitejourneys.in/uploads/gallery/infinite/140x72/jantar_mantar_jaipur_2281_jpg_600x__Custom__1420271804.jpg", width_ "140", height_ "72" ]
                                            a_ [ class_ "group1", rel_ "prettyPhoto[gallery2]", href_ "http://www.infinitejourneys.in/uploads/gallery/infinite/originals/jantar_mantar_jaipur_pooja_velhal__Custom__1420271804.jpg" ] $ img_ [ class_ "example-image", src_ "http://www.infinitejourneys.in/uploads/gallery/infinite/140x72/jantar_mantar_jaipur_pooja_velhal__Custom__1420271804.jpg", width_ "140", height_ "72" ]
                                            a_ [ class_ "group1", rel_ "prettyPhoto[gallery2]", href_ "http://www.infinitejourneys.in/uploads/gallery/infinite/originals/The_HAWA_MAHAL_by_Pooja_Velhal__Custom__1420271806.jpg" ] $ img_ [ class_ "example-image", src_ "http://www.infinitejourneys.in/uploads/gallery/infinite/140x72/The_HAWA_MAHAL_by_Pooja_Velhal__Custom__1420271806.jpg", width_ "140", height_ "72" ]
                                    div_ [ class_ "clear" ] $ ""
                                    div_ [ class_ "dividerSingle" ] $ ""
                                    div_ [ data_ "scroll-index" "4", class_ "travelTrip indexFour" ] $ do
                                        h5_ "Travel Tips"
                                        ul_ $ li_ [ style_ "background:none;" ] $ do
                                            span_ [ style_ "margin-right:10px;" ] $ "1."
                                            " Agra sightseeing places are closed on Fridays, Delhi sightseeing places are closed on Mondays and Jaipur most monuments close by 5 pm"
                                    div_ [ class_ "clear" ] $ ""
                                    div_ [ class_ "dividerSingle" ] $ ""
                                    div_ [ data_ "scroll-index" "5", class_ "mapView" ] $ do
                                        h5_ " Map"
                                        iframe_ [ src_ "https://mapsengine.google.com/map/u/1/embed?mid=zOs8Gv6jgkYA.kfXt0M5Xy2S4", width_ "640", height_ "480" ] $ ""
                                        div_ [ class_ "clear" ] $ ""
                                        div_ [ class_ "dividerSingle" ] $ ""
                            div_ [ class_ "three columns" ] $ div_ [ class_ "formBox demo1 boxShadowForm" ] $ do
                                h2_ "Advanced Search"
                                form_ $ do
                                    div_ [ class_ "rowElem radioSection" ] $ do
                                        div_ [ class_ "coll1", title_ "Infinite Journeys - Plan Your Holiday" ] $ do
                                            input_ [ type_ "radio", name_ "question", value_ "1", class_ "radiBatn1 folgeBasicSrch", id_ "customClick", checked_ ]
                                            label_ [ for_ "customClick" ] $ "Infinite"
                                        div_ [ class_ "coll2", title_ "Foliage Outdoors - Join Our Trips" ] $ do
                                            input_ [ type_ "radio", name_ "question", value_ "2", class_ "radiBatn2 folgeBasicSrch", id_ "conductedClick" ]
                                            label_ [ for_ "conductedClick" ] $ "Foliage"
                                        div_ [ class_ "clear" ] $ ""
                                    div_ [ class_ "selectSectionBox" ] $ do
                                        div_ [ class_ "rowElem selectSection viewByOnlyFoliage", title_ "View By" ] $ do
                                            label_ [ for_ "selectViewByName" ] $ "View By"
                                            select_ [ name_ "select2", class_ "selectViewByName", id_ "selectViewByName" ] $ do
                                                option_ [ value_ "" ] $ "-Select-"
                                                option_ [ value_ "all" ] $ "All"
                                                option_ [ value_ "month-wise" ] $ "Month-wise"
                                        div_ [ class_ "showBigLoadersImg" ] $ ""
                                        div_ [ class_ "advancedSearchBoxSection" ] $ do
                                            div_ [ class_ "rowElem selectSection infiniteThemesBox", title_ "Theme" ] $ do
                                                label_ [ for_ "themeTxtIJ" ] $ "Theme"
                                                select_ [ name_ "select2", id_ "themeTxtIJ" ] $ do
                                                    option_ [ value_ "" ] $ "-Select Theme-"
                                                    option_ [ value_ "Classic" ] $ "Classic"
                                                    option_ [ value_ "Family" ] $ "Family"
                                                    option_ [ value_ "Honeymoon" ] $ "Honeymoon"
                                                    option_ [ value_ "Off-the-track" ] $ "Off-the-track"
                                                    option_ [ value_ "Special Interest" ] $ "Special Interest"
                                            div_ [ class_ "rowElem selectSection foliageThemesBox", title_ "Theme" ] $ do
                                                label_ [ for_ "themeTxtFO" ] $ "Theme"
                                                select_ [ name_ "select2", id_ "themeTxtFO" ] $ do
                                                    option_ [ value_ "" ] $ "-Select Theme-"
                                                    option_ [ value_ " Kids Camp (8-10 yrs)" ] $ " Kids Camp (8-10 yrs)"
                                                    option_ [ value_ "International Tours " ] $ "International Tours "
                                                    option_ [ value_ "Kids Camp (10-12 yrs)" ] $ "Kids Camp (10-12 yrs)"
                                                    option_ [ value_ "MNS School" ] $ "MNS School"
                                                    option_ [ value_ "Open Age : Backpacking Tours" ] $ "Open Age : Backpacking Tours"
                                                    option_ [ value_ "Open Age : Special Tours" ] $ "Open Age : Special Tours"
                                                    option_ [ value_ "Open Age : Treks & Leisure Treks" ] $ "Open Age : Treks & Leisure Treks"
                                                    option_ [ value_ "Open Age : Wildlife Tours" ] $ "Open Age : Wildlife Tours"
                                                    option_ [ value_ "Students : Adventure Camp & Treks" ] $ "Students : Adventure Camp & Treks"
                                                    option_ [ value_ "Students : Wildlife Camps" ] $ "Students : Wildlife Camps"
                                                    option_ [ value_ "Upcoming Tours" ] $ "Upcoming Tours"
                                                    option_ [ value_ "Youth Camps (14 to 22 years)" ] $ "Youth Camps (14 to 22 years)"
                                            div_ [ class_ "rowElem selectSection advsRegion", title_ "Region" ] $ do
                                                input_ [ type_ "hidden", id_ "advSrchRegionTxt", value_ "" ]
                                                label_ [ for_ "regionTxt" ] $ "Region "
                                                select_ [ name_ "select2", id_ "regionTxt", class_ "regionNameVal" ] $ do
                                                    option_ [ value_ "##" ] $ "-Select Region-"
                                                    option_ [ value_ "AF##Africa" ] $ "Africa"
                                                    option_ [ value_ "AN##Antarctica" ] $ "Antarctica"
                                                    option_ [ value_ "AS##Asia", selected_ "selected" ] $ "Asia"
                                                    option_ [ value_ "OC##Australia and New Zealand" ] $ "Australia and New Zealand"
                                                    option_ [ value_ "EU##Europe" ] $ "Europe"
                                                    option_ [ value_ "NA##North America" ] $ "North America"
                                                    option_ [ value_ "SA##South America" ] $ "South America"
                                            div_ [ class_ "rowElem selectSection advsCountry", title_ "Country" ] $ do
                                                input_ [ type_ "hidden", id_ "advSrchCountryTxt", value_ "" ]
                                                label_ [ for_ "countryTxt" ] $ "Country"
                                                select_ [ name_ "select2", id_ "countryTxt", class_ "countryNameVal" ] $ do
                                                    option_ [ value_ "##" ] $ "-Select Country-"
                                                    option_ [ value_ "26##Bhutan" ] $ "Bhutan"
                                                    option_ [ value_ "39##Cambodia" ] $ "Cambodia"
                                                    option_ [ value_ "101##Hong Kong" ] $ "Hong Kong"
                                                    option_ [ value_ "104##India", selected_ "selected" ] $ "India"
                                                    option_ [ value_ "105##Indonesia" ] $ "Indonesia"
                                                    option_ [ value_ "262##Japan" ] $ "Japan"
                                                    option_ [ value_ "136##Malaysia" ] $ "Malaysia"
                                                    option_ [ value_ "137##Maldives" ] $ "Maldives"
                                                    option_ [ value_ "157##Nepal" ] $ "Nepal"
                                                    option_ [ value_ "168##Oman" ] $ "Oman"
                                                    option_ [ value_ "176##Philippines" ] $ "Philippines"
                                                    option_ [ value_ "201##Singapore" ] $ "Singapore"
                                                    option_ [ value_ "211##Sri Lanka" ] $ "Sri Lanka"
                                                    option_ [ value_ "222##Thailand" ] $ "Thailand"
                                                    option_ [ value_ "229##Turkey" ] $ "Turkey"
                                                    option_ [ value_ "235##United Arab Emirates" ] $ "United Arab Emirates"
                                                    option_ [ value_ "244##Vietnam" ] $ "Vietnam"
                                            div_ [ class_ "rowElem selectSection advsState", title_ "State" ] $ do
                                                input_ [ type_ "hidden", id_ "advSrchStateTxt", value_ "" ]
                                                label_ [ for_ "stateTxt" ] $ "State"
                                                select_ [ name_ "select2", id_ "stateTxt", class_ "stateNameVal" ] $ do
                                                    option_ [ value_ "##" ] $ "-Select State-"
                                                    option_ [ value_ "30##Andaman Islands" ] $ "Andaman Islands"
                                                    option_ [ value_ "1##Andhra Pradesh" ] $ "Andhra Pradesh"
                                                    option_ [ value_ "2##Arunachal Pradesh" ] $ "Arunachal Pradesh"
                                                    option_ [ value_ "3##Assam" ] $ "Assam"
                                                    option_ [ value_ "31##Chandigarh" ] $ "Chandigarh"
                                                    option_ [ value_ "35##Delhi" ] $ "Delhi"
                                                    option_ [ value_ "6##Goa" ] $ "Goa"
                                                    option_ [ value_ "7##Gujarat" ] $ "Gujarat"
                                                    option_ [ value_ "9##Himachal Pradesh" ] $ "Himachal Pradesh"
                                                    option_ [ value_ "10##Jammu and Kashmir" ] $ "Jammu and Kashmir"
                                                    option_ [ value_ "12##Karnataka" ] $ "Karnataka"
                                                    option_ [ value_ "13##Kerala" ] $ "Kerala"
                                                    option_ [ value_ "34##Lakshadweep" ] $ "Lakshadweep"
                                                    option_ [ value_ "14##Madhya Pradesh" ] $ "Madhya Pradesh"
                                                    option_ [ value_ "15##Maharashtra" ] $ "Maharashtra"
                                                    option_ [ value_ "16##Manipur" ] $ "Manipur"
                                                    option_ [ value_ "17##Meghalaya" ] $ "Meghalaya"
                                                    option_ [ value_ "18##Mizoram" ] $ "Mizoram"
                                                    option_ [ value_ "19##Nagaland" ] $ "Nagaland"
                                                    option_ [ value_ "20##Odisha" ] $ "Odisha"
                                                    option_ [ value_ "21##Punjab" ] $ "Punjab"
                                                    option_ [ value_ "22##Rajasthan" ] $ "Rajasthan"
                                                    option_ [ value_ "23##Sikkim" ] $ "Sikkim"
                                                    option_ [ value_ "24##Tamil Nadu" ] $ "Tamil Nadu"
                                                    option_ [ value_ "25##Telangana" ] $ "Telangana"
                                                    option_ [ value_ "27##Uttar Pradesh" ] $ "Uttar Pradesh"
                                                    option_ [ value_ "28##Uttarakhand" ] $ "Uttarakhand"
                                                    option_ [ value_ "29##West Bengal" ] $ "West Bengal"
                                            div_ [ class_ "rowElem selectSection boxAge", title_ "Age Group" ] $ do
                                                label_ [ for_ "ageTxt" ] $ "Age Group"
                                                select_ [ name_ "select2", id_ "ageTxt" ] $ do
                                                    option_ [ value_ "" ] $ "-Select Age Group-"
                                                    option_ [ value_ "Kids (8 to 10 yrs)" ] $ "Kids (8 to 10 yrs)"
                                                    option_ [ value_ "Students (10 to 16 yrs)" ] $ "Students (10 to 16 yrs)"
                                                    option_ [ value_ "For All Ages" ] $ "For All Ages"
                                                    option_ [ value_ "Kids (10 to 12 yrs)" ] $ "Kids (10 to 12 yrs)"
                                                    option_ [ value_ "Students (14 to 22 yrs)" ] $ "Students (14 to 22 yrs)"
                                            div_ [ class_ "rowElem selectSection boxFromDate", title_ "Batch Dates From" ] $ do
                                                label_ [ for_ "batchDatesFrom" ] $ "Batch Dates From"
                                                input_ [ type_ "text", id_ "batchDatesFrom", name_ "batchDatesFrom", readonly_ "readonly", placeholder_ "Select Date", value_ "" ]
                                            div_ [ class_ "rowElem selectSection boxToDate", title_ "Batch Dates To" ] $ do
                                                label_ [ for_ "batchDatesTo" ] $ "Batch Dates To"
                                                input_ [ type_ "text", id_ "batchDatesTo", name_ "batchDatesTo", readonly_ "readonly", placeholder_ "Select Date", value_ "" ]
                                            div_ [ class_ "rowElem selectSection boxDaysNights", title_ "Duration" ] $ do
                                                label_ [ for_ "durationDaysTxt" ] $ "Duration"
                                                span_ [ class_ "d" ] $ "Day"
                                                select_ [ name_ "select2", id_ "durationDaysTxt", class_ "day" ] $ do
                                                    option_ [ value_ "" ] $ "0"
                                                    option_ [ value_ "1" ] $ "1"
                                                    option_ [ value_ "2" ] $ "2"
                                                    option_ [ value_ "3" ] $ "3"
                                                    option_ [ value_ "4" ] $ "4"
                                                    option_ [ value_ "5" ] $ "5"
                                                    option_ [ value_ "6" ] $ "6"
                                                    option_ [ value_ "7" ] $ "7"
                                                    option_ [ value_ "8" ] $ "8"
                                                    option_ [ value_ "9" ] $ "9"
                                                    option_ [ value_ "10" ] $ "10"
                                                    option_ [ value_ "11" ] $ "11"
                                                    option_ [ value_ "12" ] $ "12"
                                                    option_ [ value_ "13" ] $ "13"
                                                    option_ [ value_ "14" ] $ "14"
                                                    option_ [ value_ "15" ] $ "15"
                                                    option_ [ value_ "16" ] $ "16"
                                                    option_ [ value_ "17" ] $ "17"
                                                    option_ [ value_ "18" ] $ "18"
                                                    option_ [ value_ "19" ] $ "19"
                                                    option_ [ value_ "20" ] $ "20"
                                                div_ [ class_ "clear" ] $ ""
                                                span_ [ class_ "n" ] $ "Night"
                                                select_ [ name_ "select2", id_ "durationNightsTxt", class_ "night" ] $ do
                                                    option_ [ value_ "" ] $ "0"
                                                    option_ [ value_ "1" ] $ "1"
                                                    option_ [ value_ "2" ] $ "2"
                                                    option_ [ value_ "3" ] $ "3"
                                                    option_ [ value_ "4" ] $ "4"
                                                    option_ [ value_ "5" ] $ "5"
                                                    option_ [ value_ "6" ] $ "6"
                                                    option_ [ value_ "7" ] $ "7"
                                                    option_ [ value_ "8" ] $ "8"
                                                    option_ [ value_ "9" ] $ "9"
                                                    option_ [ value_ "10" ] $ "10"
                                                    option_ [ value_ "11" ] $ "11"
                                                    option_ [ value_ "12" ] $ "12"
                                                    option_ [ value_ "13" ] $ "13"
                                                    option_ [ value_ "14" ] $ "14"
                                                    option_ [ value_ "15" ] $ "15"
                                                    option_ [ value_ "16" ] $ "16"
                                                    option_ [ value_ "17" ] $ "17"
                                                    option_ [ value_ "18" ] $ "18"
                                                    option_ [ value_ "19" ] $ "19"
                                                    option_ [ value_ "20" ] $ "20"
                                                div_ [ class_ "clear" ] $ ""
                                            div_ [ class_ "rowElem selectSection" ] $ do
                                                label_ "Keywords"
                                                input_ [ type_ "text", id_ "keywordsTxt", name_ "keywordsTxt", placeholder_ "Keywords", value_ "" ]
                                            div_ [ class_ "clear" ] $ ""
                                        div_ [ class_ "clear" ] $ ""
                                    div_ [ class_ "textSectionBox bg advancedSearchBtn", style_ "margin-bottom:50px;" ] $ do
                                        div_ [ class_ "rowElem refBtnElem pullLeft" ] $ a_ [ href_ "javascript:void(0);", id_ "resetAdvancedSearchBtn", class_ "refBtnElem " ] $ "Refresh"
                                        div_ [ class_ "rowElem refBtnElem pullLeft" ] $ a_ [ href_ "javascript:void(0);", class_ "searchBtn", id_ "advancedSearchBtn" ] $ "show"
                                        img_ [ class_ "advncSrchLdrImg", src_ "http://www.infinitejourneys.in/templates/default/images/admin/img/loaders/5.gif" ]
                                        div_ [ class_ "clear" ] $ ""
                        div_ [ class_ "overlay-bg" ] $ do
                            div_ [ class_ "popUpLoaderText", style_ "text-align:center;padding:25%;color:#A0A0A0;" ] $ img_ [ src_ "http://www.infinitejourneys.in/templates/default/images/foliage-loader.gif", alt_ "Loader" ]
                            div_ [ class_ "overlayPopup", style_ "padding-bottom:0px;height:500px;" ] $ do
                                div_ [ class_ "formBox demo1 formTextarea" ] $ do
                                    form_ $ do
                                        input_ [ type_ "hidden", id_ "contactUsCategory", value_ "" ]
                                        input_ [ type_ "hidden", id_ "contactUsTourTitle", value_ "" ]
                                        input_ [ type_ "hidden", id_ "contactUsTourUrl", value_ "" ]
                                        div_ [ id_ "enquiryNowBoxDiv" ] $ do
                                            h2_ [ style_ "margin-top:5px;", class_ "popUpHderTitle" ] $ ""
                                            div_ [ class_ "selectSectionBox" ] $ do
                                                div_ [ class_ "rowElem selectSection" ] $ do
                                                    label_ [ for_ "contactUsName" ] $ do
                                                        span_ [ class_ "redStar" ] $ "*"
                                                        " Name:"
                                                    input_ [ type_ "text", id_ "contactUsName", placeholder_ "Full Name" ]
                                                div_ [ class_ "clear" ] $ ""
                                            div_ [ class_ "selectSectionBox" ] $ do
                                                div_ [ class_ "rowElem selectSection" ] $ do
                                                    label_ [ for_ "contactUsEmail" ] $ do
                                                        span_ [ class_ "redStar" ] $ "*"
                                                        " Email:"
                                                    input_ [ type_ "text", id_ "contactUsEmail", placeholder_ "Email" ]
                                                div_ [ class_ "clear" ] $ ""
                                            div_ [ class_ "selectSectionBox", style_ "display:none;" ] $ do
                                                div_ [ class_ "rowElem selectSection" ] $ do
                                                    label_ [ for_ "contactUsSubject" ] $ "Subject:"
                                                    select_ [ name_ "select2", class_ "", id_ "contactUsSubject" ] $ do
                                                        option_ [ value_ "" ] $ "Select"
                                                        option_ [ value_ "Question" ] $ "Question"
                                                        option_ [ value_ "Business Proposal" ] $ "Business Proposal"
                                                        option_ [ value_ "Advertising" ] $ "Advertising"
                                                        option_ [ value_ "Complaint" ] $ "Complaint"
                                                div_ [ class_ "clear" ] $ ""
                                            div_ [ class_ "selectSectionBox" ] $ do
                                                div_ [ class_ "rowElem selectSection" ] $ do
                                                    label_ [ for_ "contactUsPhone" ] $ do
                                                        span_ [ class_ "redStar" ] $ "*"
                                                        " Phone No:"
                                                    input_ [ type_ "text", id_ "contactUsPhone", placeholder_ "Phone No" ]
                                                div_ [ class_ "clear" ] $ ""
                                            div_ [ class_ "selectSectionBox" ] $ do
                                                div_ [ class_ "rowElem selectSection" ] $ do
                                                    label_ [ for_ "contactUsMessage" ] $ "Message:"
                                                    textarea_ [ id_ "contactUsMessage", placeholder_ "Message..." ] $ ""
                                                div_ [ class_ "clear" ] $ ""
                                            div_ [ class_ "selectSectionBox" ] $ do
                                                img_ [ src_ "http://www.infinitejourneys.in/templates/default/images/admin/img/loaders/5.gif", id_ "enquiryNowLoader" ]
                                                div_ [ class_ "rowElem refBtnElem pullRight" ] $ input_ [ type_ "button", value_ "Send", class_ "searchBtn", id_ "enquiryNowButton", style_ "width:100px;" ]
                                                div_ [ class_ "clear" ] $ ""
                                        div_ [ id_ "successContactUsMsg" ] $ do
                                            "Thank you for getting in touch. "
                                            br_ []
                                            " Our travel consultant will revert to you within 24 hours."
                                    button_ [ class_ "close-btn" ] $ "x"
                                div_ [ class_ "clear" ] $ ""
                        style_ [ type_ "text/css" ] $ "\n.fldErrorMsg{\n  background-color: #ffebe8 !important;\n    border: 1px solid #dd3c10 !important;\n    color: #e61515 !important;\n    font-size: 12px !important;\n}\n.redStar{\n  color: #e61515;\n}\n#enquiryNowLoader{\n  display: none;\n  margin-left: 55%;\n  margin-top: 15px;\n  position: absolute;\n}\n#contactUsMessage{\n  height:105px;\n  margin-left:1%;\n  width:94%\n}\n"
                        footer_ $ do
                            section_ [ class_ "footTop" ] $ div_ [ class_ "container" ] $ do
                                div_ [ class_ "two columns coll" ] $ do
                                    ul_ $ do
                                        h5_ "Foliage Outdoors"
                                        li_ $ a_ [ href_ "http://www.infinitejourneys.in/fo/theme/-kids-camp-8-10-yrs?id=NjQ=", title_ " Kids Camp (8-10 yrs)" ] $ " Kids Camp (8-10 yrs)"
                                        li_ $ a_ [ href_ "http://www.infinitejourneys.in/fo/theme/international-tours-?id=NTY=", title_ "International Tours " ] $ "International Tours "
                                        li_ $ a_ [ href_ "http://www.infinitejourneys.in/fo/theme/kids-camp-10-12-yrs?id=NTE=", title_ "Kids Camp (10-12 yrs)" ] $ "Kids Camp (10-12 yrs)"
                                        li_ $ a_ [ href_ "http://www.infinitejourneys.in/fo/theme/mns-school?id=NTQ=", title_ "MNS School" ] $ "MNS School"
                                        li_ $ a_ [ href_ "http://www.infinitejourneys.in/fo/theme/open-age-backpacking-tours?id=NjU=", title_ "Open Age : Backpacking Tours" ] $ "Open Age : Backpacking Tours"
                                        li_ $ a_ [ href_ "http://www.infinitejourneys.in/fo/theme/open-age-special-tours?id=NTI=", title_ "Open Age : Special Tours" ] $ "Open Age : Special Tours"
                                        li_ $ a_ [ href_ "http://www.infinitejourneys.in/fo/theme/open-age-treks-leisure-treks?id=NjA=", title_ "Open Age : Treks & Leisure Treks" ] $ "Open Age : Treks & Leisure Treks"
                                        li_ $ a_ [ href_ "http://www.infinitejourneys.in/fo/theme/open-age--wildlife-tours?id=NTM=", title_ "Open Age : Wildlife Tours" ] $ "Open Age : Wildlife Tours"
                                        li_ $ a_ [ href_ "http://www.infinitejourneys.in/fo/theme/students--adventure-camp--treks?id=MTc=", title_ "Students : Adventure Camp & Treks" ] $ "Students : Adventure Camp & Treks"
                                        li_ $ a_ [ href_ "http://www.infinitejourneys.in/fo/theme/students--wildlife-camps?id=MTY=", title_ "Students : Wildlife Camps" ] $ "Students : Wildlife Camps"
                                        li_ $ a_ [ href_ "http://www.infinitejourneys.in/fo/theme/upcoming-tours?id=NTg=", title_ "Upcoming Tours" ] $ "Upcoming Tours"
                                        li_ $ a_ [ href_ "http://www.infinitejourneys.in/fo/theme/youth-camps-14-to-22-years?id=NTk=", title_ "Youth Camps (14 to 22 years)" ] $ "Youth Camps (14 to 22 years)"
                                        toHtmlRaw  "<!-- <li><a href=\"http://www.infinitejourneys.in/fo/see-all?id=1&category=upcoming_tours\" title=\"Upcoming Tours\">Upcoming Tours</a></li>\n                <li><a href=\"http://www.infinitejourneys.in/fo/see-all?id=2&category=top_picks_country&country=India\" title=\"Top Picks India\">Top Picks India</a></li>\n                <li><a href=\"http://www.infinitejourneys.in/fo/see-all?id=3&category=foliage_outdoors_exclusive\" title=\"Foliage Outdoors Exclusive\">Foliage Outdoors Exclusive</a></li> -->"
                                        toHtmlRaw  "<!-- <li><h6><a href=\"javascript:void(0);\" class=\"payUpolicy\" title=\"Terms and Conditions\">Terms and Conditions</a></h6></li> -->"
                                    div_ [ class_ "vDivider" ] $ ""
                                div_ [ class_ "two columns coll" ] $ do
                                    ul_ $ do
                                        h5_ "Infinite Journeys"
                                        li_ $ a_ [ href_ "http://www.infinitejourneys.in/ij/theme/classic?id=MzE=", title_ "Classic" ] $ "Classic"
                                        li_ $ a_ [ href_ "http://www.infinitejourneys.in/ij/theme/family?id=MjY=", title_ "Family" ] $ "Family"
                                        li_ $ a_ [ href_ "http://www.infinitejourneys.in/ij/theme/honeymoon?id=Mjc=", title_ "Honeymoon" ] $ "Honeymoon"
                                        li_ $ a_ [ href_ "http://www.infinitejourneys.in/ij/theme/off-the-track?id=Mjk=", title_ "Off-the-track" ] $ "Off-the-track"
                                        li_ $ a_ [ href_ "http://www.infinitejourneys.in/ij/theme/special-interest?id=MzI=", title_ "Special Interest" ] $ "Special Interest"
                                        li_ $ a_ [ href_ "http://www.infinitejourneys.in/ij/see-all?id=1&category=top_picks_country&country=India", title_ "Top Picks India" ] $ "Top Picks India"
                                        li_ $ a_ [ href_ "http://www.infinitejourneys.in/ij/see-all?id=2&category=top_picks_international", title_ "Top Picks International" ] $ "Top Picks International"
                                        li_ $ a_ [ href_ "http://www.infinitejourneys.in/ij/see-all?id=3&category=infinite_journeys_exclusives", title_ "Infinite Journeys Exclusives" ] $ "Infinite Journeys Exclusives"
                                        li_ $ h6_ $ a_ [ href_ "http://www.infinitejourneys.in/europe-tour-packages/", title_ "Europe Tour Packages" ] $ "Europe Tour Packages"
                                    div_ [ class_ "vDivider" ] $ ""
                                div_ [ class_ "three columns contactColl coll" ] $ do
                                    h5_ "Contact"
                                    p_ [ title_ "Phone: +91 - 20 - 66447777" ] $ do
                                        span_ "Phone:"
                                        strong_ "+91 - 20 - 66447777"
                                    p_ [ title_ "Email: web@infinitejourneys.in" ] $ do
                                        span_ "Email:"
                                        a_ [ href_ "mailto:web@infinitejourneys.in", style_ "text-decoration: none;" ] $ strong_ "web@infinitejourneys.in"
                                    p_ [ title_ "Address: 103, Mahadkar Chambers, Karve Road, Near Kothrud McDonalds, Kothrud, Pune 411038.." ] $ do
                                        span_ "Address:"
                                        strong_ "Main Office"
                                        strong_ $ p_ "103, Mahadkar Chambers, Karve Road, Near Kothrud McDonalds, Kothrud, Pune 411038.."
                                    br_ []
                                    p_ $ do
                                        span_ "Address:"
                                        strong_ "Aundh Branch"
                                    p_ $ strong_ "Plot Number : A-1 (AB) Second Floor, Abhimanshree Society, Above Hotel Abhiman, Near B U Bhandari Showroom, Opp St Joseph  School NCL - Pashan Road, Aundh, Pune 411008."
                                div_ [ class_ "one columns coll" ] $ div_ [ class_ "vDivider" ] $ ""
                                div_ [ class_ " four columns coll logocoll" ] $ do
                                    h5_ "Member of"
                                    img_ [ class_ "logo1", src_ "http://www.infinitejourneys.in/templates/default/images/illustration/tafi.png", alt_ "TAFI" ]
                                    img_ [ class_ "logo2", src_ "http://www.infinitejourneys.in/templates/default/images/illustration/iaai.png", alt_ "IAAI" ]
                                    img_ [ class_ "logo3", src_ "http://www.infinitejourneys.in/templates/default/images/illustration/etaa.png", alt_ "ETAA" ]
                                    img_ [ class_ "logo4", src_ "http://www.infinitejourneys.in/templates/default/images/illustration/taap.png", alt_ "TAAP" ]
                                    img_ [ class_ "logo5", src_ "http://www.infinitejourneys.in/templates/default/images/illustration/adtoi.png", alt_ "ADTOI" ]
                                    img_ [ class_ "logo6", src_ "http://www.infinitejourneys.in/templates/default/images/illustration/atom.png", alt_ "ATOM" ]
                                    img_ [ class_ "logo7", src_ "http://www.infinitejourneys.in/templates/default/images/illustration/advIndia.png", alt_ "Adventure Tour Operators Association of India" ]
                                    h4_ "recognised by"
                                    img_ [ class_ "logo8", src_ "http://www.infinitejourneys.in/templates/default/images/illustration/govInd.png", alt_ "Ministry of Tourism Government of India" ]
                                    img_ [ class_ "logo9", src_ "http://www.infinitejourneys.in/templates/default/images/illustration/imfo.png", alt_ "Recognizes by India Mountaineering Foundation" ]
                            section_ [ class_ "footBot" ] $ div_ [ class_ "container" ] $ do
                                div_ [ class_ "five columns" ] $ do
                                    toHtmlRaw  "<!-- <ul class=\"social\">\n            \t<a href=\"https://www.facebook.com/InfiniteJourneysIndia\" target=\"_blank\" title=\"Facebook\"><li class=\"fb\"></li></a>\n                <a href=\"https://twitter.com/foliageoutdoors\" title=\"Twitter\"><li class=\"tw\"></li></a>\n                <a href=\"javascript:void(0);\" title=\"Google Plus\"><li class=\"gPlus\"></li></a>\n                <a href=\"https://www.youtube.com/user/foliageoutdoors\" title=\"You Tube\"><li class=\"yTube\"></li></a>\n            </ul> -->"
                                    ul_ [ class_ "social" ] $ do
                                        a_ [ href_ "javascript:void(0);", title_ "Facebook", class_ "socialPopUp", id_ "socialFb" ] $ li_ [ class_ "fb" ] $ ""
                                        toHtmlRaw  "<!-- <a href=\"javascript:void(0);\" title=\"Twitter\" class=\"socialPopUp\" id=\"socialTw\"><li class=\"tw\"></li></a> -->"
                                        a_ [ href_ "https://twitter.com/foliageoutdoors", target_ "_blank", title_ "Twitter" ] $ li_ [ class_ "tw" ] $ ""
                                        toHtmlRaw  "<!-- <a href=\"javascript:void(0);\" title=\"Google Plus\" class=\"socialPopUp\" id=\"socialGplus\"><li class=\"gPlus\"></li></a> -->"
                                        a_ [ href_ "https://plus.google.com/+foliageoutdoors/about", target_ "_blank", title_ "Google Plus" ] $ li_ [ class_ "gPlus" ] $ ""
                                        a_ [ href_ "https://www.youtube.com/user/foliageoutdoors", target_ "_blank", title_ "You Tube" ] $ li_ [ class_ "yTube" ] $ ""
                                        a_ [ href_ "javascript:void(0);", title_ "Instagram", class_ "socialPopUp", id_ "socialInsta" ] $ li_ [ class_ "instagram" ] $ ""
                                div_ [ class_ "three columns" ] $ ""
                                div_ [ class_ "twelve columns footCopy" ] $ do
                                    p_ [ class_ "pullLeft" ] $ do
                                        "Copyright © "
                                        span_ [ id_ "year" ] $ ""
                                        a_ [ href_ "http://www.infinitejourneys.in/infinite-journeys/" ] $ span_ [ class_ "orange", title_ "Infinite Journeys" ] $ "Infinite Journeys."
                                        " &\n            "
                                        a_ [ href_ "http://www.infinitejourneys.in/foliage-outdoors/" ] $ span_ [ class_ "green", title_ "Foliage Outdoors" ] $ "Foliage Outdoors."
                                        " All Rights Reserved.\n            "
                                    p_ [ class_ "pullRight" ] $ do
                                        "Powered By : "
                                        a_ [ href_ "http://www.gobiggi.com/", target_ "_blank", class_ "orange", title_ "Gobiggi LLC." ] $ "Gobiggi LLC."
                        nav_ [ id_ "menu" ] $ ul_ $ do
                            li_ $ a_ [ href_ "http://www.infinitejourneys.in" ] $ "Home"
                            toHtmlRaw  "<!--<li class=\"Selected\">-->"
                            li_ $ do
                                a_ [ href_ "http://www.infinitejourneys.in/about-us/" ] $ "About Us"
                                ul_ $ do
                                    li_ $ a_ [ href_ "http://www.infinitejourneys.in/about-us/#horizontalTab1" ] $ "Our Story"
                                    li_ $ a_ [ href_ "http://www.infinitejourneys.in/about-us/#horizontalTab2" ] $ "Our Vision & Values"
                                    li_ $ a_ [ href_ "http://www.infinitejourneys.in/about-us/#horizontalTab3" ] $ "Why Us?"
                                    li_ $ a_ [ href_ "http://www.infinitejourneys.in/about-us/#horizontalTab4" ] $ "Our People"
                            li_ $ do
                                a_ [ href_ "javacript:void(0);" ] $ " Our Services"
                                ul_ $ do
                                    li_ $ a_ [ href_ "http://www.infinitejourneys.in/infinite-journeys/" ] $ "Infinite Journeys"
                                    li_ $ a_ [ href_ "http://www.infinitejourneys.in/foliage-outdoors/" ] $ "Foliage Outdoors"
                                    li_ $ a_ [ href_ "http://www.infinitejourneys.in/school-tours/" ] $ "School Tours"
                                    li_ $ a_ [ href_ "http://www.infinitejourneys.in/corporate-tours/" ] $ "Corporate Tours"
                            li_ $ a_ [ href_ "http://www.infinitejourneys.in/gallery/" ] $ "Gallery"
                            li_ $ a_ [ href_ "http://www.infinitejourneys.in/testimonials/" ] $ " Testimonials"
                            li_ $ do
                                a_ [ href_ "http://infinitejourneys.in/blog/" ] $ "Announcements"
                                toHtmlRaw  "<!-- <ul>\n                            <li><a href=\"javacript:void(0);\">Blogs</a></li>\n                            <li><a href=\"javacript:void(0);\">Forums</a></li>\n\t\t\t\t\t\t</ul> -->"
                            li_ $ a_ [ href_ "http://www.infinitejourneys.in/fo/sms-alerts" ] $ "Live SMS Updates"
                            li_ $ a_ [ href_ "http://www.infinitejourneys.in/contact-us/" ] $ "Contact Us"
                a_ [ href_ "javascript:void(0);", class_ "scrollup" ] $ " Scroll "
            div_ [ class_ "bar" ] $ ""
            style_ [ type_ "text/css" ] $ "\n    .rulesContent p{\n        padding: 10px;\n    }\n"
            div_ [ id_ "payUpolicy", class_ "simplePopup" ] $ div_ [ class_ "rulesContent" ] $ do
                h4_ "TERMS OF USE"
                p_ "The website www.infinitejourneys.in is owned by Infinite Journeys Pvt. Ltd..\n            All bookings here are made with Rnfinite Journeys Pvt. Ltd and the booking terms mentioned herein\n            below constitutes the entire agreement between the customer and Company. By making a booking\n            with us and/or depositing payments with us for tour and travel services you confirm having carefully\n            read, understood and accepted the below mentioned ‘Terms of Services’."
                h5_ $ strong_ "1. BOOKINGS"
                p_ "Visitors on our website are kindly requested to fill the Enquiry Form with all necessary fields\n            mentioned there and submit the same to be sent to our office. Upon receipt of the booking request or\n            travel enquiry a travel expert from our office will get in touch with you with the best available\n            information and offers for the desired tour package or travel services. In the event the travel\n            requirements are not clear in the booking form submitted by you to us, our team may contact you via\n            email or phone no. provided by you in the booking form. No booking is considered as ‘confirmed’\n            unless a tour confirmation letter is sent by us to the customer after receiving the initial advance\n            payments in our account."
                h5_ $ strong_ "2. PAYMENTS"
                h6_ [ style_ "margin-top: 20px;" ] $ strong_ "I). Deposit"
                p_ "Our tours are subject to availability. To make reservation for a tour with us, the customer requires\n        depositing advance payments as may be conveyed by our travel consultant during the course of\n        correspondence. No booking is treated ‘confirmed’ unless a confirmation letter is received by the\n        traveller from our office after depositing the advance payments for the trip."
                h6_ $ strong_ "II). Balance Payments"
                p_ "It is the sole responsibility of the customer to make the balance payments at least 90 days prior to\n        the start of the tour or as may be agreed / conveyed by our travel consultant during the course of\n        correspondence. In the event of non-receipt of balance payment by the cut-off date, the Company\n        will retain the right to treat the tour bookings as cancelled and the advance payment may be\n        forfeited."
                h6_ $ strong_ "III). How to pay for your travel bookings"
                p_ "To reserve tour package or travel services with us upon demand from our office our customers may\n        deposit the payments in our Yes Bank Ltd. account under intimation to our office. The bank account\n        information may be received from our office via email or phone. Our customers may also avail the\n        benefits of paying by their credit cards (Visa or MasterCard) using our ‘Secure Online Payment\n        Gateway’. For more information on security of your private information please read our ‘Privacy\n        Policy’."
                h6_ $ strong_ "A) Swift Bank Payments"
                p_ "Our customers may send the payments to us using our SWIFT bank account information. This is the\n        responsibility of the sender to provide us with a copy of the telegraphic transfer report (Bank\n        document) for necessary check and follow ups with our local bank in India. While paying the\n        deposits via SWIFT for the tour bookings kindly ensure that you have filled all correct information in\n        the payment form and have also paid the intermediary bank fee which is normally US$35 approx for\n        each payment. We will only credit in your tour account the amount which we receive in our bank and\n        we take no responsibility of intermediary bank fee/charges."
                h6_ $ strong_ "B) NEFT/RTGS"
                p_ "The customers may also pay through NEFT/RTGS for the bookings made with us. Please forward us\n        a copy of the NEFT/RTGS payment advice made by you. Upon receipt of the payments in the bank,\n        our travel consultant will confirm the same to you via phone or email."
                h6_ $ strong_ "C) Cheque / Bankers Cheque"
                p_ "The customer residing in India may deposit a local cheque / draft in our bank account (please ask for\n        the bank details from our office). A copy of deposit slip duly stamped by the bank may kindly be sent\n        to our office for our records. The receipt of the payment slip will not be considered as ‘receipt’ of the\n        payment. The payment will be considered as ‘received’ only once the same has arrived and settled\n        in our bank account. The booking confirmation process will effect accordingly therefore the\n        customers are advised to deposit the cheque payments well in advance to avoid inconvenience."
                h6_ $ strong_ "D) Cash payments"
                p_ "Our customers residing in India can also deposit advance payments in ‘cash’ in our bank account. A\n        copy of the payment deposit slip may kindly be sent to our office for their follow up and records. Our\n        office issues a ‘Cash Receipt’ against all cash payments received by us and it is the responsibility\n        and right of the customer to ask for a ‘customer copy’ of such receipt after the payment is settled in\n        our account."
                h6_ $ strong_ "E) Credit Card Payments"
                p_ "Our worldwide customers can avail the benefits of our ‘100% secure’ online credit card payment\n        gateway (Visa and MasterCard) managed by Pay u. We accept payments in US$, GBP, Euro, YEN,\n        INR and other renowned international currencies. It is advisable and requested to our customers\n        residing outside India to make the payments in US$, GBP, Euro, YEN or their local currency (if listed\n        in our payment gateway). Please note that the online payments attract online bank fee/charges of\n        3% (it may vary case to case) and the same is payable by the credit card holder in addition to the\n        tour payments while making the transaction. For certain credit card payments, on the instruction of\n        the bank to ensure genuine card entry our office may ask the credit card holder to fill and sign the\n        ‘Credit Card Payment Authorisation Form’ and send the same to our office along with the identity\n        proof (passport copies etc) and/or front copy of the credit card. It is mandatory for the customer to\n        provide us with such details / document if demanded by our office. Credit card security code\n        (CVV/CV2 no. mentioned on the ‘back’ of the card) is case sensitive and not to be shared by the\n        card holder or filled in the authorisation form or written in email etc."
                h6_ $ strong_ "F) Invoice and Taxes"
                p_ "A service invoice is issued for all tour bookings which are usually inclusive of all applicable taxes\n        except the Govt of India Service Tax. It is not only the liability of the Company to charge Service Tax\n        to the customer but also the responsibility of the customer to pay the same without fail. All our\n        quotes and offers are ‘exclusive’ of GST until specified in the quote unless."
                h6_ $ strong_ "G) Money Exchange rates"
                p_ "The customers may refer to the Reserve Bank of India website www.rbi.org.in to check the current\n        exchange rate of major foreign currencies to INDIAN Rupees"
                h6_ $ strong_ "H) Late Bookings"
                p_ "We may need full or higher percentage of amount for ‘Late Bookings’. Kindly ask our travel\n        consultant at the time of making bookings with us. The payments received for such bookings are\n        ‘non-refundable’."
                h5_ $ strong_ "3. TRAVELLER’S INFORMATION"
                p_ [ style_ "margin-top: 20px;" ] $ "To make reservation and also for our file records our travel consultant retains the right to ask you for providing him/her with the copy of passport, personal details such as name, date of birth, gender, address, phone no., email etc., the customer is kindly requested to provide the same if and when asked."
                h5_ $ strong_ "4. WHAT IS INCLUDED IN PRICE"
                p_ [ style_ "margin-top: 20px;" ] $ "Most ‘tour packages’ offered by Round the World Vacations are inclusive of accommodation in\n        hotel/guest house/resorts, transportation in a private car (for private trips) or in a coach/bus (for\n        group tours), breakfast, services of local tour guides (where available) for visiting historic sites and\n        basic entertainments for the trip. The same may vary on case to case basis and is conveyed to the\n        customer by our travel consultants during the course of correspondence."
                h6_ $ strong_ "I) Accommodation"
                p_ "Our ‘independent tours’ includes accommodation in handpicked hotels selected by us based on the\n        market report and/or recommendation of our past travellers. Based on the demand of the customer\n        and type of requirements or budget mentioned by them, our travel consultants ensure to provide a\n        comfortable and clean hotel for stay (for independent trip) during the trip. Also for our guaranteed\n        departure ‘India group tours’ we have a select list of handpicked hotels and guest houses which may\n        also be changed if situation demands. In the event of non-availability of hotel/s listed by us in our\n        offer, our team retains the right to reserve another similar standard hotel for the travellers. All our\n        hotels are subject to availability. We request the travellers to check on the internet about the\n        standard of the hotels offered by us, before making the deposit for the trip."
                h6_ $ strong_ "II) Vehicles and drivers"
                p_ "We provide comfortable vehicle (bus/coach/car/jeep) in good condition with customer friendly\n        English speaking drivers (basic knowledge of English). Some of our tourist drivers are highly\n        recommended by the travellers and they are serving to international itinerants for many years now."
                h6_ $ strong_ "III) Tour Guides/Escorts"
                p_ "Most trips are inclusive of assisted airport/railway station transfers. For sightseeing trips, we use only\n        Govt of India licensed ‘Tourist Guides/Escorts’. Most of our tour packages are inclusive of services\n        of local English speaking tour guides at historic sites. Other than English we also have tourist guides\n        who are expert in more international languages such as German, Spanish, Italian, Russian,\n        Japanese, Turkish, Farsi, Chinese etc."
                h6_ $ strong_ "IV) Meals"
                p_ "Most trips are inclusive of hotel breakfasts. Some trips also include special lunches and theme\n        dinners etc. in the hotel of stay or outside in a city restaurants. Some of the tours are even inclusive\n        of all meals (jungle lodges and camps mainly) which is mentioned in the list of inclusions and/or will\n        be conveyed during the course of correspondence."
                h6_ $ strong_ "V) Others"
                p_ "Many of our tour packages also includes basic entertainments and activities such as traditional\n        rickshaw rides, decorated Elephant ride, Camel ride, Boat tickets, cultural events etc. Please check\n        with our travel consultant about this while making reservation with us. A list of some important ‘not to\n        be missed’ visits /rides etc can be viewed in ‘Unique Travel Experience’ section and can be included\n        in the trip on demand, at an additional cost."
                h5_ $ strong_ "5. NOT INCLUDED"
                p_ [ style_ "margin-top: 20px;" ] $ "Usually our tour packages does not include international air ticket price, domestic flight tickets, travel insurance, visa (please check updates on India’s new VOA - Visa on Arrival policy), tips, camera/video camera fee at monuments and museums etc, personal expenses such as drinks/laundry/telephone/mini bar bills etc and the same are payable by the travellers in addition to the package price. Our services also does not include any additional expense incurred due to any\n        unforeseen circumstances or situation such as riots, strikes, political closure, natural hazard, technical failure, flight or train cancelation and delay etc or any other reason/situation beyond our control."
                h5_ $ strong_ "6. FLUID PRICING"
                p_ [ style_ "margin-top: 20px;" ] $ "As per the common practice of the trade Round The World Vacations operates tours on fluid price\n        basis. The offers are subject to the limitations imposed by hotels, airlines and other service providers and the same may change without prior notice in case of hike in the air ticket price, tax structure, major fluctuation in currency exchange rate or any other reason. Round the World Vacations retains the right to change its price and offers without prior notice, if the case occurs. It may also cause different price charged to different clients travelling in the same group/period. It is totally at the\n        discretion of the Company to decide upon the same."
                h5_ $ strong_ "7. TRAVEL DOCUMENTS"
                p_ [ style_ "margin-top: 20px;" ] $ "Once you have booked and paid for the tour our operation team will issue and provide you with a\n        copy of travel documents for your trip. You are kindly requested to check the details mentioned in the travel documents and in case of any error found the same may please be reported to the our concerned travel consultant for further corrections. The original travel documents shall be sent to the traveller at the port of his/her arrival in India. The travel document kit also carries a Feedback Form with an envelope which may please be filled by the traveller and sent to our senior management for their reference and our office records."
                h5_ $ strong_ "8. HOTEL CHECK IN/OUT POLICY"
                p_ [ style_ "margin-top: 20px;" ] $ "In India most hotels now offer 12.00 hrs check out and 14.00 hrs check in system. All our trips are\n        based on the same policy of the hotels and the travellers are requested to adhere with the same.\n        Any early check-in or late check-out is absolutely at the discretion of the hotel management and\n        based on the availability of rooms at the specific day and time. We neither guarantee nor do we\n        accept the liability of providing early check-in or late check-out without additional charges. Our travel\n        consultant may only request the hotel to extend this gesture to the customer and as stated the same\n        will be the decision of the hotel only. For any early check-in or late check-out facility the travellers\n        may kindly write to our office."
                h5_ $ strong_ "9. AMENDMENT OR EXTENSION IN TRIP/STAY"
                p_ [ style_ "margin-top: 20px;" ] $ "If there is any amendment requested by the customer after finalizing the trip/travel bookings with our\n        office, the same may be subject to availability. For any amendment the customers are requested to\n        immediately contact our head office and share the details of amendments with respective travel\n        consultant in writing. Our team will try its best to make the desired amendments in the trip, but we\n        neither guarantee nor do we take the liability of confirmation / availability of the travel arrangements\n        as per the new date or schedule announced by the customer. Any additional expense incurred due\n        to the amendment shall be payable only by the customer."
                h5_ $ strong_ "10. CHANGE IN THE PRICE OF THE TRIP"
                p_ [ style_ "margin-top: 20px;" ] $ "All our tours are subject to availability and our price/deals are subject to change without prior notice. We retain the right to cancel/amend or withdraw any price/deal/offer without assigning prior notice.\n        Our ‘India Group Tours’ are based on minimum participants on each trip. In the event of non\n        fulfilment of minimum participants for the group, we shall guarantee the trip with minimum possible\n        supplement cost which will be announced to the traveller before the commencement of the trip."
                h5_ $ strong_ "11. EXCLUSION FROM THE TOUR"
                p_ [ style_ "margin-top: 20px;" ] $ "At any given time if the client engage himself/herself/themselves in illegal or undesirable behaviour,\n        do not comply with the reasonable instructions and policy of our trip and services or if he/she/they\n        jeopardise the safety of other clients, guides, drivers etc. they may be excluded from the trip\n        immediately at our discretion and will be entitled for possible refund of the unutilised services,\n        subject to the policy and decision of airline, hotels etc. The refund will not be immediate but will be\n        done as per the policy of the Company through reliable banking channels only."
                h5_ $ strong_ "12. UNUTILIZED SERVICES"
                p_ [ style_ "margin-top: 20px;" ] $ "Round the World Vacations, its staff, management, partners or representative do not bear the\n        responsibility or liability of making refund for any unutilised service/s. It is to be noted seriously that\n        after the start of the trip no refund is possible for whatsoever reason. In the event of agreement by\n        any airline, hotel etc for refund against any unutilised part of the service or item etc Round the World\n        Vacations shall take up the matter on the behalf of the customer and shall only offer its assistance to\n        the customer in receiving the same from the other party. Such refunds shall be sent only to the bank\n        account of the customer within 2-3 weeks after receiving the same from service provider/s."
                h5_ $ strong_ "13. SPECIAL SCHEMES, DISCOUNTS AND OFFERS"
                p_ [ style_ "margin-top: 20px;" ] $ "None of the two (or more) schemes/ offers / deals (including loyalty discount, last minute discount,\n        early bird discount etc) can be clubbed with each other or any other offer. All such schemes and\n        offers introduced by us are only promotional offers and the terms of the scheme/s can be changed\n        anytime thereafter without assigning any notice. We also retain the right to withdraw or modify the\n        offers/scheme anytime without notice. It is totally at our discretion to confirm or reject your booking\n        under such schemes. These offers and schemes are not applicable for travel during New year or\n        Christmas period, peak tourist season dates, festival dates, luxury train bookings etc. No discount or\n        offer will be applicable for the trips already booked with us under a normal price. The discounts does\n        not apply to air fares, train bookings, luxury train travels, permits, visa, travel insurance,\n        monument/museum tickets, extra meals and/or pre/post tour arrangements. It applies to the\n        bonafide customer only and not to other traveller on the same trip (unless they also hold the discount\n        ticket). While making the query with us, you clearly need to mention the details of our special offer\n        under which you wish to book the trip. Services and bookings for all schemes and offers are subject\n        to availability only."
                h4_ "CANCELLATION AND REFUND"
                p_ "All cancellations must be intimated to our head office on phone followed by a written confirmation via\n        email or fax. Telephonic cancellation will not be accepted as ‘cancelation request’. Cancellations for the\n        independent/individual tour services should be made with a notice of not less than 7-30 days (According\n        to Situation). The cancellation in case of group booking should be made at least 30 days prior to the date\n        of commencement of the trip. For Christmas, New Year, Diwali, Pushkar Fair and other important festivals\n        the normal cancelation policy does not apply and payments for against bookings during such busy period\n        are considered as non-refundable. Please check with our travel consultants at the time of booking for\n        such cancelation policy for special event tours."
                h5_ "Please view the information on cancelation policy and cancellation fee as below:"
                h5_ "In the event of less than 8 travellers:"
                p_ "I) If the booking is cancelled 10 days prior to the start of the trip Loss of deposit will be full."
                p_ "II)  If the booking is cancelled 20 days prior to the start of the trip 50% Loss of deposit"
                p_ "III) If the booking is cancelled 30 days prior to the start of the trip 70% Amount will refund"
                p_ "IV) If the booking is cancelled within 0 days prior to the start of the trip 100% Amount will refund"
                h5_ "In the event of more than 8 travellers:"
                p_ "I) If the booking is cancelled 10 days prior to the start of the trip Loss of deposit will be full. "
                p_ "II) If the booking is cancelled 20 days prior to the start of the trip 50% Loss of deposit"
                p_ "III) If the booking is cancelled 30 days prior to the start of the trip 70% Amount will refund"
                p_ "IV) If the booking is cancelled within 0 days prior to the start of the trip 100% Amount will refund"
                h5_ "Please Note:"
                p_ "I) Amount will be refunded through Electronic Transfer or by the card (Debit/Credit)."
                p_ "II) Refund of amount will initiate after deducting the applicable cancellation Charges and service charge\n        and both will be settled within 7 to 30 days of the day of cancellation request approved by Round The\n        World Vacation."
                p_ "III) Booking which is under no Cancellation/ No Refund, guest/client travelling or person/entity booked will\n        have to pay the service charge to Round The World Vacations."
                h4_ "PRIVACY POLICY"
                p_ $ do
                    "For us privacy for our valued customer is very important. We strongly believe that the personal\n        information of our customers should not be shared with the third party without the prior consent or\n        request from the customer. Privacy is the right of an individual and at nfinite Journeys Pvt. Ltd he\n        information of the customer such as contact no., email, addresses etc is used only for the internal\n        purpose and not for sale. "
                    br_ []
                    "\n        Your contact information is stored in our database and is only used to contact you during the course\n        of your travel with us for sharing the status of your travel bookings with us and then after for\n        announcement of our latest deals and news etc. We at Round the World Holidays condemn the\n        unauthorised reach and misuse and/or discloser of the personal information of the customer and we\n        have strict guidelines and high security features to prevent the same. "
                    br_ []
                    " \n        Any changes in our ‘Privacy Policy’ will be posted here on the website. Should the customer require\n        any further information on our ‘Privacy Policy’ please send us an email at\n        "
                    a_ [ href_ "mailto:info@foliageoutdoors.com" ] $ "info@foliageoutdoors.com"
                    " with ‘Privacy Policy’ written in the subject field. We will ensure reply to the reasonable queries at our earliest possible time."
                h5_ "DATA SECURITY INFORMATION"
                p_ "We have extensive firewall and high end security system to monitor the traffic and financial\n        transaction on our website/s. Any suspicious email, traffic on website and/or financial transaction will\n        be investigated to ensure there is no breach of policy and security. Our customer care executive or\n        other staff may contact you to verify the transaction made by you. The secure connection between\n        your browser and our system for financial transactions uses 128 bit Secure Sockets Layer (SSL)\n        encryption. This is a well-respected technology developed by Netscape, Microsoft and RSA Inc that\n        is supported by most browsers."
                h5_ "SECURE ONLINE PAYMENTS"
                p_ "The visitor on our website please take a note that your name, email address and other personal\n        information submitted on our website may be stored with us and may also appear on the website.\n        Like other platforms our server log files also receives general information such as IP address of the\n        visitor, cookie etc. For the financial transactions by credit card nfinite Journeys Pvt. Ltd uses a 3rd\n        party secure payment gateway provided by “Pay u” and the credit card details are ‘not stored’ with\n        Round the World Holidays, instead the information is securely stored and encrypted with\n        Visa/MasterCard. The ‘online credit card payment gateway’ provided by us for our customers is fully\n        PCI-DSS compliant and to transfer information between Round the World Holidays and credit card\n        bank we use a 128bit SSL certificate powered by Dialect . It simply means that when the customer\n        makes the transaction using our online payment gateway on our website, these details are being\n        securely stored within Dialect’s fully secure vaults to ensure your information cannot be used by\n        malicious 3rd parties. Round the World Holidays and/or its employees cannot view the credit card’s"
                h5_ "CHILDREN"
                p_ "We do not suggest and allow person/s below 18 year of age to become a member of our website\n        and other websites/social sites etc. By entering to our websites and using our services you confirm\n        and warrant that you are 18 or older."
                h5_ "NO GUARANTEES"
                p_ $ do
                    "Round the World Holidays India Pvt. Ltd. will make all possible efforts to meet with the policies\n        mentioned herein on the website, but we are not in a position to guarantee these standards as there\n        may be factors beyond our control. As a consequence, we disclaim any warranties or\n        representations relating to maintenance or nondisclosure of Data. "
                    br_ []
                    br_ []
                    "\n        Our ‘Privacy Policy’ does not cover or apply to the other entities that are not under our control or\n        owned by us and/or person/s that are not our employees within our control."
            script_ [ type_ "text/javascript", src_ "http://www.infinitejourneys.in/js/jquery.simplePopup.js" ] $ ""
            link_ [ rel_ "stylesheet", type_ "text/css", href_ "http://www.infinitejourneys.in/templates/default/css/popupstyle.css" ]
            script_ [ type_ "text/javascript" ] $ "\n$(document).ready(function(){\n   $('.payUpolicy').click(function(){\n     $('#payUpolicy').simplePopup({\n        centerPopup: true,\n     });\n   });\n});\n"
            style_ [ type_ "text/css" ] $ "\n    .popNewBx{\n        float: none;\n        width: 100%;\n        display: block;\n        text-align: center;\n        vertical-align: middle;\n        position: relative;\n        margin-top: 10%;\n        height: 100%;\n    }\n    .popNewInj{\n        border-right: 1px solid #ccc;\n        width: inherit;\n        padding: 0 15px;\n        margin: 0 15px 0 0;\n    }\n    .fb-icon a {\n        color:#E35E12;\n        font-size: 15px;\n        font-weight: 600;\n        margin: 13px 20px;\n        display: inline-block;\n    }\n    .fb-icon a i{\n        /*background-color: #E35E12;*/\n        /*background-position: 40px 41px;*/\n        /*background: url('http://www.infinitejourneys.in/templates/default/images/layout/socialNetwok.png');*/\n        /*color: #ffffff;*/\n        border-radius: 100%;\n        padding: 10px 13px;\n        font-size: 17px;\n        margin-right: 5px;\n    }\n\n    .fa-instagram{\n     width: 40px;\n    height: 40px;\n    background: #999;\n    float: left;\n    margin: 0 10px 0 0;\n    background: url('http://www.infinitejourneys.in/templates/default/images/layout/socialNetwok.png') 0 0;\n    }\n    .fa-instagram:before {\n    content: none!important;\n    }\n    .fa-facebook:before {\n    content: none!important;\n    }\n    .pop-up-fb{\n            width: 40px;\n    height: 40px;\n    background: #999;\n    float: left;\n    margin: 0 10px 0 0;\n    background: url('http://www.infinitejourneys.in/templates/default/images/layout/socialNetwok.png') 0 0;\n    background-position: 0 0px;\n    padding: 0px 0px!important;\n    margin-top: -10px;\n    }\n    .pop-up-insta{\n        width: 40px!important;\n     height: 40px!important;\n     background-position: 40px 0!important;\n     background: url('http://www.infinitejourneys.in/templates/default/images/layout/socialNetwok.png')!important 0 0;\n     margin: 0 10px 0 0;\n    padding: 0px 0px!important;\n        margin-top: -10px;\n    }\n\n"
            link_ [ rel_ "stylesheet", href_ "http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.min.css" ]
            div_ [ class_ "overlay-bgSocial" ] $ do
                div_ [ class_ "popUpLoaderText", style_ "text-align:center;padding:25%;color:#A0A0A0;" ] $ img_ [ src_ "http://www.infinitejourneys.in/templates/default/images/foliage-loader.gif", alt_ "Loader" ]
                div_ [ class_ "overlayPopupSocial", style_ "padding-bottom:0px;" ] $ do
                    div_ [ class_ "formBox demo1 formTextarea" ] $ do
                        div_ [ id_ "socialBoxBoxDiv" ] $ do
                            div_ [ class_ "fbPopBx popNewBx", style_ "float: left;width: 100%;" ] $ do
                                a_ [ href_ "https://www.facebook.com/InfiniteJourneysIndia" ] $ img_ [ src_ "http://www.infinitejourneys.in/templates/default/images/layout/Infinite_journeys_logo_new.png", class_ "popNewInj fbijLnk", alt_ "Infinite Journeys Logo" ]
                                a_ [ href_ "https://www.facebook.com/Foliagers", target_ "_blank" ] $ img_ [ src_ "http://www.infinitejourneys.in/templates/default/images/layout/foliage_outdoors_logo_new.png", class_ "fbfoLnk ", alt_ "Foliage Outdoors Logo" ]
                                div_ [ class_ "fb-icon", style_ "margin-top: 15px;" ] $ do
                                    a_ [ href_ "https://www.facebook.com/InfiniteJourneysIndia", target_ "_blank", class_ "fbijLnk" ] $ do
                                        i_ [ class_ "fa  pop-up-fb", ariaHidden_ "true" ] $ ""
                                        span_ [ style_ "padding-top:10px;font-size:15px;color:#006599" ] $ " CLICK HERE"
                                    a_ [ href_ "https://www.facebook.com/Foliagers", target_ "_blank", class_ "fbfoLnk" ] $ do
                                        i_ [ class_ "fa  pop-up-fb", ariaHidden_ "true" ] $ ""
                                        span_ [ style_ "padding-top:10px;font-size:15px;color:#006599" ] $ " CLICK HERE"
                            div_ [ class_ "twPopBx popNewBx", style_ "float: left;width: 100%;" ] $ do
                                a_ [ href_ "javascript:void(0);" ] $ img_ [ src_ "http://www.infinitejourneys.in/templates/default/images/layout/Infinite_journeys_logo_new.png", class_ "popNewInj", alt_ "Infinite Journeys Logo" ]
                                a_ [ href_ "https://twitter.com/foliageoutdoors" ] $ img_ [ src_ "http://www.infinitejourneys.in/templates/default/images/layout/foliage_outdoors_logo_new.png", alt_ "Foliage Outdoors Logo" ]
                            div_ [ class_ "gplusPopBx popNewBx" ] $ do
                                a_ [ href_ "javascript:void(0);", style_ "display: inline-block;" ] $ img_ [ src_ "http://www.infinitejourneys.in/templates/default/images/layout/Infinite_journeys_logo_new.png", class_ "popNewInj", alt_ "Infinite Journeys Logo" ]
                                a_ [ href_ "https://plus.google.com/+foliageoutdoors/about", target_ "_blank", style_ "display: inline-block;" ] $ img_ [ src_ "http://www.infinitejourneys.in/templates/default/images/layout/foliage_outdoors_logo_new.png", alt_ "Foliage Outdoors Logo" ]
                            div_ [ class_ "instaPopBx popNewBx", style_ "float: left;width: 100%;" ] $ do
                                a_ [ href_ "https://www.instagram.com/infinite.journeys", target_ "_blank" ] $ img_ [ src_ "http://www.infinitejourneys.in/templates/default/images/layout/Infinite_journeys_logo_new.png", class_ "popNewInj instIjLnk", alt_ "Infinite Journeys Logo" ]
                                a_ [ href_ "https://www.instagram.com/foliageoutdoors", target_ "_blank" ] $ img_ [ src_ "http://www.infinitejourneys.in/templates/default/images/layout/foliage_outdoors_logo_new.png", class_ "instFoLnk", alt_ "Foliage Outdoors Logo" ]
                                div_ [ class_ "fb-icon", style_ "margin-top: 15px;" ] $ do
                                    a_ [ href_ "https://www.instagram.com/infinite.journeys", target_ "_blank", class_ "instIjLnk" ] $ do
                                        i_ [ class_ "fa fa-instagram pop-up-insta", ariaHidden_ "true" ] $ ""
                                        span_ [ style_ "font-size:15px;color:#333" ] $ " CLICK HERE"
                                    a_ [ href_ "https://www.instagram.com/foliageoutdoors", target_ "_blank", class_ "instFoLnk" ] $ do
                                        i_ [ class_ "fa fa-instagram pop-up-insta", ariaHidden_ "true" ] $ ""
                                        span_ [ style_ "font-size:15px;color:#333" ] $ "CLICK HERE"
                        button_ [ class_ "close-btn" ] $ "x"
                    div_ [ class_ "clear" ] $ ""
            script_ [ type_ "text/javascript" ] $ "\n\n    //Facebook\n    $('.fbijLnk').click(function() {\n        window.open(\"https://www.facebook.com/InfiniteJourneysIndia\", \"_blank\");\n    });\n\n    $('.fbfoLnk').click(function() {\n        window.open(\"https://www.facebook.com/Foliagers\", \"_blank\");\n    });\n\n    //Instagram\n    $('.instIjLnk').click(function() {\n        window.open(\"https://www.instagram.com/infinite.journeys\", \"_blank\");\n    });\n\n    $('.instFoLnk').click(function() {\n        window.open(\"https://www.instagram.com/foliageoutdoors\", \"_blank\");\n    });\n\n\n"
            toHtmlRaw  "<!-- Google Code for Remarketing Tag -->"
            toHtmlRaw  "<!-- Remarketing tags may not be associated with personally identifiable information or placed on pages related to sensitive categories. See more information and instructions on how to setup the tag on: http://google.com/ads/remarketingsetup -->"
            script_ [ type_ "text/javascript" ] $ "\n/* <![CDATA[ */\nvar google_conversion_id = 874842349;\nvar google_custom_params = window.google_tag_params;\nvar google_remarketing_only = true;\n/* ]]> */\n"
            script_ [ type_ "text/javascript", src_ "//www.googleadservices.com/pagead/conversion.js" ] $ ""
            noscript_ $ div_ [ style_ "display:inline;" ] $ img_ [ height_ "1", width_ "1", style_ "border-style:none;", alt_ "", src_ "//googleads.g.doubleclick.net/pagead/viewthroughconversion/874842349/?value=0&guid=ON&script=0" ]
            script_ "\nvar timeInt = setInterval(function(){\nif(jQuery('#successContactUsMsg').is(':visible'))\n{\n(new Image()).src=\"//www.googleadservices.com/pagead/conversion/1023196461/?label=8BJ-CKCo6GQQrfry5wM&guid=ON&script=0\";\nclearInterval(timeInt);\n}\n},1000)\n"
            script_ [ type_ "text/javascript" ] $ "\n\n<!--Start of Tawk.to Script-->\nvar $_Tawk_AccountKey='53e315938a6482154c000603',$_Tawk_API={},$_Tawk_LoadStart=new Date();(function(){var s1=document.createElement(\"script\"),s0=document.getElementsByTagName(\"script\")[0];s1.async=true;s1.src='https://embed.tawk.to/53e315938a6482154c000603/default';s1.charset='UTF-8';s1.setAttribute('crossorigin','*');s0.parentNode.insertBefore(s1,s0);})();\n\n"
            toHtmlRaw  "<!-- Review plugin js -->"
            script_ [ type_ "text/javascript", src_ "https://s3.amazonaws.com/assets.gobiggi.com/review/review.js", data_ "review-link" "infinite-journeys-and-foliage-outdoors", data_ "review-theme" "badge-style-04", data_ "attr-id" "2582" ] $ ""
            toHtmlRaw  "<!-- Review plugin js ends here -->"

