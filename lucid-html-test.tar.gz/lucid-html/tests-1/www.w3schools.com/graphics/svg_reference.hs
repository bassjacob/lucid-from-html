{-# LANGUAGE OverloadedStrings, ExtendedDefaultRules #-}

import Lucid
import Lucid.Base
import Data.Text
import System.IO (stdout)
import Data.Text.Lazy.IO as L

main :: IO ()
main = L.hPutStr stdout (renderText template1)

ariaHidden_ :: Text -> Attribute
ariaHidden_ = makeAttribute "aria-hidden"

property_ :: Text -> Attribute
property_ = makeAttribute "property"

-- tag is deprecated
language_ :: Text -> Attribute
language_ = makeAttribute "language"

-- tag is obsolete!
align_ :: Text -> Attribute
align_ = makeAttribute "align"

-- Template for file: svg_reference.asp
template1 :: Html ()
template1 = do
    doctype_
    html_ [ lang_ "en-US" ] $ do
        head_ $ do
            title_ "SVG Reference"
            meta_ [ charset_ "utf-8" ]
            meta_ [ name_ "viewport", content_ "width=device-width, initial-scale=1" ]
            meta_ [ name_ "Keywords", content_ "HTML,CSS,JavaScript,SQL,PHP,jQuery,XML,DOM,Bootstrap,Web development,W3C,tutorials,programming,training,learning,quiz,primer,lessons,references,examples,source code,colors,demos,tips" ]
            meta_ [ name_ "Description", content_ "Well organized and easy to understand Web building tutorials with lots of examples of how to use HTML, CSS, JavaScript, SQL, PHP, and XML." ]
            base_ [ href_ "https://www.w3schools.com" ]
            link_ [ rel_ "icon", href_ "/favicon.ico", type_ "image/x-icon" ]
            link_ [ rel_ "stylesheet", href_ "/w3css/4/w3.css" ]
            style_ "\r\na:hover,a:active{color:#4CAF50}\r\ntable.w3-table-all{margin:20px 0}\r\n/*OPPSETT AV TOP, TOPNAV, SIDENAV, MAIN, RIGHT OG FOOTER:*/\r\n.top {\r\nposition:relative;\r\nbackground-color:#ffffff;\r\nheight:68px;\r\npadding-top:20px;\r\nline-height:50px;\r\noverflow:hidden;\r\nz-index:2;\r\n}\r\n.w3schools-logo {\r\nfont-family:fontawesome;\r\ntext-decoration:none;\r\nline-height:1;\r\n-webkit-font-smoothing:antialiased;\r\n-moz-osx-font-smoothing:grayscale;\r\nfont-size:37px;\r\nletter-spacing:3px;\r\ncolor:#555555;\r\ndisplay:block;\r\nposition:absolute;\r\ntop:17px;\r\n}\r\n.w3schools-logo .dotcom {color:#4CAF50}\r\n.topnav {\r\nposition:relative;\r\nz-index:2;\r\nfont-size:17px;\r\nbackground-color:#5f5f5f;\r\ncolor:#f1f1f1;\r\nwidth:100%;\r\npadding:0;\r\nletter-spacing:1px;\r\nfont-family:\"Segoe UI\",Arial,sans-serif;\r\n}\r\n.topnav a{\r\npadding:10px 15px 9px 15px !important;\r\n}\r\n.topnav .w3-bar a:hover{\r\nbackground-color:#000000 !important;\r\ncolor:#ffffff !important;\r\n}\r\n.topnav .w3-bar a.active {\r\nbackground-color:#4CAF50;\r\ncolor:#ffffff;\r\n}\r\na.topnav-icons {\r\nwidth:52px !important;\r\nfont-size:20px !important;\r\npadding-top:11px !important;\r\npadding-bottom:13px !important;\r\n}\r\na.topnav-icons.fa-home {font-size:22px !important}\r\na.topnav-icons.fa-menu {font-size:22px !important}\r\na.topnav-localicons {\r\nfont-size:20px !important;\r\npadding-top:6px !important;\r\npadding-bottom:12px !important;\r\n}\r\ni.fa-caret-down,i.fa-caret-up{width:10px}\r\n#sidenav h2 {\r\nfont-size:21px;\r\npadding-left:16px;\r\nmargin:-4px 0 4px 0;\r\nwidth:204px;\r\n}\r\n#sidenav a {font-family:\"Segoe UI\",Arial,sans-serif;text-decoration:none;display:block;padding:2px 1px 1px 16px}\r\n#sidenav a:hover {color:#000000;background-color:#cccccc;}\r\n#sidenav a.active {background-color:#4CAF50;color:#ffffff}\r\n#leftmenuinner {\r\nposition:fixed;\r\ntop:0;\r\npadding-top:112px;\r\npadding-bottom:0;    \r\nheight:100%;\r\nwidth:220px;\r\nbackground-color:transparent;\r\n}\r\n#leftmenuinnerinner {\r\nheight:100%;\r\nwidth:100%;\r\noverflow-y:scroll;\r\noverflow-x:hidden;\r\npadding-top:20px;\r\n}\r\n#main {padding:16px}\r\n#mainLeaderboard {height:90px}\r\n#right {text-align:center;padding:16px 16px 0 0}\r\n#right a {text-decoration:none}\r\n#right a:hover {text-decoration:underline}\r\n#skyscraper {min-height:600px}\r\n.sidesection {margin-bottom:32px;}\r\n.bottomad {padding:0 16px 16px 0;float:left;width:auto;}\r\n.footer a {text-decoration:none;}\r\n.footer a:hover{text-decoration:underline;}\r\n#nav_tutorials,#nav_references,#nav_examples{-webkit-overflow-scrolling:touch;overflow:auto;}\r\n#nav_tutorials::-webkit-scrollbar,#nav_references::-webkit-scrollbar,#nav_examples::-webkit-scrollbar {width: 12px;}\r\n#nav_tutorials::-webkit-scrollbar-track,#nav_references::-webkit-scrollbar-track,#nav_examples::-webkit-scrollbar-track {background:#555555;}\r\n#nav_tutorials::-webkit-scrollbar-thumb,#nav_references::-webkit-scrollbar-thumb,#nav_examples::-webkit-scrollbar-thumb {background: #999999;}\r\n#nav_tutorials,#nav_references,#nav_examples {\r\ndisplay:none;\r\nletter-spacing:0;\r\nmargin-top:44px;\r\n}\r\n#nav_tutorials a,#nav_references a,#nav_examples a{\r\npadding:2px 0 !important;\r\n}\r\n.w3-example{background-color:#f1f1f1;padding:0.01em 16px;margin:20px 0;box-shadow:0 2px 4px 0 rgba(0,0,0,0.16),0 2px 10px 0 rgba(0,0,0,0.12)!important}\r\n.nextprev a {font-size:17px;border:1px solid #cccccc;}\r\n.nextprev a:link,.nextprev a:visited {background-color:#ffffff;color:#000000;}\r\n.nextprev a.w3-right {background-color:#4CAF50;color:#ffffff;border-color:#4CAF50}\r\n.w3-theme {color:#fff !important;background-color:#73AD21 !important;background-color:#4CAF50 !important}\r\n.w3-theme-border {border-color:#4CAF50 !important}\r\n.sharethis a:hover {color:inherit;}\r\n.fa-facebook-square,.fa-twitter-square,.fa-google-plus-square {padding:0 8px;}\r\n.fa-facebook-square:hover, .fa-thumbs-o-up:hover {color:#3B5998;}\r\n.fa-twitter-square:hover {color:#55acee;}\r\n.fa-google-plus-square:hover {color:#dd4b39;}\r\n#google_translate_element img {margin-bottom:-1px;}\r\n#googleSearch {color:#000000;}\r\n#googleSearch a {padding:0 !important;}\r\n.searchdiv {max-width:400px;margin:auto;text-align:left;font-size:16px}\r\ndiv.cse .gsc-control-cse, div.gsc-control-cse {background-color:transparent;border:none;padding:6px;margin:0px}\r\ntd.gsc-search-button input.gsc-search-button {background-color:#4CAF50;border-color:#4CAF50}\r\ntd.gsc-search-button input.gsc-search-button:hover {background-color:#46a049;}\r\ninput.gsc-input, .gsc-input-box, .gsc-input-box-hover, .gsc-input-box-focus, .gsc-search-button {\r\nbox-sizing:content-box; line-height:normal;}\r\n.gsc-tabsArea div {overflow:visible;}\r\n/*\"nullstille\" w3css:*/\r\n.w3-main{transition:margin-left 0s;}\r\n/*\"nullstilling\" slutt*/\r\n@media (min-width:1675px) {\r\n#main {width:79%}\r\n#right {width:21%}\r\n}\r\n@media (max-width:992px) {\r\n.top {height:100px}\r\n.top img {display:block;margin:auto;}\r\n.top .w3schools-logo {position:relative;top:0;width:100%;text-align:center;margin:auto}\r\n.toptext {width:100%;text-align:center}\r\n#sidenav {width:260px;}\r\n#sidenav h2 {font-size:26px;width:100%;}\r\n#sidenav a {padding:3px 2px 3px 24px;font-size:17px}\r\n#leftmenuinner {  \r\nbox-shadow:0 3px 6px rgba(0,0,0,0.16), 0 3px 6px rgba(0,0,0,0.23);\r\noverflow:auto;\r\n-webkit-overflow-scrolling:touch;\r\nheight:100%;\r\nposition:relative;\r\nwidth:auto;\r\npadding-top:0;\r\nbackground-color:#f1f1f1;\r\n}\r\n#leftmenuinnerinner {overflow-y:scroll}\r\n.bottomad {float:none;text-align:center}\r\n#skyscraper {min-height:60px}\r\n}\r\n@media screen and (max-width:600px) {\r\n.top {height:68px}\r\n.toptext {display:none}\r\n}\r\n@font-face {\r\nfont-family:'fontawesome';\r\nsrc: url('../lib/fonts/fontawesome.eot?14663396');\r\nsrc:url('../lib/fonts/fontawesome.eot?14663396#iefix') format('embedded-opentype'),\r\nurl('../lib/fonts/fontawesome.woff?14663396') format('woff'),\r\nurl('../lib/fonts/fontawesome.ttf?14663396') format('truetype'),\r\nurl('../lib/fonts/fontawesome.svg?14663396#fontawesome') format('svg');\r\nfont-weight:normal;\r\nfont-style:normal;\r\n}\r\n.fa {\r\ndisplay:inline-block;\r\nfont:normal normal normal 14px/1 FontAwesome;\r\nfont-size:inherit;\r\ntext-rendering:auto;\r\n-webkit-font-smoothing:antialiased;\r\n-moz-osx-font-smoothing:grayscale;\r\ntransform:translate(0, 0);\r\n}\r\n.fa-2x {\r\n font-size:2em;\r\n}\r\n.fa-home:before {content:'\\e800';}\r\n.fa-menu:before {content: '\\f0c9';}\r\n.fa-globe:before {content:'\\e801';}\r\n.fa-search:before {content:'\\e802'; }\r\n.fa-thumbs-o-up:before {content:'\\e803';}\r\n.fa-left-open:before {content:'\\e804';}\r\n.fa-right-open:before {content:'\\e805';}\r\n.fa-facebook-square:before {content:'\\e806';}\r\n.fa-google-plus-square:before {content:'\\e807';}\r\n.fa-twitter-square:before {content:'\\e808';}\r\n.fa-caret-down:before {content:'\\e809';}\r\n.fa-caret-up:before {content:'\\e80a';}\r\nspan.marked, span.deprecated {\r\n color:#e80000;\r\n background-color:transparent;\r\n}\r\n.intro {font-size:16px}\r\n.w3-btn, .w3-btn:link, .w3-btn:visited {color:#FFFFFF;background-color:#4CAF50}\r\na.w3-btn[href*=\"exercise.asp\"] {margin:10px 5px 0 0}\r\na.btnplayit,a.btnplayit:link,a.btnplayit:visited {background-color:#FFAD33;padding:1px 10px 2px 10px}\r\na.btnplayit:hover,a.btnplayit:active {background-color:#ffffff;color:#FFAD33}\r\na.btnplayit:hover {box-shadow:0 4px 8px 0 rgba(0,0,0,0.2);}\r\na.btnsmall:link,a.btnsmall:visited,a.btnsmall:active,a.btnsmall:hover {\r\nfloat:right;padding:1px 10px 2px 10px;font:15px Verdana, sans-serif;}\r\na.btnsmall:hover {box-shadow:0 4px 8px 0 rgba(0,0,0,0.2);}\r\na.btnsmall:active,a.btnsmall:hover {color:#4CAF50;background-color:#ffffff}\r\n@media screen and (max-width:700px) {\r\n#mainLeaderboard {height:60px}\r\n#div-gpt-ad-1422003450156-0 {float:none;margin-left:auto;margin-right:auto}\r\n#div-gpt-ad-1422003450156-3 {float:none;margin-left:auto;margin-right:auto}\r\n}\r\n@media (max-width:1600px) {#topnav .w3-bar:nth-of-type(1) a:nth-of-type(16){display:none;}}\r\n@media (max-width:1500px) {#topnav .w3-bar:nth-of-type(1) a:nth-of-type(12){display:none;}}\r\n@media (max-width:1410px) {#topnav .w3-bar:nth-of-type(1) a:nth-of-type(11){display:none;}}\r\n@media (max-width:1350px) {#topnav .w3-bar:nth-of-type(1) a:nth-of-type(10){display:none;}}\r\n@media (max-width:1230px) {#topnav .w3-bar:nth-of-type(1) a:nth-of-type(9){display:none;}}\r\n@media (max-width:1140px) {#topnav .w3-bar:nth-of-type(1) a:nth-of-type(8){display:none;}}\r\n@media (max-width:1000px) {#topnav .w3-bar:nth-of-type(1) a:nth-of-type(7){display:none;}}\r\n@media (max-width:992px) {#topnav .w3-bar:nth-of-type(1) a:nth-of-type(6){display:none;}}\r\n@media (max-width:930px) {#topnav .w3-bar:nth-of-type(1) a:nth-of-type(17){display:none;}}\r\n@media (max-width:800px) {#topnav .w3-bar:nth-of-type(1) a:nth-of-type(18){display:none;}}\r\n@media (max-width:650px) {#topnav .w3-bar:nth-of-type(1) a:nth-of-type(5){display:none;} #topnav .w3-bar:nth-of-type(1) a:nth-of-type(15){display:none;}}\r\n@media (max-width:460px) {#topnav .w3-bar:nth-of-type(1) a:nth-of-type(4){display:none;}}\r\n@media (max-width:400px) {#topnav .w3-bar:nth-of-type(1) a:nth-of-type(3){display:none;}}\r\n.w3-note{background-color:#ffffcc;border-left:6px solid #ffeb3b}\r\n.w3-warning{background-color:#ffdddd;border-left:6px solid #f44336}\r\n.w3-info{background-color:#ddffdd;border-left:6px solid #4CAF50}\r\nhr[id^=\"ez-insert-after-placeholder\"] {margin-top: 0;}\r\n"
            script_ "\r\n(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){\r\n(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),\r\nm=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)\r\n})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');\r\nga('create', 'UA-3855518-1', 'auto');\r\nga('require', 'displayfeatures');\r\nga('send', 'pageview');\r\n"
            script_ [ type_ "text/javascript" ] $ "\r\nvar googletag = googletag || {};\r\ngoogletag.cmd = googletag.cmd || [];\r\n(function() {\r\nvar gads = document.createElement('script');\r\ngads.async = true;\r\ngads.type = 'text/javascript';\r\ngads.src = 'https://www.googletagservices.com/tag/js/gpt.js';\r\nvar node = document.getElementsByTagName('script')[0];\r\nnode.parentNode.insertBefore(gads, node);\r\n})();\r\n"
            script_ [ type_ "text/javascript" ] $ "\r\n// GPT slots\r\nvar gptAdSlots = [];\r\ngoogletag.cmd.push(function() {\r\nvar leaderMapping = googletag.sizeMapping().\r\n// Mobile ad\r\naddSize([0, 0], [320, 50]). \r\n// Vertical Tablet ad\r\naddSize([480, 0], [468, 60]). \r\n// Horizontal Tablet\r\naddSize([780, 0], [728, 90]).\r\n// Small Desktop\r\naddSize([993, 0], [468, 60]).\r\n// Normal Desktop\r\naddSize([1150, 0], [728, 90]).\r\n// Large Desktop and bigger ad\r\naddSize([1425, 0], [[728, 90], [970, 90]]).build();\r\ngptAdSlots[0] = googletag.defineSlot('/16833175/MainLeaderboard', [[728, 90], [970, 90]], 'div-gpt-ad-1422003450156-2').\r\ndefineSizeMapping(leaderMapping).addService(googletag.pubads());\r\nvar skyMapping = googletag.sizeMapping().\r\n// Mobile ad\r\naddSize([0, 0], [320, 50]). \r\n// Tablet ad\r\naddSize([975, 0], [120, 600]). \r\n// Desktop\r\naddSize([1135, 0], [160, 600]).   \r\n// Large Desktop\r\naddSize([1675, 0], [[160, 600], [300, 600], [300, 1050]]).build();\r\ngptAdSlots[1] = googletag.defineSlot('/16833175/WideSkyScraper', [[160, 600], [300, 600], [300, 1050]], 'div-gpt-ad-1422003450156-5').\r\ndefineSizeMapping(skyMapping).addService(googletag.pubads());\r\nvar stickyMapping = googletag.sizeMapping().\r\n// Mobile ad\r\naddSize([0, 0], []). \r\n// Tablet ad\r\naddSize([975, 0], [120, 600]). \r\n// Desktop\r\naddSize([1135, 0], [160, 600]).   \r\n// Large Desktop\r\naddSize([1675, 0], [[160, 600], [300, 600], [300, 250]]).build();\r\ngptAdSlots[4] = googletag.defineSlot('/16833175/StickySkyScraper', [[300, 600], [120, 600], [300, 250], [160, 600]], 'div-gpt-ad-1472547360578-0').\r\ndefineSizeMapping(stickyMapping).addService(googletag.pubads());\r\nvar mcontMapping = googletag.sizeMapping().\r\n// Mobile ad\r\naddSize([0, 0], [[300, 250], [336, 280], [320, 50]]). \r\n// Vertical Tablet ad\r\naddSize([490, 0], [[300, 250], [336, 280], [468, 60]]). \r\n// Horizontal Tablet\r\naddSize([750, 0], [728, 90]).\r\n// Small Desktop\r\naddSize([993, 0], [[300, 250], [336, 280], [468, 60]]).\r\n// Normal Desktop\r\naddSize([1135, 0], [728, 90]).\r\n// Large Desktop and bigger ad\r\naddSize([1440, 0], [[728, 90], [970, 90], [970, 250]]).build();\r\ngptAdSlots[5] = googletag.defineSlot('/16833175/MidContent', [[300, 250], [336, 280]], 'div-gpt-ad-1493883843099-0').\r\ndefineSizeMapping(mcontMapping).setCollapseEmptyDiv(true).addService(googletag.pubads());\r\nvar bmrMapping = googletag.sizeMapping().\r\n// Smaller\r\naddSize([0, 0], [[300, 250], [336, 280]]). \r\n// Large Desktop\r\naddSize([1240, 0], [[300, 250], [336, 280], [970, 250]]).build();\r\ngptAdSlots[2] = googletag.defineSlot('/16833175/BottomMediumRectangle', [[300, 250], [336, 280], [970, 250]], 'div-gpt-ad-1422003450156-0').\r\ndefineSizeMapping(bmrMapping).setCollapseEmptyDiv(true).addService(googletag.pubads());\r\nvar rbmrMapping = googletag.sizeMapping().\r\n// Smaller\r\naddSize([0, 0], []). \r\n// Large Desktop\r\naddSize([975, 0], [[300, 250], [336, 280]]).build();\r\ngptAdSlots[3] = googletag.defineSlot('/16833175/RightBottomMediumRectangle', [[300, 250], [336, 280]], 'div-gpt-ad-1422003450156-3').\r\ndefineSizeMapping(rbmrMapping).setCollapseEmptyDiv(true).addService(googletag.pubads());\r\ngoogletag.pubads().setTargeting(\"content\",(function () {\r\n  var folder = location.pathname;\r\n  folder = folder.replace(\"/\", \"\");\r\n  folder = folder.substr(0, folder.indexOf(\"/\"));\r\n  return folder;\r\n})()\r\n);\r\ngoogletag.enableServices();\r\n});\r\n"
            script_ [ type_ "text/javascript" ] $ "\r\nvar stickyadstatus = \"\";\r\nfunction fix_stickyad() {\r\n  var elem = document.getElementById(\"stickyadcontainer\");\r\n  if (!elem) {return false;}\r\n  if (document.getElementById(\"skyscraper\")) {\r\n    var skyWidth = Number(w3_getStyleValue(document.getElementById(\"skyscraper\"), \"width\").replace(\"px\", \"\"));  \r\n    }\r\n  else {\r\n    var skyWidth = Number(w3_getStyleValue(document.getElementById(\"right\"), \"width\").replace(\"px\", \"\"));  \r\n  }\r\n  elem.style.width = skyWidth + \"px\";\r\n  if (window.innerWidth <= 992) {\r\n    elem.style.position = \"\";\r\n    elem.style.top = stickypos + \"px\";\r\n    return false;\r\n  }\r\n  var stickypos = document.getElementById(\"stickypos\").offsetTop;\r\n  var docTop = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop;\r\n  var adHeight = Number(w3_getStyleValue(elem, \"height\").replace(\"px\", \"\"));\r\n  if (stickyadstatus == \"\") {\r\n    if ((stickypos - docTop) < 60) {\r\n      elem.style.position = \"fixed\";\r\n      elem.style.top = \"60px\";\r\n      stickyadstatus = \"sticky\";\r\n    }\r\n  } else {\r\n    if ((docTop + 60) - stickypos < 0) {  \r\n      elem.style.position = \"\";\r\n      elem.style.top = stickypos + \"px\";\r\n      stickyadstatus = \"\";\r\n    }\r\n  }\r\n  if (stickyadstatus == \"sticky\") {\r\n    if ((docTop + adHeight + 60) > document.getElementById(\"footer\").offsetTop) {\r\n      elem.style.position = \"absolute\";\r\n      elem.style.top = (document.getElementById(\"footer\").offsetTop - adHeight) + \"px\";\r\n    } else {\r\n        elem.style.position = \"fixed\";\r\n        elem.style.top = \"60px\";\r\n        stickyadstatus = \"sticky\";\r\n    }\r\n  }\r\n}\r\nfunction w3_getStyleValue(elmnt,style) {\r\n  if (window.getComputedStyle) {\r\n    return window.getComputedStyle(elmnt,null).getPropertyValue(style);\r\n  } else {\r\n    return elmnt.currentStyle[style];\r\n  }\r\n}\r\n"
        body_ $ do
            div_ [ class_ "w3-container top" ] $ do
                a_ [ class_ "w3schools-logo", href_ "//www.w3schools.com" ] $ do
                    "w3schools"
                    span_ [ class_ "dotcom" ] $ ".com"
                div_ [ class_ "w3-right w3-hide-small w3-wide toptext", style_ "font-family:'Segoe UI',Arial,sans-serif" ] $ "THE WORLD'S LARGEST WEB DEVELOPER SITE"
            div_ [ style_ "display:none;position:absolute;z-index:4;right:52px;height:44px;background-color:#5f5f5f;letter-spacing:normal;", id_ "googleSearch" ] $ div_ [ class_ "gcse-search" ] $ ""
            div_ [ style_ "display:none;position:absolute;z-index:3;right:111px;height:44px;background-color:#5f5f5f;text-align:right;padding-top:9px;", id_ "google_translate_element" ] $ ""
            div_ [ class_ "w3-card-2 topnav", id_ "topnav" ] $ div_ [ style_ "overflow:auto;" ] $ do
                div_ [ class_ "w3-bar w3-left", style_ "width:100%;overflow:hidden;height:44px" ] $ do
                    a_ [ href_ "javascript:void(0);", class_ "topnav-icons fa fa-menu w3-hide-large w3-left w3-bar-item w3-button", onclick_ "open_menu()", title_ "Menu" ] $ ""
                    a_ [ href_ "/default.asp", class_ "topnav-icons fa fa-home w3-left w3-bar-item w3-button", title_ "Home" ] $ ""
                    a_ [ class_ "w3-bar-item w3-button", href_ "/html/default.asp", title_ "HTML Tutorial" ] $ "HTML"
                    a_ [ class_ "w3-bar-item w3-button", href_ "/css/default.asp", title_ "CSS Tutorial" ] $ "CSS"
                    a_ [ class_ "w3-bar-item w3-button", href_ "/js/default.asp", title_ "JavaScript Tutorial" ] $ "JAVASCRIPT"
                    a_ [ class_ "w3-bar-item w3-button", href_ "/sql/default.asp", title_ "SQL Tutorial" ] $ "SQL"
                    a_ [ class_ "w3-bar-item w3-button", href_ "/php/default.asp", title_ "PHP Tutorial" ] $ "PHP"
                    a_ [ class_ "w3-bar-item w3-button", href_ "/bootstrap/default.asp", title_ "Bootstrap Tutorial" ] $ "BOOTSTRAP"
                    a_ [ class_ "w3-bar-item w3-button", href_ "/jquery/default.asp", title_ "jQuery Tutorial" ] $ "JQUERY"
                    a_ [ class_ "w3-bar-item w3-button", href_ "/angular/default.asp", title_ "Angular Tutorial" ] $ "ANGULAR"
                    a_ [ class_ "w3-bar-item w3-button", href_ "/w3css/default.asp", title_ "W3.CSS Tutorial" ] $ "W3.CSS"
                    a_ [ class_ "w3-bar-item w3-button", href_ "/xml/default.asp", title_ "XML Tutorial" ] $ "XML"
                    a_ [ class_ "w3-bar-item w3-button", id_ "topnavbtn_tutorials", href_ "javascript:void(0);", onclick_ "w3_open_nav(\"tutorials\")", title_ "Tutorials" ] $ do
                        "MORE "
                        i_ [ class_ "fa fa-caret-down" ] $ ""
                        i_ [ class_ "fa fa-caret-up", style_ "display:none" ] $ ""
                    a_ [ href_ "javascript:void(0);", class_ "topnav-icons fa w3-right w3-bar-item w3-button", onclick_ "open_search(this)", title_ "Search W3Schools" ] $ "\59394"
                    a_ [ href_ "javascript:void(0);", class_ "topnav-icons fa w3-right w3-bar-item w3-button", onclick_ "open_translate(this)", title_ "Translate W3Schools" ] $ "\59394"
                    a_ [ class_ "w3-bar-item w3-button w3-right", href_ "/forum/default.asp" ] $ "FORUM"
                    a_ [ class_ "w3-bar-item w3-button w3-right", id_ "topnavbtn_examples", href_ "javascript:void(0);", onclick_ "w3_open_nav(\"examples\")", title_ "Examples" ] $ do
                        "EXAMPLES "
                        i_ [ class_ "fa fa-caret-down" ] $ ""
                        i_ [ class_ "fa fa-caret-up", style_ "display:none" ] $ ""
                    a_ [ class_ "w3-bar-item w3-button w3-right", id_ "topnavbtn_references", href_ "javascript:void(0);", onclick_ "w3_open_nav(\"references\")", title_ "References" ] $ do
                        "REFERENCES "
                        i_ [ class_ "fa fa-caret-down" ] $ ""
                        i_ [ class_ "fa fa-caret-up", style_ "display:none" ] $ ""
                div_ [ id_ "nav_tutorials", class_ "w3-bar-block w3-card-2", style_ "display:none;" ] $ do
                    span_ [ onclick_ "w3_close_nav(\"tutorials\")", class_ "w3-button w3-xlarge w3-right", style_ "position:absolute;right:0;font-weight:bold;" ] $ "×"
                    div_ [ class_ "w3-row-padding", style_ "padding:24px 48px" ] $ do
                        div_ [ class_ "w3-col l3 m6" ] $ do
                            h3_ "HTML and CSS"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/html/default.asp" ] $ "Learn HTML"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/css/default.asp" ] $ "Learn CSS"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/w3css/default.asp" ] $ "Learn W3.CSS"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/colors/default.asp" ] $ "Learn Colors"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/bootstrap/default.asp" ] $ "Learn Bootstrap 3"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/bootstrap4/default.asp" ] $ "Learn Bootstrap 4"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/graphics/default.asp" ] $ "Learn Graphics"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/icons/default.asp" ] $ "Learn Icons"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/howto/default.asp" ] $ "Learn How To"
                        div_ [ class_ "w3-col l3 m6" ] $ do
                            h3_ "JavaScript"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/js/default.asp" ] $ "Learn JavaScript"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/jquery/default.asp" ] $ "Learn jQuery"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/angular/default.asp" ] $ "Learn AngularJS"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/js/js_json_intro.asp" ] $ "Learn JSON"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/js/js_ajax_intro.asp" ] $ "Learn AJAX"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/w3js/default.asp" ] $ "Learn W3.JS"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/appml/default.asp" ] $ "Learn AppML"
                            div_ [ class_ "w3-hide-small" ] $ do
                                br_ []
                                br_ []
                        div_ [ class_ "w3-col l3 m6" ] $ do
                            h3_ "Server Side"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/sql/default.asp" ] $ "Learn SQL"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/php/default.asp" ] $ "Learn PHP"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/asp/default.asp" ] $ "Learn ASP"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/nodejs/default.asp" ] $ "Learn Node.js"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/nodejs/nodejs_raspberrypi.asp" ] $ "Learn Raspberry Pi"
                            h3_ "Web Building"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/w3css/w3css_templates.asp" ] $ "Web Templates"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/browsers/default.asp" ] $ "Web Statistics"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/cert/default.asp" ] $ "Web Certificates"
                        div_ [ class_ "w3-col l3 m6" ] $ do
                            h3_ "XML"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/xml/default.asp" ] $ "Learn XML"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/xml/ajax_intro.asp" ] $ "Learn XML AJAX"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/xml/dom_intro.asp" ] $ "Learn XML DOM"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/xml/xml_dtd_intro.asp" ] $ "Learn XML DTD"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/xml/schema_intro.asp" ] $ "Learn XML Schema"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/xml/xsl_intro.asp" ] $ "Learn XSLT"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/xml/xpath_intro.asp" ] $ "Learn XPath"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/xml/xquery_intro.asp" ] $ "Learn XQuery"
                    br_ []
                div_ [ id_ "nav_references", class_ "w3-bar-block w3-card-2" ] $ do
                    span_ [ onclick_ "w3_close_nav(\"references\")", class_ "w3-button w3-xlarge w3-right", style_ "position:absolute;right:0;font-weight:bold;" ] $ "×"
                    div_ [ class_ "w3-row-padding", style_ "padding:24px 48px" ] $ do
                        div_ [ class_ "w3-col m4" ] $ do
                            h3_ "HTML"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/tags/default.asp" ] $ "HTML Tag Reference"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/tags/ref_eventattributes.asp" ] $ "HTML Event Reference"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/colors/default.asp" ] $ "HTML Color Reference"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/tags/ref_attributes.asp" ] $ "HTML Attribute Reference"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/tags/ref_canvas.asp" ] $ "HTML Canvas Reference"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/graphics/svg_reference.asp" ] $ "HTML SVG Reference"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/graphics/google_maps_reference.asp" ] $ "Google Maps Reference"
                            h3_ "CSS"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/cssref/default.asp" ] $ "CSS Reference"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/cssref/css_selectors.asp" ] $ "CSS Selector Reference"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/w3css/w3css_references.asp" ] $ "W3.CSS Reference"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/bootstrap/bootstrap_ref_all_classes.asp" ] $ "Bootstrap Reference"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/icons/icons_reference.asp" ] $ "Icon Reference"
                        div_ [ class_ "w3-col m4" ] $ do
                            h3_ "JavaScript"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/jsref/default.asp" ] $ "JavaScript Reference"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/jsref/default.asp" ] $ "HTML DOM Reference"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/jquery/jquery_ref_selectors.asp" ] $ "jQuery Reference"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/angular/angular_ref_directives.asp" ] $ "AngularJS Reference"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/w3js/w3js_references.asp" ] $ "W3.JS Reference"
                            h3_ "XML"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/xml/dom_nodetype.asp" ] $ "XML Reference"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/xml/dom_http.asp" ] $ "XML Http Reference"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/xml/xsl_elementref.asp" ] $ "XSLT Reference"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/xml/schema_elements_ref.asp" ] $ "XML Schema Reference"
                        div_ [ class_ "w3-col m4" ] $ do
                            h3_ "Charsets"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/charsets/default.asp" ] $ "HTML Character Sets"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/charsets/ref_html_ascii.asp" ] $ "HTML ASCII"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/charsets/ref_html_ansi.asp" ] $ "HTML ANSI"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/charsets/ref_html_ansi.asp" ] $ "HTML Windows-1252"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/charsets/ref_html_8859.asp" ] $ "HTML ISO-8859-1"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/charsets/ref_html_symbols.asp" ] $ "HTML Symbols"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/charsets/ref_html_utf8.asp" ] $ "HTML UTF-8"
                            h3_ "Server Side"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/php/php_ref_array.asp" ] $ "PHP Reference"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/sql/sql_quickref.asp" ] $ "SQL Reference"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/asp/asp_ref_response.asp" ] $ "ASP Reference"
                    br_ []
                div_ [ id_ "nav_examples", class_ "w3-bar-block w3-card-2" ] $ do
                    span_ [ onclick_ "w3_close_nav(\"examples\")", class_ "w3-button w3-xlarge w3-right", style_ "position:absolute;right:0;font-weight:bold;" ] $ "×"
                    div_ [ class_ "w3-row-padding", style_ "padding:24px 48px" ] $ do
                        div_ [ class_ "w3-col l3 m6" ] $ do
                            h3_ "HTML/CSS"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/html/html_examples.asp" ] $ "HTML Examples"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/css/css_examples.asp" ] $ "CSS Examples"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/w3css/w3css_examples.asp" ] $ "W3.CSS Examples"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/w3css/w3css_templates.asp" ] $ "W3.CSS Templates"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/bootstrap/bootstrap_examples.asp" ] $ "Bootstrap Examples"
                        div_ [ class_ "w3-col l3 m6" ] $ do
                            h3_ "JavaScript"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/js/js_examples.asp", target_ "_top" ] $ "JavaScript Examples"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/js/js_dom_examples.asp", target_ "_top" ] $ "HTML DOM Examples"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/jquery/jquery_examples.asp", target_ "_top" ] $ "jQuery Examples"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/angular/angular_examples.asp", target_ "_top" ] $ "AngularJS Examples"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/js/js_ajax_examples.asp", target_ "_top" ] $ "AJAX Examples"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/w3js/w3js_examples.asp" ] $ "W3.JS Examples"
                        div_ [ class_ "w3-col l3 m6" ] $ do
                            h3_ "Server Side"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/php/php_examples.asp", target_ "_top" ] $ "PHP Examples"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/asp/asp_examples.asp", target_ "_top" ] $ "ASP Examples"
                            h3_ "XML"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/xml/xml_examples.asp", target_ "_top" ] $ "XML Examples"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/xml/xsl_examples.asp", target_ "_top" ] $ "XSLT Examples"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/xml/xpath_examples.asp", target_ "_top" ] $ "XPath Examples"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/xml/schema_example.asp", target_ "_top" ] $ "XML Schema Examples"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/graphics/svg_examples.asp", target_ "_top" ] $ "SVG Examples"
                        div_ [ class_ "w3-col l3 m6" ] $ do
                            h3_ "Quizzes"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/quiztest/quiztest.asp?Qtest=HTML", target_ "_top" ] $ "HTML Quiz"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/quiztest/quiztest.asp?Qtest=CSS", target_ "_top" ] $ "CSS Quiz"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/quiztest/quiztest.asp?Qtest=JavaScript", target_ "_top" ] $ "JavaScript Quiz"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/quiztest/quiztest.asp?Qtest=Bootstrap", target_ "_top" ] $ "Bootstrap Quiz"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/quiztest/quiztest.asp?Qtest=jQuery", target_ "_top" ] $ "jQuery Quiz"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/quiztest/quiztest.asp?Qtest=PHP", target_ "_top" ] $ "PHP Quiz"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/quiztest/quiztest.asp?Qtest=SQL", target_ "_top" ] $ "SQL Quiz"
                            a_ [ class_ "w3-bar-item w3-button", href_ "/quiztest/quiztest.asp?Qtest=XML", target_ "_top" ] $ "XML Quiz"
                    br_ []
            div_ [ class_ "w3-sidebar w3-collapse", id_ "sidenav" ] $ div_ [ id_ "leftmenuinner" ] $ div_ [ class_ "w3-light-grey", id_ "leftmenuinnerinner" ] $ do
                a_ [ href_ "javascript:void(0)", onclick_ "close_menu()", class_ "w3-button w3-hide-large w3-large w3-display-topright", style_ "right:16px;padding:3px 12px;font-weight:bold;" ] $ "×"
                h2_ [ class_ "left" ] $ "HTML Graphics"
                a_ [ target_ "_top", href_ "default.asp" ] $ "Graphics HOME"
                br_ []
                h2_ [ class_ "left" ] $ "Google Maps"
                a_ [ target_ "_top", href_ "google_maps_intro.asp" ] $ "Maps Intro"
                a_ [ target_ "_top", href_ "google_maps_basic.asp" ] $ "Maps Basic"
                a_ [ target_ "_top", href_ "google_maps_overlays.asp" ] $ "Maps Overlays"
                a_ [ target_ "_top", href_ "google_maps_events.asp" ] $ "Maps Events"
                a_ [ target_ "_top", href_ "google_maps_controls.asp" ] $ "Maps Controls"
                a_ [ target_ "_top", href_ "google_maps_types.asp" ] $ "Maps Types"
                a_ [ target_ "_top", href_ "google_maps_reference.asp" ] $ "Maps Reference"
                br_ []
                h2_ [ class_ "left" ] $ "SVG Tutorial"
                a_ [ target_ "_top", href_ "svg_intro.asp" ] $ "SVG Intro"
                a_ [ target_ "_top", href_ "svg_inhtml.asp" ] $ "SVG in HTML5"
                a_ [ target_ "_top", href_ "svg_rect.asp" ] $ "SVG Rectangle"
                a_ [ target_ "_top", href_ "svg_circle.asp" ] $ "SVG Circle"
                a_ [ target_ "_top", href_ "svg_ellipse.asp" ] $ "SVG Ellipse"
                a_ [ target_ "_top", href_ "svg_line.asp" ] $ "SVG Line"
                a_ [ target_ "_top", href_ "svg_polygon.asp" ] $ "SVG Polygon"
                a_ [ target_ "_top", href_ "svg_polyline.asp" ] $ "SVG Polyline"
                a_ [ target_ "_top", href_ "svg_path.asp" ] $ "SVG Path"
                a_ [ target_ "_top", href_ "svg_text.asp" ] $ "SVG Text"
                a_ [ target_ "_top", href_ "svg_stroking.asp" ] $ "SVG Stroking"
                a_ [ target_ "_top", href_ "svg_filters_intro.asp" ] $ "SVG Filters Intro"
                a_ [ target_ "_top", href_ "svg_fegaussianblur.asp" ] $ "SVG Blur Effects"
                a_ [ target_ "_top", href_ "svg_feoffset.asp" ] $ "SVG Drop Shadows"
                a_ [ target_ "_top", href_ "svg_grad_linear.asp" ] $ "SVG Linear"
                a_ [ target_ "_top", href_ "svg_grad_radial.asp" ] $ "SVG Radial"
                a_ [ target_ "_top", href_ "svg_examples.asp" ] $ "SVG Examples"
                a_ [ target_ "_top", href_ "svg_reference.asp" ] $ "SVG Reference"
                br_ []
                h2_ [ class_ "left" ] $ "Canvas Tutorial"
                a_ [ target_ "_top", href_ "canvas_intro.asp" ] $ "Canvas Intro"
                a_ [ target_ "_top", href_ "canvas_drawing.asp" ] $ "Canvas Drawing"
                a_ [ target_ "_top", href_ "canvas_coordinates.asp" ] $ "Canvas Coordinates"
                a_ [ target_ "_top", href_ "canvas_gradients.asp" ] $ "Canvas Gradients"
                a_ [ target_ "_top", href_ "canvas_text.asp" ] $ "Canvas Text"
                a_ [ target_ "_top", href_ "canvas_images.asp" ] $ "Canvas Images"
                a_ [ target_ "_top", href_ "canvas_reference.asp" ] $ "Canvas Reference"
                br_ []
                h2_ [ class_ "left" ] $ "Canvas Clock"
                a_ [ target_ "_top", href_ "canvas_clock.asp" ] $ "Clock Intro"
                a_ [ target_ "_top", href_ "canvas_clock_face.asp" ] $ "Clock Face"
                a_ [ target_ "_top", href_ "canvas_clock_numbers.asp" ] $ "Clock Numbers"
                a_ [ target_ "_top", href_ "canvas_clock_hands.asp" ] $ "Clock Hands"
                a_ [ target_ "_top", href_ "canvas_clock_start.asp" ] $ "Clock Start"
                br_ []
                h2_ [ class_ "left" ] $ "HTML Game"
                a_ [ target_ "_top", href_ "game_intro.asp" ] $ "Game Intro"
                a_ [ target_ "_top", href_ "game_canvas.asp" ] $ "Game Canvas"
                a_ [ target_ "_top", href_ "game_components.asp" ] $ "Game Components"
                a_ [ target_ "_top", href_ "game_controllers.asp" ] $ "Game Controllers"
                a_ [ target_ "_top", href_ "game_obstacles.asp" ] $ "Game Obstacles"
                a_ [ target_ "_top", href_ "game_score.asp" ] $ "Game Score"
                a_ [ target_ "_top", href_ "game_images.asp" ] $ "Game Images"
                a_ [ target_ "_top", href_ "game_sound.asp" ] $ "Game Sound"
                a_ [ target_ "_top", href_ "game_gravity.asp" ] $ "Game Gravity"
                a_ [ target_ "_top", href_ "game_bouncing.asp" ] $ "Game Bouncing"
                a_ [ target_ "_top", href_ "game_rotation.asp" ] $ "Game Rotation"
                a_ [ target_ "_top", href_ "game_movement.asp" ] $ "Game Movement"
                br_ []
                br_ []
            div_ [ class_ "w3-main w3-light-grey", id_ "belowtopnav", style_ "margin-left:220px;" ] $ do
                div_ [ class_ "w3-row w3-white" ] $ do
                    div_ [ class_ "w3-col l10 m12", id_ "main" ] $ do
                        div_ [ id_ "mainLeaderboard", style_ "overflow:hidden;" ] $ do
                            toHtmlRaw  "<!-- MainLeaderboard-->"
                            div_ [ id_ "div-gpt-ad-1422003450156-2" ] $ script_ [ type_ "text/javascript" ] $ "googletag.cmd.push(function() { googletag.display('div-gpt-ad-1422003450156-2'); });"
                        h1_ $ do
                            "SVG "
                            span_ [ class_ "color_h1" ] $ "Reference"
                        div_ [ class_ "w3-clear nextprev" ] $ do
                            a_ [ class_ "w3-left w3-btn", href_ "svg_examples.asp" ] $ "❮ Previous"
                            a_ [ class_ "w3-right w3-btn", href_ "canvas_intro.asp" ] $ "Next ❯"
                        hr_ []
                        h2_ "SVG Elements"
                        div_ [ class_ "w3-responsive" ] $ table_ [ class_ "w3-table-all notranslate" ] $ do
                            tr_ $ do
                                th_ [ style_ "width:20%" ] $ "Element"
                                th_ [ style_ "width:30%" ] $ "Description"
                                th_ "Attributes"
                            tr_ $ do
                                td_ "<a>"
                                td_ "Creates a link around SVG elements"
                                td_ $ do
                                    "xlink:show"
                                    br_ []
                                    "\r\n xlink:actuate"
                                    br_ []
                                    "\r\n xlink:href"
                                    br_ []
                                    "\r\n target"
                            tr_ $ do
                                td_ "<altGlyph>"
                                td_ "Provides control over the glyphs used to render particular character data"
                                td_ $ do
                                    "x"
                                    br_ []
                                    "\r\n y"
                                    br_ []
                                    "\r\n dx"
                                    br_ []
                                    "\r\n dy"
                                    br_ []
                                    "\r\n rotate"
                                    br_ []
                                    "\r\n glyphRef"
                                    br_ []
                                    "\r\n format"
                                    br_ []
                                    "\r\n xlink:href"
                            tr_ $ do
                                td_ "<altGlyphDef>"
                                td_ "Defines a substitution set for glyphs"
                                td_ "id"
                            tr_ $ do
                                td_ "<altGlyphItem>"
                                td_ "Defines a candidate set of glyph substitutions"
                                td_ "id"
                            tr_ $ do
                                td_ "<animate>"
                                td_ "Defines how an attribute of an element changes over time"
                                td_ $ do
                                    "attributeName=\"the name of the target attribute\""
                                    br_ []
                                    "by=\"a relative offset value\""
                                    br_ []
                                    "\r\n from=\"the starting value\""
                                    br_ []
                                    "\r\n to=\"the ending value\""
                                    br_ []
                                    "\r\n dur=\"the duration\""
                                    br_ []
                                    "\r\n repeatCount=\"the number of time the animation will take place\""
                            tr_ $ do
                                td_ "<animateMotion>"
                                td_ "Causes a referenced element to move along a motion path"
                                td_ $ do
                                    "calcMode=\"the interpolation mode for the animation. Can be 'discrete', 'linear', 'paced', 'spline'\""
                                    br_ []
                                    "\r\n path=\"the motion path\""
                                    br_ []
                                    "\r\n keyPoints=\"how far along the motion path the object shall move at the moment in time\""
                                    br_ []
                                    "\r\n rotate=\"applies a rotation transformation\""
                                    br_ []
                                    "\r\n xlink:href=\"an URI reference to the <path> element which defines the motion path\""
                            tr_ $ do
                                td_ "<animateTransform>"
                                td_ "Animates a transformation attribute on a target element, thereby allowing animations to control translation, scaling, rotation and/or skewing"
                                td_ $ do
                                    "by=\"a relative offset value\""
                                    br_ []
                                    "\r\n from=\"the starting value\""
                                    br_ []
                                    "\r\n to=\"the ending value\""
                                    br_ []
                                    "\r\n type=\"the type of transformation which is to have its values change over time. Can be 'translate', 'scale', 'rotate', 'skewX', 'skewY'\""
                            tr_ $ do
                                td_ "<circle>"
                                td_ "Defines a circle"
                                td_ $ do
                                    "cx=\"the x-axis center of the circle\""
                                    br_ []
                                    "\r\n cy=\"the y-axis center of the circle\""
                                    br_ []
                                    "\r\n r=\"The circle's radius\". Required."
                                    br_ []
                                    br_ []
                                    "\r\n + presentation attributes:"
                                    br_ []
                                    "\r\n Color, FillStroke, Graphics"
                            tr_ $ do
                                td_ "<clipPath>"
                                td_ "Clipping is about hiding what normally would be drawn. The stencil which defines what is and what isn't drawn is called a clipping path"
                                td_ $ do
                                    "clip-path=\"the referenced clipping path is intersected with the referencing clipping path\""
                                    br_ []
                                    "\r\n clipPathUnits=\"'userSpaceOnUse' or 'objectBoundingBox'. The second value makes units of children a fraction of the object bounding box which uses the mask (default: 'userSpaceOnUse')\""
                            tr_ $ do
                                td_ "<color-profile>"
                                td_ "Specifies a color profile description (when the document is styled using CSS)"
                                td_ $ do
                                    "local=\"the unique ID for a locally stored color profile\""
                                    br_ []
                                    "\r\n name=\"\""
                                    br_ []
                                    "\r\n rendering-intent=\"auto|perceptual|relative-colorimetric|saturation|absolute-colorimetric\""
                                    br_ []
                                    "\r\n xlink:href=\"the URI of an ICC profile resource\""
                            tr_ $ do
                                td_ "<cursor>"
                                td_ "Defines a platform-independent custom cursor"
                                td_ $ do
                                    "x=\"the x-axis top-left corner of the cursor (default is 0)\""
                                    br_ []
                                    "\r\n y=\"the y-axis top-left corner of the cursor (default is 0)\""
                                    br_ []
                                    "\r\n xlink:href=\"the URI of the image to use as the cursor"
                            tr_ $ do
                                td_ "<defs>"
                                td_ "A container for referenced elements"
                                td_ ""
                            tr_ $ do
                                td_ "<desc>"
                                td_ "A text-only description for container elements or graphic elements in SVG (user agents may display the text \r\n    as a tooltip)"
                                td_ ""
                            tr_ $ do
                                td_ "<ellipse>"
                                td_ "Defines an ellipse"
                                td_ $ do
                                    "cx=\"the x-axis center of the ellipse\""
                                    br_ []
                                    "\r\n cy=\"the y-axis center of the ellipse\""
                                    br_ []
                                    "\r\n rx=\"the length of the ellipse's radius along the x-axis\". Required."
                                    br_ []
                                    "\r\n ry=\"the length of the ellipse's radius along the y-axis\". Required."
                                    br_ []
                                    br_ []
                                    "\r\n + presentation attributes:"
                                    br_ []
                                    "\r\n Color, FillStroke, Graphics"
                            tr_ $ do
                                td_ "<feBlend>"
                                td_ "Composes two objects together according to a certain blending mode"
                                td_ $ do
                                    "mode=\"the image blending modes: normal|multiply|screen|darken|lighten\""
                                    br_ []
                                    "\r\n in=\"identifies input for the given filter primitive: SourceGraphic | SourceAlpha | BackgroundImage | BackgroundAlpha | FillPaint | StrokePaint | <filter-primitive-reference>\""
                                    br_ []
                                    "\r\n in2=\"the second input image to the blending operation\""
                            tr_ $ do
                                td_ "feColorMatrix"
                                td_ "SVG filter. Applies a matrix transformation"
                                td_ ""
                            tr_ $ do
                                td_ "feComponentTransfer"
                                td_ "SVG filter. Performs component-wise remapping of data"
                                td_ ""
                            tr_ $ do
                                td_ "feComposite"
                                td_ "SVG filter."
                                td_ ""
                            tr_ $ do
                                td_ "feConvolveMatrix"
                                td_ "SVG filter."
                                td_ ""
                            tr_ $ do
                                td_ "feDiffuseLighting"
                                td_ "SVG filter."
                                td_ ""
                            tr_ $ do
                                td_ "feDisplacementMap"
                                td_ "SVG filter."
                                td_ ""
                            tr_ $ do
                                td_ "feDistantLight"
                                td_ "SVG filter. Defines a light source"
                                td_ ""
                            tr_ $ do
                                td_ "feFlood"
                                td_ "SVG filter."
                                td_ ""
                            tr_ $ do
                                td_ "feFuncA"
                                td_ "SVG filter. Sub-element to feComponentTransfer"
                                td_ ""
                            tr_ $ do
                                td_ "feFuncB"
                                td_ "SVG filter. Sub-element to feComponentTransfer"
                                td_ ""
                            tr_ $ do
                                td_ "feFuncG"
                                td_ "SVG filter. Sub-element to feComponentTransfer"
                                td_ ""
                            tr_ $ do
                                td_ "feFuncR"
                                td_ "SVG filter. Sub-element to feComponentTransfer"
                                td_ ""
                            tr_ $ do
                                td_ "feGaussianBlur"
                                td_ "SVG filter. Performs a Gaussian blur on the image"
                                td_ ""
                            tr_ $ do
                                td_ "feImage"
                                td_ "SVG filter."
                                td_ ""
                            tr_ $ do
                                td_ "feMerge"
                                td_ "SVG filter. Creates image layers on top of each \r\nother"
                                td_ ""
                            tr_ $ do
                                td_ "feMergeNode"
                                td_ "SVG filter. Sub-element to feMerge"
                                td_ ""
                            tr_ $ do
                                td_ "feMorphology"
                                td_ "SVG filter. Performs a \"fattening\" or \"thinning\" on a \r\n    source graphic"
                                td_ ""
                            tr_ $ do
                                td_ "feOffset"
                                td_ "SVG filter. Moves an image relative to its current position"
                                td_ ""
                            tr_ $ do
                                td_ "fePointLight"
                                td_ "SVG filter."
                                td_ ""
                            tr_ $ do
                                td_ "feSpecularLighting"
                                td_ "SVG filter."
                                td_ ""
                            tr_ $ do
                                td_ "feSpotLight"
                                td_ "SVG filter."
                                td_ ""
                            tr_ $ do
                                td_ "feTile"
                                td_ "SVG filter."
                                td_ ""
                            tr_ $ do
                                td_ "feTurbulence"
                                td_ "SVG filter."
                                td_ ""
                            tr_ $ do
                                td_ "filter"
                                td_ "Container for filter effects"
                                td_ ""
                            tr_ $ do
                                td_ "font"
                                td_ "Defines a font"
                                td_ ""
                            tr_ $ do
                                td_ "font-face"
                                td_ "Describes the characteristics of a font"
                                td_ ""
                            tr_ $ do
                                td_ "font-face-format"
                                td_ ""
                                td_ ""
                            tr_ $ do
                                td_ "font-face-name"
                                td_ ""
                                td_ ""
                            tr_ $ do
                                td_ "font-face-src"
                                td_ ""
                                td_ ""
                            tr_ $ do
                                td_ "font-face-uri"
                                td_ ""
                                td_ ""
                            tr_ $ do
                                td_ "foreignObject"
                                td_ ""
                                td_ ""
                            tr_ $ do
                                td_ "<g>"
                                td_ "Used to group together   \r\n    elements"
                                td_ $ do
                                    "id=\"the name of the group\""
                                    br_ []
                                    "\r\n fill=\"the fill color for the group\""
                                    br_ []
                                    "\r\n opacity=\"the opacity for the group\""
                                    br_ []
                                    br_ []
                                    "\r\n + presentation attributes:"
                                    br_ []
                                    "\r\n All"
                            tr_ $ do
                                td_ "glyph"
                                td_ "Defines the graphics for a given glyph"
                                td_ ""
                            tr_ $ do
                                td_ "glyphRef"
                                td_ "Defines a possible glyph to use"
                                td_ ""
                            tr_ $ do
                                td_ "hkern"
                                td_ ""
                                td_ ""
                            tr_ $ do
                                td_ "<image>"
                                td_ "Defines an image"
                                td_ $ do
                                    "x=\"the x-axis top-left corner of the image\""
                                    br_ []
                                    "\r\n y=\"the y-axis top-left corner of the image\""
                                    br_ []
                                    "\r\n width=\"the width of the image\". Required."
                                    br_ []
                                    "\r\n height=\"the height of the image\". Required."
                                    br_ []
                                    "\r\n xlink:href=\"the path to the image\". Required."
                                    br_ []
                                    br_ []
                                    "\r\n + presentation attributes:"
                                    br_ []
                                    "\r\n Color, Graphics, Images, Viewports"
                            tr_ $ do
                                td_ "<line>"
                                td_ "Defines a line"
                                td_ $ do
                                    "x1=\"the x start point of the line\""
                                    br_ []
                                    "\r\n y1=\"the y start point of the line\""
                                    br_ []
                                    "\r\n x2=\"the x end point of the line\""
                                    br_ []
                                    "\r\n y2=\"the y end point of the line\""
                                    br_ []
                                    br_ []
                                    "\r\n + presentation attributes:"
                                    br_ []
                                    "\r\n Color, FillStroke, Graphics, Markers"
                            tr_ $ do
                                td_ "<linearGradient>"
                                td_ "Defines a linear gradient. Linear gradients fill the object by using a vector, and can be defined as horizontal, vertical or angular gradients."
                                td_ $ do
                                    "id=\"the unique id used to reference this pattern. Required to reference it\""
                                    br_ []
                                    "\r\n gradientUnits=\"'userSpaceOnUse' or 'objectBoundingBox'. Use the view box or object to determine relative position of vector points. (Default 'objectBoundingBox')\""
                                    br_ []
                                    "\r\n gradientTransform=\"the transformation to apply to the gradient\""
                                    br_ []
                                    "\r\n x1=\"the x start point of the gradient vector (number or % - 0% is default)\""
                                    br_ []
                                    "\r\n y1=\"the y start point of the gradient vector. (0% default)\" "
                                    br_ []
                                    "\r\n x2=\"the x end point of the gradient vector. (100% default)\""
                                    br_ []
                                    "\r\n y2=\"the y end point of the gradient vector. (0% default)\" "
                                    br_ []
                                    "\r\n spreadMethod=\"'pad' or 'reflect' or 'repeat'\""
                                    br_ []
                                    "\r\n xlink:href=\"reference to another gradient whose attribute values are used as defaults and stops included. Recursive\""
                            tr_ $ do
                                td_ "<marker>"
                                td_ "Markers can be placed on the vertices of lines, polylines, polygons and paths. These elements can use the marker attributes \"marker-start\", \"marker-mid\" and \"marker-end\"' which inherit by default or can be set to 'none' or the URI of a defined marker. You must first define the marker before you can reference it via its URI. Any kind of shape can be put inside marker. They are drawn on top of the element they are attached to"
                                td_ $ do
                                    "markerUnits=\"'strokeWidth' or 'userSpaceOnUse'. If 'strokeWidth' is used then one unit equals one stroke width. Otherwise, the marker does not scale and uses the the same view units as the referencing element (default 'strokeWidth')\""
                                    br_ []
                                    "\r\n refx=\"the position where the marker connects with the vertex (default 0)\""
                                    br_ []
                                    "\r\n refy=\"the position where the marker connects with the vertex (default 0)\""
                                    br_ []
                                    "\r\n orient=\"'auto' or an angle to always show the marker at. 'auto' will compute an angle that makes the x-axis a tangent of the vertex (default 0)\""
                                    br_ []
                                    "\r\n markerWidth=\"the width of the marker (default 3)\""
                                    br_ []
                                    "\r\n markerHeight=\"the height of the marker (default 3)\""
                                    br_ []
                                    "\r\n viewBox=\"the points \"seen\" in this SVG drawing area. 4 values separated by white space or commas. (min x, min y, width, height)\" "
                                    br_ []
                                    br_ []
                                    "\r\n + presentation attributes:"
                                    br_ []
                                    "\r\n All"
                            tr_ $ do
                                td_ "<mask>"
                                td_ "Masking is a combination of opacity values and clipping. Like clipping you can use shapes, text or paths to define sections of the mask. The default state of a mask is fully transparent which is the opposite of clipping plane. The graphics in a mask sets how opaque portions of the mask are"
                                td_ $ do
                                    "maskUnits=\"'userSpaceOnUse' or 'objectBoundingBox'. Set whether the clipping plane is relative the full view port or object (default: 'objectBoundingBox')\""
                                    br_ []
                                    "\r\n maskContentUnits=\"Use the second with percentages to make mask graphic positions relative the object. 'userSpaceOnUse' or 'objectBoundingBox' (default: 'userSpaceOnUse')\""
                                    br_ []
                                    "\r\n x=\"the clipping plane of the mask (default: -10%)\" "
                                    br_ []
                                    "\r\n y=\"the clipping plane of the mask (default: -10%)\" "
                                    br_ []
                                    "\r\n width=\"the clipping plane of the mask (default: 120%)\""
                                    br_ []
                                    "\r\n height=\"the clipping plane of the mask (default: 120%)\""
                            tr_ $ do
                                td_ "metadata"
                                td_ "Specifies metadata"
                                td_ ""
                            tr_ $ do
                                td_ "missing-glyph"
                                td_ ""
                                td_ ""
                            tr_ $ do
                                td_ "mpath"
                                td_ ""
                                td_ ""
                            tr_ $ do
                                td_ "<path>"
                                td_ "Defines a path"
                                td_ $ do
                                    "d=\"a set of commands which define the path\""
                                    br_ []
                                    "\r\n pathLength=\"If present, the path will be scaled so that the computed path length of the points equals this value\""
                                    br_ []
                                    "\r\n transform=\"a list of transformations\""
                                    br_ []
                                    br_ []
                                    "\r\n + presentation attributes:"
                                    br_ []
                                    "\r\n Color, FillStroke, Graphics, Markers"
                            tr_ $ do
                                td_ "<pattern>"
                                td_ "Defines the coordinates you want the view to show and the size of the view. Then you add shapes into your pattern. The pattern repeats when an edge of the view box (viewing area) is hit"
                                td_ $ do
                                    "id=\"the unique id used to reference this pattern.\" Required. "
                                    br_ []
                                    "\r\n patternUnits=\"'userSpaceOnUse' or 'objectBoundingBox'. The second value makes units of x, y, width, height a fraction (or %) of the object bounding box which uses the pattern.\""
                                    br_ []
                                    "\r\n patternContentUnits=\"'userSpaceOnUse' or 'objectBoundingBox'\""
                                    br_ []
                                    "\r\n patternTransform=\"allows the whole pattern to be transformed\""
                                    br_ []
                                    "\r\n x=\"pattern's offset from the top-left corner (default 0)\" "
                                    br_ []
                                    "\r\n y=\"pattern's offset from the top-left corner. (default 0)\""
                                    br_ []
                                    "\r\n width=\"the width of the pattern tile (default 100%)\" "
                                    br_ []
                                    "\r\n height=\"the height of the pattern tile (default 100%)\""
                                    br_ []
                                    "\r\n viewBox=\"the points \"seen\" in this SVG drawing area. 4 values separated by white space or commas. (min x, min y, width, height)\" "
                                    br_ []
                                    "\r\n xlink:href=\"reference to another pattern whose attribute values are used as defaults and any children are inherited. Recursive\""
                                    br_ []
                            tr_ $ do
                                td_ "<polygon>"
                                td_ "Defines a graphic that contains at least three sides"
                                td_ $ do
                                    "points=\"the points of the polygon. The total number of points must be even\". Required."
                                    br_ []
                                    "\r\n fill-rule=\"part of the FillStroke presentation attributes\""
                                    br_ []
                                    br_ []
                                    "\r\n + presentation attributes:"
                                    br_ []
                                    "\r\n Color, FillStroke, Graphics, Markers"
                            tr_ $ do
                                td_ "<polyline>"
                                td_ "Defines any shape that consists of only straight lines"
                                td_ $ do
                                    "points=\"the points on the polyline\". Required."
                                    br_ []
                                    br_ []
                                    "\r\n + presentation attributes:"
                                    br_ []
                                    "\r\n Color, FillStroke, Graphics, Markers"
                            tr_ $ do
                                td_ "<radialGradient>"
                                td_ "Defines a radial gradient. Radial gradients are created by taking a circle and smoothly changing values between gradient stops from the focus point to the outside radius."
                                td_ $ do
                                    "gradientUnits=\"'userSpaceOnUse' or 'objectBoundingBox'. Use the view box or object to determine relative position of vector points. (Default 'objectBoundingBox')\""
                                    br_ []
                                    "\r\n gradientTransform=\"the transformation to apply to the gradient\" "
                                    br_ []
                                    "\r\n cx=\"the center point of the gradient (number or % - 50% is default)\""
                                    br_ []
                                    "\r\n cy=\"the center point of the gradient. (50% default)\""
                                    br_ []
                                    "\r\n r=\"the radius of the gradient. (50% default)\" "
                                    br_ []
                                    "\r\n fx=\"the focus point of the gradient. (0% default)\""
                                    br_ []
                                    "\r\n fy=\"The focus point of the gradient. (0% default)\""
                                    br_ []
                                    "\r\n spreadMethod=\"'pad' or 'reflect' or 'repeat'\""
                                    br_ []
                                    "\r\n xlink:href=\"Reference to another gradient whose attribute values are used as defaults and stops included. Recursive\""
                            tr_ $ do
                                td_ "<rect>"
                                td_ "Defines a rectangle"
                                td_ $ do
                                    "x=\"the x-axis top-left corner of the rectangle\""
                                    br_ []
                                    "\r\n y=\"the y-axis top-left corner of the rectangle\""
                                    br_ []
                                    "\r\n rx=\"the x-axis radius (to round the element)\""
                                    br_ []
                                    "\r\n ry=\"the y-axis radius (to round the element)\" "
                                    br_ []
                                    "\r\n width=\"the width of the rectangle\". Required."
                                    br_ []
                                    "\r\n height=\"the height of the rectangle\" Required."
                                    br_ []
                                    br_ []
                                    "\r\n + presentation attributes:"
                                    br_ []
                                    "\r\n Color, FillStroke, Graphics"
                            tr_ $ do
                                td_ "script"
                                td_ "Container for scripts (e.g., ECMAScript)"
                                td_ ""
                            tr_ $ do
                                td_ "set"
                                td_ "Sets the value of an \r\n    attribute for a specified duration"
                                td_ ""
                            tr_ $ do
                                td_ "<stop>"
                                td_ "The stops for a gradient"
                                td_ $ do
                                    "offset=\"the offset for this stop (0 to 1/0% to 100%)\". Required."
                                    br_ []
                                    "\r\n stop-color=\"the color of this stop\" "
                                    br_ []
                                    "\r\n stop-opacity=\"the opacity of this stop (0 to 1)\""
                            tr_ $ do
                                td_ "style"
                                td_ "Allows style sheets to be embedded directly within SVG \r\n    content"
                                td_ ""
                            tr_ $ do
                                td_ "<svg>"
                                td_ "Creates an SVG document fragment"
                                td_ $ do
                                    "x=\"top left corner when embedded (default 0)\""
                                    br_ []
                                    "\r\n y=\"top left corner when embedded (default 0)\""
                                    br_ []
                                    "\r\n width=\"the width of the svg fragment (default 100%)\""
                                    br_ []
                                    "\r\n height=\"the height of the svg fragment (default 100%)\""
                                    br_ []
                                    "\r\n viewBox=\"the points \"seen\" in this SVG drawing area. 4 values separated by white space or commas. (min x, min y, width, height)\""
                                    br_ []
                                    "\r\n preserveAspectRatio=\"'none' or any of the 9 combinations of 'xVALYVAL' where VAL is 'min', 'mid' or 'max'. (default xMidYMid)\""
                                    br_ []
                                    "\r\n zoomAndPan=\"'magnify' or 'disable'. Magnify option allows users to pan and zoom your file (default magnify)\""
                                    br_ []
                                    "\r\n xml=\"outermost <svg> element needs to setup SVG and its namespace: xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" xml:space=\"preserve\"\""
                                    br_ []
                                    br_ []
                                    "\r\n + presentation attributes:"
                                    br_ []
                                    "\r\n All"
                            tr_ $ do
                                td_ "switch"
                                td_ ""
                                td_ ""
                            tr_ $ do
                                td_ "symbol"
                                td_ ""
                                td_ ""
                            tr_ $ do
                                td_ "<text>"
                                td_ "Defines a text"
                                td_ $ do
                                    "x=\"a list of x-axis positions. The nth x-axis position is given to the nth character in the text. If there are additional characters after the positions run out they are placed after the last character. 0 is default\""
                                    br_ []
                                    "\r\n y=\"a list of y-axis positions. (see x). 0 is default\""
                                    br_ []
                                    "\r\n dx=\"a list of lengths which moves the characters relative to the absolute position of the last glyph drawn. (see x)\""
                                    br_ []
                                    "\r\n dy=\"a list of lengths which moves the characters relative to the absolute position of the last glyph drawn. (see x)\" "
                                    br_ []
                                    "\r\n rotate=\"a list of rotations. The nth rotation is performed on the nth character. Additional characters are NOT given the last rotation value\""
                                    br_ []
                                    "\r\n textLength=\"a target length for the text that the SVG viewer will attempt to display the text between by adjusting the spacing and/or the glyphs. (default: The text's normal length)\""
                                    br_ []
                                    "\r\n lengthAdjust=\"tells the viewer what to adjust to try to accomplish rendering the text if the length is specified. The two values are 'spacing' and 'spacingAndGlyphs'\""
                                    br_ []
                                    br_ []
                                    "\r\n + presentation attributes:"
                                    br_ []
                                    "\r\n Color, FillStroke, Graphics, FontSpecification, TextContentElements"
                            tr_ $ do
                                td_ "textPath"
                                td_ ""
                                td_ ""
                            tr_ $ do
                                td_ "title"
                                td_ "A text-only description for elements in SVG - not displayed as part of the \r\n    graphics. User agents may display the text \r\n    as a tooltip"
                                td_ ""
                            tr_ $ do
                                td_ "<tref>"
                                td_ "References any <text> element in the SVG document and reuse it"
                                td_ "Identical to the <text> element"
                            tr_ $ do
                                td_ "<tspan>"
                                td_ "Identical to the <text> element but can be nested inside text tags and inside itself"
                                td_ $ do
                                    "Identical to the <text> element"
                                    br_ []
                                    "\r\n + in addition:"
                                    br_ []
                                    "\r\n xlink:href=\"Reference to a <text> element\" "
                            tr_ $ do
                                td_ "<use>"
                                td_ "Uses a URI to reference a <g>, <svg> or other graphical element with a unique id attribute and replicate it. The copy is only a reference to the original so only the original exists in the document. Any change to the original affects all copies."
                                td_ $ do
                                    "x=\"the x-axis top-left corner of the cloned element\""
                                    br_ []
                                    "\r\n y=\"the y-axis top-left corner of the cloned element\""
                                    br_ []
                                    "\r\n width=\"the width of the cloned element\""
                                    br_ []
                                    "\r\n height=\"the height of the cloned element\""
                                    br_ []
                                    "\r\n xlink:href=\"a URI reference to the cloned element\""
                                    br_ []
                                    br_ []
                                    "\r\n + presentation attributes:"
                                    br_ []
                                    "\r\n All"
                            tr_ $ do
                                td_ "view"
                                td_ ""
                                td_ ""
                            tr_ $ do
                                td_ "vkern"
                                td_ ""
                                td_ ""
                        br_ []
                        div_ [ class_ "w3-clear nextprev" ] $ do
                            a_ [ class_ "w3-left w3-btn", href_ "svg_examples.asp" ] $ "❮ Previous"
                            a_ [ class_ "w3-right w3-btn", href_ "canvas_intro.asp" ] $ "Next ❯"
                    div_ [ class_ "w3-col l2 m12", id_ "right" ] $ do
                        div_ [ class_ "sidesection" ] $ div_ [ id_ "skyscraper" ] $ div_ [ id_ "div-gpt-ad-1422003450156-5" ] $ script_ "\r\n      googletag.cmd.push(function() {\r\n      googletag.display('div-gpt-ad-1422003450156-5');\r\n      });\r\n      "
                        div_ [ class_ "sidesection" ] $ do
                            h4_ $ a_ [ href_ "/colors/colors_picker.asp" ] $ "COLOR PICKER"
                            a_ [ href_ "/colors/colors_picker.asp" ] $ img_ [ src_ "/images/colorpicker.gif", alt_ "colorpicker" ]
                        div_ [ class_ "sidesection", id_ "moreAboutSubject" ] $ ""
                        div_ [ class_ "sidesection" ] $ do
                            h4_ $ a_ [ href_ "/howto/default.asp" ] $ "HOW TO"
                            p_ $ do
                                a_ [ href_ "/howto/howto_js_tabs.asp" ] $ "Tabs"
                                br_ []
                                a_ [ href_ "/howto/howto_css_dropdown.asp" ] $ "Dropdowns"
                                br_ []
                                a_ [ href_ "/howto/howto_js_accordion.asp" ] $ "Accordions"
                                br_ []
                                a_ [ href_ "/howto/howto_js_weight_converter.asp" ] $ "Convert Weights"
                                br_ []
                                a_ [ href_ "/howto/howto_css_animate_buttons.asp" ] $ "Animated Buttons"
                                br_ []
                                a_ [ href_ "/howto/howto_js_sidenav.asp" ] $ "Side Navigation"
                                br_ []
                                a_ [ href_ "/howto/howto_js_topnav.asp" ] $ "Top Navigation"
                                br_ []
                                a_ [ href_ "/howto/howto_css_modals.asp" ] $ "Modal Boxes"
                                br_ []
                                a_ [ href_ "/howto/howto_js_progressbar.asp" ] $ "Progress Bars"
                                br_ []
                                a_ [ href_ "/howto/howto_css_parallax.asp" ] $ "Parallax"
                                br_ []
                                a_ [ href_ "/howto/howto_css_login_form.asp" ] $ "Login Form"
                                br_ []
                                a_ [ href_ "/howto/howto_html_include.asp" ] $ "HTML Includes"
                                br_ []
                                a_ [ href_ "/howto/howto_google_maps.asp" ] $ "Google Maps"
                                br_ []
                                a_ [ href_ "/howto/howto_js_rangeslider.asp" ] $ "Range Sliders"
                                br_ []
                                a_ [ href_ "/howto/howto_css_tooltip.asp" ] $ "Tooltips"
                                br_ []
                                a_ [ href_ "/howto/howto_js_slideshow.asp" ] $ "Slideshow"
                                br_ []
                                a_ [ href_ "/howto/howto_js_filter_lists.asp" ] $ "Filter List"
                                br_ []
                                a_ [ href_ "/howto/howto_js_sort_list.asp" ] $ "Sort List"
                                br_ []
                        div_ [ class_ "sidesection" ] $ do
                            h4_ "SHARE"
                            div_ [ class_ "w3-text-grey sharethis" ] $ do
                                script_ "\r\n<!--\r\ntry{\r\nloc=location.pathname;\r\nif (loc.toUpperCase().indexOf(\".ASP\")<0) loc=loc+\"default.asp\";\r\ntxt='<a href=\"http://www.facebook.com/sharer.php?u=https://www.w3schools.com'+loc+'\" target=\"_blank\" title=\"Facebook\"><span class=\"fa fa-facebook-square fa-2x\"></span></a>';\r\ntxt=txt+'<a href=\"https://twitter.com/home?status=Currently reading https://www.w3schools.com'+loc+'\" target=\"_blank\" title=\"Twitter\"><span class=\"fa fa-twitter-square fa-2x\"></span></a>';\r\ntxt=txt+'<a href=\"https://plus.google.com/share?url=https://www.w3schools.com'+loc+'\" target=\"_blank\" title=\"Google+\"><span class=\"fa fa-google-plus-square fa-2x\"></span></a>';\r\ndocument.write(txt);\r\n} catch(e) {}\r\n//-->\r\n"
                                br_ []
                                br_ []
                                a_ [ href_ "javascript:void(0);", onclick_ "clickFBLike()", title_ "Like W3Schools on Facebook" ] $ span_ [ class_ "fa fa-thumbs-o-up fa-2x" ] $ ""
                                div_ [ id_ "fblikeframe", class_ "w3-modal" ] $ div_ [ class_ "w3-modal-content w3-padding-64 w3-animate-zoom", id_ "popupDIV" ] $ ""
                        div_ [ class_ "sidesection" ] $ do
                            h4_ $ a_ [ target_ "_blank", href_ "//www.w3schools.com/cert/default.asp" ] $ "CERTIFICATES"
                            p_ "HTML, CSS, JavaScript, PHP, jQuery, Bootstrap and XML."
                            a_ [ target_ "_blank", href_ "//www.w3schools.com/cert/default.asp", class_ "w3-button w3-dark-grey", style_ "text-decoration:none" ] $ "\r\nRead More »"
                        div_ [ id_ "stickypos", class_ "sidesection", style_ "text-align:center;" ] $ div_ [ id_ "stickyadcontainer" ] $ div_ [ style_ "position:relative;margin:auto;" ] $ div_ [ id_ "div-gpt-ad-1472547360578-0" ] $ script_ "\r\n        if (Number(w3_getStyleValue(document.getElementById(\"main\"), \"height\").replace(\"px\", \"\")) > 2200) {\r\n        googletag.cmd.push(function() { googletag.display('div-gpt-ad-1472547360578-0'); });\r\n        }\r\n        "
                        script_ "\r\n  window.addEventListener(\"scroll\", fix_stickyad);\r\n  window.addEventListener(\"resize\", fix_stickyad);\r\n"
                div_ [ id_ "footer", class_ "footer w3-container w3-white" ] $ do
                    hr_ []
                    div_ [ style_ "overflow:auto" ] $ do
                        toHtmlRaw  "<!-- BottomMediumRectangle -->"
                        div_ [ class_ "bottomad", id_ "div-gpt-ad-1422003450156-0" ] $ script_ [ type_ "text/javascript" ] $ "\r\n    googletag.cmd.push(function() { googletag.display('div-gpt-ad-1422003450156-0'); });\r\n    "
                        toHtmlRaw  "<!-- RightBottomMediumRectangle -->"
                        div_ [ class_ "bottomad", id_ "div-gpt-ad-1422003450156-3" ] $ script_ [ type_ "text/javascript" ] $ "\r\n    googletag.cmd.push(function() { googletag.display('div-gpt-ad-1422003450156-3'); });\r\n    "
                    hr_ []
                    div_ [ class_ "w3-row w3-center w3-small" ] $ do
                        div_ [ class_ "w3-col l3 m3 s12" ] $ a_ [ href_ "javascript:void(0);", onclick_ "displayError();return false", style_ "white-space:nowrap;" ] $ "REPORT ERROR"
                        div_ [ class_ "w3-col l3 m3 s12" ] $ a_ [ href_ "javascript:void(0);", target_ "_blank", onclick_ "printPage();return false;" ] $ "PRINT PAGE"
                        div_ [ class_ "w3-col l3 m3 s12" ] $ a_ [ href_ "/forum/default.asp", target_ "_blank" ] $ "FORUM"
                        div_ [ class_ "w3-col l3 m3 s12" ] $ a_ [ href_ "/about/default.asp", target_ "_top" ] $ "ABOUT"
                    hr_ []
                    div_ [ class_ "w3-light-grey w3-padding w3-center", id_ "err_form", style_ "display:none;position:relative" ] $ do
                        span_ [ onclick_ "this.parentElement.style.display='none'", class_ "w3-button w3-display-topright" ] $ "×"
                        h2_ "Your Suggestion:"
                        form_ $ do
                            div_ [ class_ "w3-section" ] $ do
                                label_ [ for_ "err_email" ] $ "Your E-mail:"
                                input_ [ class_ "w3-input", type_ "text", style_ "width:100%", id_ "err_email", name_ "err_email" ]
                            div_ [ class_ "w3-section" ] $ do
                                label_ [ for_ "err_email" ] $ "Page address:"
                                input_ [ class_ "w3-input", type_ "text", style_ "width:100%", id_ "err_url", name_ "err_url", disabled_ "disabled" ]
                            div_ [ class_ "w3-section" ] $ do
                                label_ [ for_ "err_email" ] $ "Description:"
                                textarea_ [ rows_ "10", class_ "w3-input", id_ "err_desc", name_ "err_desc", style_ "width:100%;" ] $ ""
                            div_ [ class_ "form-group" ] $ button_ [ type_ "button", onclick_ "sendErr()" ] $ "Submit"
                            br_ []
                    div_ [ class_ "w3-container w3-light-grey w3-padding", id_ "err_sent", style_ "display:none;position:relative" ] $ do
                        span_ [ onclick_ "this.parentElement.style.display='none'", class_ "w3-button w3-display-topright" ] $ "×"
                        h2_ "Thank You For Helping Us!"
                        p_ "Your message has been sent to W3Schools."
                    div_ [ class_ "w3-row w3-center w3-small" ] $ do
                        div_ [ class_ "w3-col l3 m6 s12" ] $ div_ [ class_ "top10" ] $ do
                            h4_ "Top 10 Tutorials"
                            a_ [ href_ "/html/default.asp" ] $ "HTML Tutorial"
                            br_ []
                            a_ [ href_ "/css/default.asp" ] $ "CSS Tutorial"
                            br_ []
                            a_ [ href_ "/js/default.asp" ] $ "JavaScript Tutorial"
                            br_ []
                            a_ [ href_ "/w3css/default.asp" ] $ "W3.CSS Tutorial"
                            br_ []
                            a_ [ href_ "/bootstrap/default.asp" ] $ "Bootstrap Tutorial"
                            br_ []
                            a_ [ href_ "/sql/default.asp" ] $ "SQL Tutorial"
                            br_ []
                            a_ [ href_ "/php/default.asp" ] $ "PHP Tutorial"
                            br_ []
                            a_ [ href_ "/jquery/default.asp" ] $ "jQuery Tutorial"
                            br_ []
                            a_ [ href_ "/angular/default.asp" ] $ "Angular Tutorial"
                            br_ []
                            a_ [ href_ "/xml/default.asp" ] $ "XML Tutorial"
                            br_ []
                        div_ [ class_ "w3-col l3 m6 s12" ] $ div_ [ class_ "top10" ] $ do
                            h4_ "Top 10 References"
                            a_ [ href_ "/tags/default.asp" ] $ "HTML Reference"
                            br_ []
                            a_ [ href_ "/cssref/default.asp" ] $ "CSS Reference"
                            br_ []
                            a_ [ href_ "/jsref/default.asp" ] $ "JavaScript Reference"
                            br_ []
                            a_ [ href_ "/w3css/w3css_references.asp" ] $ "W3.CSS Reference"
                            br_ []
                            a_ [ href_ "/browsers/default.asp" ] $ "Browser Statistics"
                            br_ []
                            a_ [ href_ "/php/php_ref_array.asp" ] $ "PHP Reference"
                            br_ []
                            a_ [ href_ "/colors/colors_names.asp" ] $ "HTML Colors"
                            br_ []
                            a_ [ href_ "/charsets/default.asp" ] $ "HTML Character Sets"
                            br_ []
                            a_ [ href_ "/jquery/jquery_ref_selectors.asp" ] $ "jQuery Reference"
                            br_ []
                            a_ [ href_ "/angular/angular_ref_directives.asp" ] $ "AngularJS Reference"
                            br_ []
                        div_ [ class_ "w3-col l3 m6 s12" ] $ div_ [ class_ "top10" ] $ do
                            h4_ "Top 10 Examples"
                            a_ [ href_ "/html/html_examples.asp" ] $ "HTML Examples"
                            br_ []
                            a_ [ href_ "/css/css_examples.asp" ] $ "CSS Examples"
                            br_ []
                            a_ [ href_ "/js/js_examples.asp" ] $ "JavaScript Examples"
                            br_ []
                            a_ [ href_ "/w3css/w3css_examples.asp" ] $ "W3.CSS Examples"
                            br_ []
                            a_ [ href_ "/js/js_dom_examples.asp" ] $ "HTML DOM Examples"
                            br_ []
                            a_ [ href_ "/php/php_examples.asp" ] $ "PHP Examples"
                            br_ []
                            a_ [ href_ "/asp/asp_examples.asp" ] $ "ASP Examples"
                            br_ []
                            a_ [ href_ "/jquery/jquery_examples.asp" ] $ "jQuery Examples"
                            br_ []
                            a_ [ href_ "/angular/angular_examples.asp" ] $ "Angular Examples"
                            br_ []
                            a_ [ href_ "/xml/xml_examples.asp" ] $ "XML Examples"
                            br_ []
                        div_ [ class_ "w3-col l3 m6 s12" ] $ div_ [ class_ "top10" ] $ do
                            h4_ "Web Certificates"
                            a_ [ href_ "/cert/default.asp" ] $ "HTML Certificate"
                            br_ []
                            a_ [ href_ "/cert/default.asp" ] $ "CSS Certificate"
                            br_ []
                            a_ [ href_ "/cert/default.asp" ] $ "JavaScript Certificate"
                            br_ []
                            a_ [ href_ "/cert/default.asp" ] $ "jQuery Certificate"
                            br_ []
                            a_ [ href_ "/cert/default.asp" ] $ "PHP Certificate"
                            br_ []
                            a_ [ href_ "/cert/default.asp" ] $ "Bootstrap Certificate"
                            br_ []
                            a_ [ href_ "/cert/default.asp" ] $ "XML Certificate"
                            br_ []
                    hr_ []
                    div_ [ class_ "w3-center w3-small w3-opacity" ] $ do
                        "\r\nW3Schools is optimized for learning, testing, and training. Examples might be simplified to improve reading and basic understanding.\r\nTutorials, references, and examples are constantly reviewed to avoid errors, but we cannot warrant full correctness of all content.\r\nWhile using this site, you agree to have read and accepted our "
                        a_ [ href_ "/about/about_copyright.asp" ] $ "terms of use"
                        ",\r\n"
                        a_ [ href_ "/about/about_privacy.asp" ] $ "cookie and privacy policy"
                        ".\r\n"
                        a_ [ href_ "/about/about_copyright.asp" ] $ "Copyright 1999-2017"
                        " by Refsnes Data. All Rights Reserved."
                        br_ []
                        a_ [ href_ "//www.w3schools.com/w3css/" ] $ "Powered by W3.CSS"
                        "."
                        br_ []
                        br_ []
                        a_ [ href_ "//www.w3schools.com" ] $ img_ [ style_ "width:150px;height:28px;border:0", src_ "/images/w3schoolscom_gray.gif", alt_ "W3Schools.com" ]
                    br_ []
                    br_ []
            script_ [ src_ "/lib/w3schools_footer.js" ] $ ""
            script_ [ src_ "https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit" ] $ ""
            toHtmlRaw  "<!--[if lt IE 9]>\r\n<script src=\"https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js\"></script>\r\n<script src=\"https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js\"></script>  \r\n<![endif]-->"

