{-# LANGUAGE OverloadedStrings, ExtendedDefaultRules #-}

import Lucid
import Lucid.Base
import Data.Text
import System.IO (stdout)
import Data.Text.Lazy.IO as L

main :: IO ()
main = L.hPutStr stdout (renderText template1)

ariaHidden_ :: Text -> Attribute
ariaHidden_ = makeAttribute "aria-hidden"

property_ :: Text -> Attribute
property_ = makeAttribute "property"

-- Template for file: index.html
template1 :: Html ()
template1 = do
    doctype_
    html_ $ do
        head_ $ do
            meta_ [ charset_ "utf-8" ]
            meta_ [ httpEquiv_ "X-UA-Compatible", content_ "IE=edge" ]
            meta_ [ name_ "viewport", content_ "width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" ]
            title_ "Best Wildlife & Adventure Holidays | Summer Camps | Offbeat Trips | Treks | Nature Camps | Kids Camps Pune Mumbai"
            meta_ [ name_ "description", content_ "We are a government recognized Tours & Travels in Pune, India. We specialized in offering Offbeat Destinations in India, summer camps in India, offbeat tours. Foliage Outdoors , Boys and Girls age 8 to 16 years , Kids Acitivity camps near Pune , Mumbai , Wildlife camps Kanha , Bandhavgarh, Ranthambhore,Gir,Corbett , Kaziranga , Manali Adventure, Chandrashila Chopta Trek, Pha Konda trek, Pugmarks123, Cloud 9 , Rishikeh Rafting,Dandeli Goa Meta Description: Foliage Outdoors premier organisation in Pune and near Mumbai catering to boys and girls of age 8 years to 16 years to various destination near Pune, Wildlife National Parks in India and Himalayan Treks" ]
            link_ [ rel_ "canonical", href_ "http://www.foliageoutdoors.com/" ]
            link_ [ href_ "//d1j3wd17d78ehn.cloudfront.net/custom_stylesheets/common/store_front/themes/flexi_theme/style_4156_20171124060331-53c06b5123a00cef3b90b71865ecca2a.css", media_ "screen", rel_ "stylesheet", type_ "text/css" ]
            link_ [ rel_ "icon", type_ "image/png", href_ "//d1j3wd17d78ehn.cloudfront.net/system/images/000/100/266/ff0d1c0901096aa65bc72b8c91c5d20d/favicon/Foliage_logo_favicon_png.png?1510555138" ]
            --  HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries 
            --  WARNING: Respond.js doesn't work if you view the page via file:// 
            -- [if lt IE 9]>
            --     <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
            --     <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
            --   <![endif]
            --  Open Graph Tags 
            --  <meta property="og:type" content="article"> 
            meta_ [ property_ "og:title", content_ "Foliage Outdoors | Wildlife Camps | Adventure Camps | Trekking | Kids Camps Pune |Summer Camps" ]
            meta_ [ property_ "og:description", content_ "Adventure seekers and travellers looking for new vistas are what excite us and have kept us going since 2000." ]
            meta_ [ property_ "og:url", content_ "http://www.foliageoutdoors.com/" ]
            meta_ [ property_ "og:site_name", content_ "Foliage Outdoors" ]
            meta_ [ property_ "og:image", content_ "//d1j3wd17d78ehn.cloudfront.net/system/images/000/102/604/99cc0041ebd04dd50c12b7f9aff70fe6/banner/24_(1).jpg?1511023098" ]
            --  Client stylesheet and header script 
            style_ [ type_ "text/css" ] $ "#body > div > div.content-area > div.main-content > div.section.additional-fields-section > div.additional-fields > div > div.field-title{display:none;}\n\n#body > div > div.content-area > div.main-content > div.section.additional-fields-section > div.additional-fields > div > div.field-value{display:none;}\n\n.section-type-accreditations > .content > .logo-item > .logo{\n  filter: none !important;\n}\n\n.page-type-trip .section-type-banner .floating-container .book-button{font-size:18px;}\n.section-type-accreditations > .content > .logo-item > a > .logo{\n  filter: none !important;}\n\n.trips-date-based .months-listing .month-accordion .accordion-content .accordion-data .trip-info .availability { display:none;}\n\n#body > div > div.content-area > div.section.trips-date-based > div.months-listing > div.month-accordion.active > div.accordion-content.slide > div > div > div > span:nth-child(3){ display:none;}\n\n.footer-container.footer-multi-column{font-size:14px;}\n\n.header-center-aligned .header-bottom .main-nav{font-size:14px;}\n\n.page-type-trip .section-type-banner .mobile-floating-container .btn-container .book-button{font-size:14px;}\n\n.page-type-trip .additional-fields-section .additional-fields{display:none;}\n\n.trips-date-based .months-listing .month-accordion .accordion-content .accordion-data .trip-info .tour-location .media-body .available-seats-sticker-price > span:first-child{display:none;}"
            --  Global site tag (gtag.js) - AdWords: 874842349 
            script_ [ async_ "", src_ "https://www.googletagmanager.com/gtag/js?id=AW-874842349" ] $ ""
            script_ "window.dataLayer = window.dataLayer || [];\n  function gtag(){dataLayer.push(arguments);}\n  gtag('js', new Date());\n\n  gtag('config', 'AW-874842349');"
            --  Global site tag (gtag.js) - Google Analytics 
            script_ [ async_ "", src_ "https://www.googletagmanager.com/gtag/js?id=UA-1961475-4" ] $ ""
            script_ "window.dataLayer = window.dataLayer || [];\n  function gtag(){dataLayer.push(arguments);}\n  gtag('js', new Date());\n\n  gtag('config', 'UA-1961475-4');"
            --  Google Tag Manager 
            script_ "(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':\nnew Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],\nj=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=\n'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);\n})(window,document,'script','dataLayer','GTM-PJSPXL7');"
            --  End Google Tag Manager 
            --  Global site tag (gtag.js) - Google Analytics 
            script_ [ async_ "", src_ "https://www.googletagmanager.com/gtag/js?id=UA-1961475-9" ] $ ""
            script_ "window.dataLayer = window.dataLayer || [];\n  function gtag(){dataLayer.push(arguments);}\n  gtag('js', new Date());\n\n  gtag('config', 'UA-1961475-9');"
            --  Facebook Pixel Code 
            script_ "!function(f,b,e,v,n,t,s)\n  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?\n  n.callMethod.apply(n,arguments):n.queue.push(arguments)};\n  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';\n  n.queue=[];t=b.createElement(e);t.async=!0;\n  t.src=v;s=b.getElementsByTagName(e)[0];\n  s.parentNode.insertBefore(t,s)}(window, document,'script',\n  'https://connect.facebook.net/en_US/fbevents.js');\n  fbq('init', '1565756943734145');\n  fbq('track', 'PageView');"
            noscript_ $ img_ [ height_ "1", width_ "1", style_ "display:none", src_ "https://www.facebook.com/tr?id=1565756943734145&ev=PageView&noscript=1" ]
            --  End Facebook Pixel Code 
        body_ [ id_ "", data_ "page-type" "home", data_ "page" "38017", class_ "container-fluid assan-container index_handler center-aligned-header-style ", data_ "spy" "scroll", data_ "target" ".sticky-menu", data_ "offset" "150" ] $ do
            header_ [ class_ "header-center-aligned " ] $ do
                div_ [ class_ "header-top" ] $ div_ [ class_ "container" ] $ div_ [ class_ "row" ] $ div_ [ class_ "col-xs-12" ] $ div_ [ class_ "holder" ] $ do
                    div_ [ class_ "hidden-xs hidden-sm info-block" ] $ ul_ [ class_ "info-list list-unstyled" ] $ do
                        li_ $ a_ [ href_ "tel://#{@client.support_phone}" ] $ do
                            i_ [ class_ "fa fa-phone skip-title-check", ariaHidden_ "true" ] $ ""
                            "+91 2066447777"
                        li_ $ a_ [ href_ "mailto:#{@client.support_email}" ] $ do
                            i_ [ class_ "fa fa-envelope", ariaHidden_ "true" ] $ ""
                            "info@foliageoutdoors.com"
