{-# LANGUAGE OverloadedStrings, ExtendedDefaultRules #-}

import Lucid
import System.IO (stdout)
import qualified Data.Text.Lazy.IO as L

main :: IO ()
main = L.hPutStr stdout (renderText template1)

-- Template for file: test2.html
template1 :: Html ()
template1 = do
    div_ [ class_ "icon" ] $ do
        div_ [ class_ "svg svg-facebook" ] $ --  <svg version="1.1" id="Layer_1"> 
        --   </svg>
        --   
        "Facebook"

