{-# LANGUAGE OverloadedStrings, ExtendedDefaultRules #-}

import Lucid
import System.IO (stdout)
import qualified Data.Text.Lazy.IO as L

main :: IO ()
main = L.hPutStr stdout (renderText template1)

-- Template for file: test2.html
template1 :: Html ()
template1 =  div_ [ class_ "content-holder image-align-bottom" ] $ div_ [ class_ "text-block no-image-block text-align-center" ] $ p_ $ do
                        "We are an organisation working in the field of Eco-tourism, from past eighteen years and stand tall, as a recognized name in the domain of"
                        strong_ "'Wildlife,"
                        strong_ "Adventure"
                        strong_ "and Trekking Holidays'"
                        "and have rendered lasting experiences to travel and wildlife enthusiasts, corporates and adventure dwellers of all ages."
